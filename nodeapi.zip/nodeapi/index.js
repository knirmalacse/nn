var fs = require("fs");
var http = require("http");
var configFile = 'config.json';
var express = require('express');
var validator = require('express-validator');
var path = require('path');
var bodyParser = require('body-parser');

const jwt = require('jsonwebtoken');
const expressJwt = require('express-jwt');

var app = express();
var server = http.createServer(app);
var router = express.Router();
var request = require('request');
var redis   = require("redis");
var session = require('express-session');
var redisStore = require('connect-redis')(session);
var client  = redis.createClient();
var cors=require('cors');
var mongoose = require('mongoose');
var auditLog = require('audit-log');
const mongojs = require("mongojs");
const fileUpload = require('express-fileupload');
if(server) server.close();
/*Local files*/
//var user = require('./app/user');
//var account = require('./app/account');
var common = require('./app/common');
var audit = require('./app/auditLog');
//var acl = require('./app/acl');
//var acl = require('./server/routes/Modules/Acl');
// read config
var configJSON = JSON.parse(fs.readFileSync(path.join(__dirname, configFile)));



// Parsers
app.use(validator());
app.use(bodyParser.json());



app.use(bodyParser.urlencoded({ extended: true}));

app.use(fileUpload());

// Angular DIST output folder
app.use(express.static(path.join(__dirname, '../dist')));
app.use(function(req, res, next) {
  res.set('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
  next();
});
app.use(function(req, res, next) {
  global.user_ip_address = ((req.headers['x-forwarded-for'] || '').split(',')[0] || req.connection.remoteAddress);
  res.header("Access-Control-Allow-Origin", "*");
  res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');
  res.header("Access-Control-Allow-Headers", "X-Requested-With,Content-Type,Cache-Control,Authorization");
  next();
});
let Forbidden = {
  status: 403,
  message : "Forbidden"
}
app.use(function(req, res, next) {
	//'/api/user/login'
	console.log(req.originalUrl);
	var URLStr = req.originalUrl;
	if(req.originalUrl != '/api/user/login' && URLStr.indexOf('/api/uploadFile') < 0 ) {
		if(req.headers.hasOwnProperty("authorization")) {
			let auth =  req.headers['authorization'];
			//console.log(req.headers);
			//console.log(auth);
			let token =  auth.split(" ")[1];
			//console.log(token);
			jwt.verify(token, configJSON.API.secretKey, function(err, payload) {
				//console.log(payload)
				if (payload) {
					next();
				} else {
					res.send(Forbidden);
				}
			});
		} else {
			res.send(Forbidden);
		}
		
	} else {
		next();
	}
 
  /* const token =  auth.split(" ")[1];
  jwt.verify(token, configJSON.API.secretKey, function(err, payload) {
	console.log(payload)
	if (payload) {
		next();
	} else {
		res.send(Forbidden);
	}
  }); *///, verifyOptions
  //console.log(JSON.stringify(legit));
  //next();
});
app.use(session(
  {
	secret: configJSON.Redis.sessionSecretKey,
	store: new redisStore({ host: configJSON.Redis.host, port: configJSON.Redis.port, client: client,
	  ttl :  configJSON.Redis.sessionTTL }),
	resave: false,
	saveUninitialized: true 
  }
));

	

var logFunct = require('./log_function.js');
var db = "";
//console.log("out app use");
//app.use(function(req, res, next) {
	//var dbcollList = new Array("users","log_detail");
	//console.log("in app use");
	var strAuthsrcAppend = "";
	if(!configJSON.Production) strAuthsrcAppend = "?&authSource=admin";
	logFunct.getDatabaseConn(mongojs,configJSON,strAuthsrcAppend,function(responseDB){
		var db = responseDB;
		var acl = require('./server/routes/Modules/Acl')(app, express, request, common, configJSON,logFunct,fs,db);
		var application = require('./server/routes/Modules/Application')(app, express, request, common, configJSON,logFunct,fs,db);
		var acp = require('./server/routes/Modules/Acp')(app, express, request, common, configJSON,logFunct,fs,db);

		var user = require('./server/routes/Modules/User')(app, express, request, common, configJSON,logFunct,fs,db);
		var account = require('./server/routes/Modules/Account')(app, express, request, common, configJSON,logFunct,fs,db);

		var ruleengine = require('./server/routes/Modules/Ruleengine')(app, express, request, common, configJSON,logFunct,fs,db);
		var workexp = require('./server/routes/Modules/Workexp')(app, express, request, common, configJSON,logFunct,fs,db);
		var age = require('./server/routes/Modules/Age')(app, express, request, common, configJSON,logFunct,fs,db);
		app.use(function(req, res, next) {
		  if(configJSON.AuditLog.Enable==true) audit(auditLog, mongoose, common, configJSON, req);
		  if(req.originalUrl.slice(0, 5)=='/api/' && req.originalUrl!='/api/user/login' && req.originalUrl!='/api/usrLogCheck' && req.originalUrl!='/api/usrDetails' && req.originalUrl!='/api/logout') {


		   // if(acl(request, req, res, common, configJSON)) {
			 // next();	
			//} else {
			//  res.send(Forbidden);
			//}
		  } else {
			next();	
		  }  
		});
    });
	//console.log("in in double app use");
	//next();
//});


let ConnectionError = {
	Message:"Connection Failed",
	DestinationHost: null,
	DestinationPort: null,
}
/**********************************Routing Starts*************************************************************************/
/** Login Check****/
//user(app, express, request, common, configJSON);

/** Account Check****/
//account(app, express, request, common, configJSON);
//account1(app, express, request, common, configJSON);
/* router.post('/user/login',function(req,res,next){
	console.log('user login');
	res.send('hello');
}); */

/** USer Session Check ENDS****/
/**********************************Routing End*************************************************************************/

app.use('/api', router);


server.listen(configJSON.API.port,configJSON.API.host,function(){
  console.log("Server listening at:"+configJSON.API.host+" on port:"+configJSON.API.port);
});

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../dist/index.html'));
});
//console.log(router);
module.exports = router;