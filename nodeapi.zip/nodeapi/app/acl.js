module.exports = function (request, req, res, common, configJSON) {
  var UserData = common.getSession(req);
  var request = require('sync-request');
  console.log(UserData);
  console.log(req.originalUrl);
  var response = request('POST', 'http://' + configJSON.Module.Acl.host +':'+ configJSON.Module.Acl.port + '/', {
    json: {UserData: UserData, originalUrl: req.originalUrl, method: req.method},
  });
  var JSONFormatResponse = JSON.parse(response.getBody('utf8'));
  console.log(req.originalUrl + " " + req.method + " " +JSONFormatResponse.status);
  if(JSONFormatResponse.status==200) return true;
  else if(JSONFormatResponse.status==403) return false;
  else return false;
}