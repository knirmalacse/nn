module.exports = function (auditLog, mongoose, common, configJSON, req) {
  var UserData = common.getSession(req);
  if(UserData !== undefined && UserData!='') {
    var DateObj = new Date();
    var Month = ("0" + (parseInt(DateObj.getMonth())+ 1)).slice(-2);

     auditLog.addTransport("mongoose", {connectionString: "mongodb://"+configJSON.AuditLog.Database.mongodb.host+":"+configJSON.AuditLog.Database.mongodb.port+"/"+ configJSON.AuditLog.Database.mongodb.name, collectionName:'auditLog'+DateObj.getFullYear()+Month+DateObj.getDate()});
  
    // auditLog.addTransport("console");
    /* actor: {type:String},
	origin: {type:String},
	action: {type:String},
	label: {type:String},
	object: {type:String},
	description: {type:String}
	below line is using this schema
    */
    var origin = { "reffer":req.headers.referer, originalUrl: req.originalUrl};
    auditLog.logEvent(JSON.stringify(req.session.userData), JSON.stringify(origin), req.method, req.statusMessage, '', JSON.stringify(req.body));
  }
}