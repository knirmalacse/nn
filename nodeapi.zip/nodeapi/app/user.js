module.exports = function (app, express, request, common, configJSON) {
	
  var ROUTER = express.Router();
  
  routerURLObj = configJSON.Module.User.routerURLObj;
  routerURLObj.forEach(function(routerObj){
	   //console.log(routerObj);
	   
		routerURLSet = routerObj.METHOD;
		routerURLSet.forEach(function(routerURL){  console.log(routerObj.URL + routerURL);
	    if(routerURL == 'POST'){
			 console.log('User login post');
			 /* ROUTER.route(routerObj.URL)
				.post(common.mthdPostFn(req, res, next, request, configJSON.API.host, configJSON.Module.User.host, configJSON.Module.User.port, routerObj.URL));  */
			ROUTER.route(routerObj.URL)
				.post(function(req, res, next){
					var UserData = common.getSession(req);
					//console.log(UserData.userData);
					req.body.curUsr = UserData.userData;
					common.mthdPostFn(req, res, next, request, configJSON.API.host, configJSON.Module.User.host, configJSON.Module.User.port, routerObj.URL);
					//console.log(req.session);
					//req.session.email=user[0].frmEmail1;
					//req.session.usrName=user[0].frmusername;
					//req.session.save();
			});
		} else if(routerURL == 'GET'){
			ROUTER.route(routerObj.URL)
			.get(function(req, res, next){
				console.log('Users get');
				common.mthdGetFn(req, res, next, request, configJSON.API.host, configJSON.Module.User.host, configJSON.Module.User.port, routerObj.URL)			  
			}); 
		} else if(routerURL == 'DELETE'){
			ROUTER.route(routerObj.URL)
				.delete(function(req, res, next){
					var UserData = common.getSession(req);
					req.query.curUsr = UserData.userData.frmusername;
					common.mthdDeleteFn(req, res, next, request, configJSON.API.host, configJSON.Module.User.host, configJSON.Module.User.port, routerObj.URL)
				// console.log('Delete Project');
				  
			});
		} else if(routerURL == 'PUT'){
			ROUTER.route(routerObj.URL)
				.put(function(req, res, next){
					var UserData = common.getSession(req);
					//console.log(UserData.userData);
					req.body.curUsr = UserData.userData;
				 //console.log('Put Project'+req.body.userID+'--'+req.body.status);
				 common.mthdPutFn(req, res, next, request, configJSON.API.host, configJSON.Module.User.host, configJSON.Module.User.port, routerObj.URL) 
			});
		}
	    });
   });
  
  /*ROUTER.route('/login')
    .post(function(req, res, next){
	  request({
		method: 'POST',
		uri: "http://" + configJSON.Module.User.host +':'+ configJSON.Module.User.port + '/login',
		body:JSON.stringify(req.body),
		headers: {
		  'x-access-token': configJSON.API.host,
		  'Content-Type': 'application/json',
		  'body': JSON.stringify(req.body)
		}
	  }, function (error, response, body) {
		if(!error && response.statusCode == 200) {
		  body = JSON.parse(body)
		  //console.log('response'+response);
		  //console.log('body'+body);
		  if(body.success==true) {
			common.setSession(req, body.data);
			// common.getSession(req);	
			res.send(body);
		  } else {
			  res.send(body);
		  }
		} else {
		 
		}
	  });
	});*/
	
	ROUTER.route('/usrLogCheck')
      .get(function(req, res, next){
		var UserData = common.getSession(req);
		if(UserData !== undefined && UserData!='') {
		  response={
			status: 200,
			success:true,
			message: "success"
		  }  
		  res.send(response);
		}
	});
	
	ROUTER.route('/usrDetails')
		.get(function(req,res){
		//sess = req.session;
		//console.log(req.session);
		response.data = '';
		var UserData = common.getSession(req);
		console.log('here'+UserData.userData.EmailID+UserData.userData.UserName);
		if(UserData.userData.EmailID && UserData.userData.UserName) {
			response.success = true;
			response.data = UserData.userData.UserName;
		} else {
			response.success = false;
		}
		res.json(response);
	});
	ROUTER.route('/logout')
      .get(function(req, res, next){
	  response={
		status: 200,
		success:false,
		message: "success"
	  } 
		//console.log(req.session);
		if (req.session) {
		  response.success = common.destroySession(req, res, next);
	    }
		//console.log(req.session);
		res.json(response);
	});
	
  app.use('/api', ROUTER);
};