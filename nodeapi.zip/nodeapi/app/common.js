function setSession(req, data){
  req.session.userData = data;
  req.session.save();
  return true;
}

function getSession(req) {
  return req.session;
}
function destroySession(req, res, next) {
  if (req.session) {	
    req.session.destroy(function(err) {
	  if(err) {
		return false;
	  } else {
	    return true;
	  }
	});
  } else {
	// return res.redirect('/');
  }
}

function mthdPostFn (req, res, next, request, host, moduleHost, ModulePort, URL){
	request({
		method: 'post',
		uri: "http://" + moduleHost +':'+ ModulePort + URL,
		body:JSON.stringify(req.body),
		headers: {
		  'x-access-token': host,
		  'Content-Type': 'application/json',
		  'body': JSON.stringify(req.body)
		}
	  }, function (error, response, body) {
		if(!error && response.statusCode == 200) {
		  body = JSON.parse(body)	
		  //console.log(body.uData);
		  setSession(req,body.uData);
		  res.send(body);
		 
		} else {
		 
		}
	});
}

function mthdGetFn (req, res, next, request, host, moduleHost, ModulePort, URL){
	request({
		method: 'GET',
		uri: "http://" + moduleHost +':'+ ModulePort + URL,
		body:JSON.stringify(req.query),
		headers: {
		  'x-access-token': host,
		  'Content-Type': 'application/json',
		  'body': JSON.stringify(req.query)				 
		}
		}, function (error, response, body) {
		if(!error && response.statusCode == 200) {
		  res.send(body);		
		  //return body;
		} else {
		 
		}	
	});	
}

function mthdDeleteFn (req, res, next, request, host, moduleHost, ModulePort, URL){
	request({
		method: 'DELETE',
		uri: "http://" + moduleHost +':'+ ModulePort + URL,
		body:JSON.stringify(req.query),
		headers: {
		  'x-access-token': host,
		  'Content-Type': 'application/json',
		  'body': JSON.stringify(req.query)
		}
	  }, function (error, response, body) {
		if(!error && response.statusCode == 200) {
		  body = JSON.parse(body)					  
		  res.send(body);
		 
		} else {
		 
		}
	  });
}

function mthdPutFn (req, res, next, request, host, moduleHost, ModulePort, URL){
	request({
		method: 'PUT',
		uri: "http://" + moduleHost +':'+ ModulePort + URL,
		body:JSON.stringify(req.body),
		headers: {
		  'x-access-token': host,
		  'Content-Type': 'application/json',
		  'body': JSON.stringify(req.body)
		}
	  }, function (error, response, body) {
		if(!error && response.statusCode == 200) {
		  body = JSON.parse(body)					  
		  res.send(body);
		 
		} else {
		 
		}
	  });
}
module.exports = {
  setSession,getSession,destroySession,mthdPostFn,mthdGetFn,mthdDeleteFn,mthdPutFn
};
