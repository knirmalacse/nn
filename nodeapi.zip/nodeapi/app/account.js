module.exports = function (app, express, request, common, configJSON) {
		
	var ROUTER = express.Router();

	routerURLObj = configJSON.Module.Account.routerURLObj;
	routerURLObj.forEach(function(routerObj){
	  
		routerURLSet = routerObj.METHOD;
		routerURLSet.forEach(function(routerURL){  console.log(routerObj.URL + routerURL);
	    if(routerURL == 'POST'){
			ROUTER.route(routerObj.URL)
				.post(function(req, res, next){
				 console.log('Create Project');
					/* let sampleFile = req.files.projectLogo;
					console.log(sampleFile); */
				 var UserData = common.getSession(req);
				 console.log(UserData);
				 req.body.curUsr = UserData.userData;
				 console.log(req.body);
				/* req.body.projectServices.forEach(function(service) {
				  console.log(service);
				}); */
				  request({
					method: 'post',
					uri: "http://" + configJSON.Module.Account.host +':'+ configJSON.Module.Account.port + routerObj.URL,
					body:JSON.stringify(req.body),
					headers: {
					  'x-access-token': configJSON.API.host,
					  'Content-Type': 'application/json',
					  'body': JSON.stringify(req.body)
					}
				  }, function (error, response, body) {
					if(!error && response.statusCode == 200) {
					  body = JSON.parse(body)					  
					  res.send(body);
					 
					} else {
					 
					}
				  });
			});
		} else if(routerURL == 'GET'){
			ROUTER.route(routerObj.URL)
			.get(function(req, res, next){
				console.log('Get Project detail'+JSON.stringify(req.query.AID));
				request({
				method: 'GET',
				uri: "http://" + configJSON.Module.Account.host +':'+ configJSON.Module.Account.port + routerObj.URL,
				body:JSON.stringify(req.query),
				headers: {
				  'x-access-token': configJSON.API.host,
				  'Content-Type': 'application/json',
				  'body': JSON.stringify(req.query)				 
				}
				}, function (error, response, body) {
					if(!error && response.statusCode == 200) {
					  res.send(body);				 
					} else {
					 
					}	
				});				  
			});
		} else if(routerURL == 'DELETE'){
			ROUTER.route(routerObj.URL)
				.delete(function(req, res, next){
				 console.log('Delete Project');
				 var UserData = common.getSession(req);
				  req.query.curUsr = UserData.userData.frmusername;
				  request({
					method: 'delete',
					uri: "http://" + configJSON.Module.Account.host +':'+ configJSON.Module.Account.port + routerObj.URL,
					body:JSON.stringify(req.query),
					headers: {
					  'x-access-token': configJSON.API.host,
					  'Content-Type': 'application/json',
					  'body': JSON.stringify(req.query)
					}
				  }, function (error, response, body) {
					if(!error && response.statusCode == 200) {
					  body = JSON.parse(body)					  
					  res.send(body);
					 
					} else {
					 
					}
				  });
			});
		} else if(routerURL == 'PUT'){
			ROUTER.route(routerObj.URL)
				.post(function(req, res, next){
				 console.log('Put Project');
				 var UserData = common.getSession(req);
				 req.body.curUsr = UserData.userData;
				  request({
					method: 'post',
					uri: "http://" + configJSON.Module.Account.host +':'+ configJSON.Module.Account.port + routerObj.URL,
					body:JSON.stringify(req.body),
					headers: {
					  'x-access-token': configJSON.API.host,
					  'Content-Type': 'application/json',
					  'body': JSON.stringify(req.body)
					}
				  }, function (error, response, body) {
					if(!error && response.statusCode == 200) {
					  body = JSON.parse(body)					  
					  res.send(body);
					 
					} else {
					 
					}
				  });
			});
		}
	  });  
   });
	
	
  app.use('/api', ROUTER);
};