const express = require('express');
const app = express();
var bodyParser = require('body-parser');
var validator = require('express-validator');
var db = require('./db/db');


app.use(validator());
/* app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true})); */
 
app.use(bodyParser.json({limit: '50mb', extended: true}));
app.use(bodyParser.urlencoded({limit: '50mb', extended: true}));

app.use(function(req, res, next) {
  res.set('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
  next();
});
app.use(function(req, res, next) {
  global.user_ip_address = ((req.headers['x-forwarded-for'] || '').split(',')[0] || req.connection.remoteAddress);
  res.header("Access-Control-Allow-Origin", "*");
  res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');
  res.header("Access-Control-Allow-Headers", "X-Requested-With,Content-Type,Cache-Control,Authorization");
  next();
});
global.config = require('./config/config.json')[process.env.NODE_ENV || "development"];
// MongoDB Configuration
if(process.env.NODE_ENV != 'development') {
  // config.mongoDB.Username = process.env.APPLICATION_MONGODB_USERNAME; 
  // config.mongoDB.Password = process.env.APPLICATION_MONGODB_PASSWORD;
  // Production Setup
  // config.Production = process.env.APPLICATION_IS_PRODUCTION || config.Production
}

const acppassport = require('passport');
var acpauth = require('./acppassport');
app.use(acppassport.initialize());
app.use(acppassport.session());


/* app.use(express.static(__dirname + '/public'));*/
//app.use(require('./middlewares'));
//app.use(require('./routes'));
//app.use(require('./controllers'));

// Default page. Kubernetes health Check page.
/* app.use("/", function (req, res) {
  res.send('App working')
});
 */

app.get('/', (req, res) => {	
  res.send('Working...');	
});	

const routes = require('./routes');
app.use("/api", routes);

db.connect(function(err) {
	if (err) {
		console.log('Unable to connect to Mongo.')
		//process.exit(1)
	} else {
		app.listen(config.API.port,config.API.host, function() {
			console.log("Server listening at:"+config.API.host+" on port:"+config.API.port);
		})
	}
});

/* app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../dist/index.html'));
}); */
//console.log(router);
//module.exports = router;