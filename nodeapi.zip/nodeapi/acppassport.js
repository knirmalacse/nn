//const config = require('./config/config.json')[process.env.NODE_ENV || "development"];
var acppassport = require('passport');
var LocalStrategy = require('passport-local').Strategy;
var acpModel = require('./models/acpModel');
var appdb = require('./db/appdb');
const passportJWT = require("passport-jwt");
const JWTStrategy   = passportJWT.Strategy;
const ExtractJWT = passportJWT.ExtractJwt; 
///password bcrypt starts//
const bcrypt = require('bcrypt');
const saltRounds = 10;
///password bcrypt ends// 
 
acppassport.use(new LocalStrategy({
			usernameField : 'usrName',
            passwordField : 'usrPwd',
            passReqToCallback : true 
		},
    function (req,usrName, usrPwd, cb) {
		var projectIdentifier = req.body.projectIdentifier;
        //this one is typically a DB call. Assume that the returned user object is pre-formatted and ready for storing in JWT
		appdb.connect(projectIdentifier,function(err) {
			if (err) {
				return cb(null, false, {message: 'Unable to connect to Mongo.'});
				 //process.exit(1)
			}else{
				 
				acpModel.get(usrName ,usrPwd, function(err, user) { 
					if (err) return cb(err); 
					if (!user)  return cb(null, false, {message: 'Invalid Registration No or Password.'}); 
						var hashpwd =user['userPwd'];
							console.log('---hashpwd---');
							console.log(hashpwd);	
							console.log('---usrPwd---');
							console.log(usrPwd);
						var passwordStatus = bcrypt.compareSync(usrPwd, hashpwd);   
							console.log('---passwordStatus---');
							console.log(passwordStatus);						
						//if(passwordStatus==false)  return cb(null, false, {message: 'Invalid  Password.'});    
					  	
				     return cb(null, user, {message: 'Logged In Successfully'}); 
				 });
			}
		});
           
    }
));

//
// In order to help keep authentication state across HTTP requests,
// Sequelize needs to serialize and deserialize the user
// Just consider this part boilerplate needed to make it all work
acppassport.serializeUser(function(user, cb) {
  cb(null, user);
});
//
acppassport.deserializeUser(function(obj, cb) {
  cb(null, obj);
});


acppassport.use(new JWTStrategy({
        jwtFromRequest: ExtractJWT.fromAuthHeaderAsBearerToken(),
        secretOrKey   : config.API.secretKey,
		passReqToCallback : true 
    },
    function (req,jwtPayload, cb) {
		var projectIdentifier = req.body.projectIdentifier;
		if (typeof projectIdentifier == 'undefined' || projectIdentifier=='') var projectIdentifier = req.query.projectIdentifier;
		
		appdb.connect(projectIdentifier,function(err) {
			if (err) {
				return cb(null, false, {message: 'Unable to connect to Mongo.'});
				 //process.exit(1)
			}else{
				if(jwtPayload.userName){
					acpModel.findOneById(jwtPayload.userName, function(err, user) {
						if (err) return cb(err);
						// if no user is found, return the message
						return cb(null, user, {message: 'Logged In Successfully'});
					 });
				}else{
					return cb(null, false, {message: 'Error'});
				}
			}
		});
    }
));


// Exporting our configured passport
module.exports = acppassport;