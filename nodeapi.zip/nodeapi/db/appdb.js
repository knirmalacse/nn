const ObjectID = require("mongodb").ObjectID;
const mongojs = require("mongojs");
//const config = require('../config/config.json')[process.env.NODE_ENV || "development"];

let appdbConnection = {};

var state = {
  appdb: null,
}

appdbConnection.connect = function( appNamestr,done) {
	//console.log("in connect");
	//if (state.appdb) return done() 
	var MongoConnStr = config.mongoDB.Username+':'+config.mongoDB.Password+'@'+config.mongoDB.host+':'+config.mongoDB.port+'/'+appNamestr+''+config.mongoDB.strAuthsrcAppend;
	state.appdb = mongojs(MongoConnStr);
	done();
 /*  MongoClient.connect(url, function(err, db) {
    if (err) return done(err)
    state.db = db
    done()
  }) */
}

appdbConnection.get = function() {
  return state.appdb
}

appdbConnection.close = function(done) {
  if (state.appdb) {
    state.appdb.close(function(err, result) {
      state.appdb = null;
      //state.mode = null
      done();
    })
  }
}

module.exports = appdbConnection;