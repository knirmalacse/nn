const mongojs = require("mongojs");
//const config = require('../config/config.json')[process.env.NODE_ENV || "development"];

let dbConnection = {};

var state = {
  db: null,
} 

dbConnection.connect = function( done) {
  if (state.db) return done()
	  
	var MongoConnStr = config.mongoDB.Username+':'+config.mongoDB.Password+'@'+config.mongoDB.host+':'+config.mongoDB.port+'/'+config.AdminDatabase+''+config.mongoDB.strAuthsrcAppend;
	state.db = mongojs(MongoConnStr);
	done();
 /*  MongoClient.connect(url, function(err, db) {
    if (err) return done(err)
    state.db = db
    done()
  }) */
}

dbConnection.get = function() {
  return state.db
}

dbConnection.close = function(done) {
  if (state.db) {
    state.db.close(function(err, result) {
      state.db = null
      //state.mode = null
      done(err)
    })
  }
}

module.exports = dbConnection;