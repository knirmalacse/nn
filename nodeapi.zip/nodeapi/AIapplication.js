module.exports = {
	createCounterAI: function(category,seqAIVal,db,callback) {
		console.log("counter Creation");
		db.AIapplication.find({_id: category}, function (err, resAI) {
			if(resAI.length == 0) {
				db.AIapplication.insert ( {_id: category , sequence_value : seqAIVal },{},
				function(err,result){
					if (!err) return callback('set AutoIncrement successfully');
				});
			}else return callback('set AutoIncrement successfully');
		});
	},
	getValueForNextSequence: function(sequenceOfName,db,callback){
		var sequence_valueRes;
		var sequenceDoc = db.AIapplication.findAndModify({
		   query:{_id: sequenceOfName },
		   update: {$inc:{sequence_value:1}},
		   new:true
		}, function (err, resAI) {//console.log(resAI);
			console.log(err);
			var sequence_valueRes = resAI.sequence_value;
			return callback(resAI.sequence_value);
		}); 
		/* let sequenceDoc = db.AIapplication.findAndModify({
		   query:{_id: sequenceOfName },
		   update: {$inc:{sequence_value:1}},
		   new:true
		}); 
		console.log(sequenceDoc);
		
		return sequenceDoc.sequence_value; */
	},
	sendAPIService: function(postData,routerKey,headerData,request,configJSON,callback){
		
		/* console.log(postData);
		console.log(routerKey);
		console.log(headerData);
		console.log(request); */
		console.log("start");
		
		request({
			method: 'post',
			url: configJSON.APIGateway.url+':'+configJSON.APIGateway.port+'/'+routerKey,
			body:JSON.stringify(postData),
			headers: headerData
		}, function (error, response, body) {
			console.log("response end");
			/* console.log(error);
			console.log(response); */
			if(!error && response.status == 200) {
				console.log(response);
				return callback('success');
			} else {
				console.log(error);
			}
		});
		console.log("out side");
		
	},
	getDatabaseConn: function(mongojs,configJSON,strAuthsrcAppend,AppDatabase,callback){ 
		//var dbCon = mongojs('"'+configJSON.mongoDB.Username+':'+configJSON.mongoDB.Password+'@'+configJSON.mongoDB.host+':'+configJSON.mongoDB.host+'/'+configJSON.AdminDatabase+'"', DbcollectionList);
		//var dbCon = mongojs('Admin:Admin123@localhost:27017/FormBuilderACP?&authSource=admin');
		var MongoConnStr = configJSON.mongoDB.Username+':'+configJSON.mongoDB.Password+'@'+configJSON.mongoDB.host+':'+configJSON.mongoDB.port+'/'+AppDatabase+''+strAuthsrcAppend;
		var dbCon = mongojs(MongoConnStr);
		return callback(dbCon);
	}
}