var db = require('../db/db');
var appdb = require('../db/appdb');
const ObjectID = require("mongodb").ObjectID;
let acpModel = {};

acpModel.saveStaticDoc = function(data, cb) {
	var dbConn = appdb.get();
	dbConn.staticdocs.save(data,{}, function(err, result) {		 
		if (err) return cb(err)
		cb(null, result)
	});
}

acpModel.getDocs = function(cb) {
	var dbConn = appdb.get();
	/* dbConn.staticdocs.find({}, function(err, result) {
		if (err) return cb(err)
		cb(null, result)
	}); */
	dbConn.staticdocs.aggregate({  
			"$group": {
			"_id": "$doccategory",
			"docname": { "$last": "$docname" },
			"docfile": { "$last": "$docfile" },
			"docPath": { "$last": "$docPath" },
			"createdDate": { "$last": "$createdDate" },
			"doccategory": { "$last": "$doccategory" }
			}}, 
			{ "$sort": { "createdDate": -1 }  },  
		function(err, result) {		 
		if (err) return cb(err)
		cb(null, result)
	});
}

acpModel.saveAdminUser = function(data,dataId, cb) {
	var dbConn = appdb.get();
	delete data.data;
	if(dataId != '') { //update
		dbConn.admin_users.update({'_id': ObjectID(dataId)},{$set: data},
		function(err, result) {
			if (err) return cb(err)
			cb(null, result)
		});
	} else { //save
		dbConn.admin_users.save(data,{}, function(err, result) {
			if (err) return cb(err)
			cb(null, result)
		});
	}
}
acpModel.saveIpLogCheck = function(data, cb) {
	var dbConn = appdb.get();	 
		dbConn.admin_IpLogCheck.save(data, function(err, result) {
			if (err) return cb(err)
			cb(null, result)
		});	 
}
acpModel.CountIpLogCheck = function(data, cb) {
	 var dbConn = appdb.get();	 
		 var user_ip=data.user_ip; 
					let date_ob = new Date();
					let date = ("0" + date_ob.getDate()).slice(-2);
					let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
					let year = date_ob.getFullYear();
					var createdDate = year + "-" + month + "-" + date;
				dbConn.admin_IpLogCheck.aggregate( { $sort: { "_id": -1 } },{  
			    $match: {"iplogin_reset_status":1,"user_ip":user_ip,"access_date":createdDate}
				},{ $limit: 5  
			 }, function(err, result) { 	
			if (err) return cb(err)
			cb(null, result)
			}); 
		  
}
 
acpModel.getAdminUser = function(dataId,cb) {
	var dbConn = appdb.get();
	if(dataId!=''){
		dbConn.admin_users.find({'_id': ObjectID(dataId)}, function(err, result) {
			if (err) return cb(err)
			cb(null,result)
		});
	}else{
		dbConn.admin_users.find({}, function(err, result) {
			if (err) return cb(err)
			cb(null,result)
		});
	}
}
acpModel.getLsearchuser = function(searchtype,searchval,cb) { 
	var dbConn = appdb.get();
	var condn = {};
	if(searchtype!='' && searchval!=''){
		var searchvalRes = (searchval.split(',')); 
		if(searchtype == 'registration_no' || searchtype == 'mobile') {
			searchvalArr = searchval.split(',');
			searchvalRes = searchvalArr.map(function (x) { 
				return parseInt(x, 10);
			});
		}
		condn = {[searchtype]:{$in:searchvalRes}};
	}  
	dbConn.registration.find(condn,{},{'sort':{'_id':-1},'limit':20}, function(err, result) {
		 
		if (err) return cb(err)
		cb(null,result)
	});
}
acpModel.getunblkaccessRouteFind = function(unblkaccesstype,unblkaccessval,cb) { 
	var dbConn = appdb.get();
	var condn = {};	
	if(unblkaccesstype!='' && unblkaccessval!=''){
		var unblkaccessvalRes = (unblkaccessval.split(','));		
		if(unblkaccesstype == 'user_ip' || unblkaccesstype == 'username') {
			unblkaccessvalArr = unblkaccessval.split(',');
			condn = {[unblkaccesstype]:{$in:unblkaccessvalRes}};	
		} 
		dbConn.admin_IpLogCheck.find(condn,{},{'sort':{'_id':-1},'limit':20}, function(err, result) {
		if (err) return cb(err)
		cb(null,result)
		});
	} 		 
}
acpModel.getunblkaccessRouteModel = function(unblkaccesstype,unblkaccessval,cb) { 
	var dbConn = appdb.get();
	var condn = {};	
	if(unblkaccesstype!='' && unblkaccessval!=''){
		var unblkaccessvalRes = (unblkaccessval.split(','));		
		if(unblkaccesstype == 'user_ip' || unblkaccesstype == 'username') {
			unblkaccessvalArr = unblkaccessval.split(',');	 
		} 
		condn = {[unblkaccesstype]:{$in:unblkaccessvalRes}};
		dbConn.admin_IpLogCheck.update( condn, { $set: { iplogin_reset_status : 0,iplogin_status:"SUCCESS" } },{multi: true},   
		function(err, result) {
			if (err) return cb(err)
			cb(null, result)
		}); 
	} 		 
}
acpModel.getLreportsuser = function(dataId,cb) {
	var dbConn = appdb.get();
	  
		dbConn.registration.aggregate({ "$facet": {
					"Total": [
					  { "$match" : {}},
					  { "$count": "Total" },
					],
					"Complete": [
					  { "$match" : {"formio_applstatus":"C"}},
					  { "$count": "Complete" },
					],
					"InComplete": [
					  { "$match" : {"formio_applstatus":"IC"}},
					  { "$count": "InComplete" },
					],
					"Paid": [
					  { "$match" : {"formio_paystatus":"Y"}},
					  { "$count": "Paid" },
					],
					"Unpaid": [
					  { "$match" : {"formio_paystatus":"N"}},
					  { "$count": "Unpaid" },
					]     
			}},
		   { "$project": {
				"Total": { "$arrayElemAt": ["$Total.Total", 0] },
				"Complete": { "$arrayElemAt": ["$Complete.Complete", 0] },			
				"InComplete": { "$arrayElemAt": ["$InComplete.InComplete", 0] },			
				"Paid": { "$arrayElemAt": ["$Paid.Paid", 0] },			
				"Unpaid": { "$arrayElemAt": ["$Unpaid.Unpaid", 0] }			
		   }}, (err, data) => {
		  
		if (err) return cb(err)
		cb(null, data)
	});
	 
}
 
acpModel.get = function(userName, passwd, cb) {
	var dbConn = appdb.get();
	 dbConn.admin_users.find({'userName': userName}, { userName: 1,userPwd: 1,PID:1,userType:1},{'limit':1}, function(err, docs) { 
		if (err) return cb(err) 
		  
		cb(null, docs[0])
	});
}


acpModel.findOneById = function(userName, cb) {
	var dbConn = appdb.get();
	dbConn.admin_users.find({'userName': userName},{'userPwd':0},{'limit':1},function(err, docs) {
		if (err) return cb(err)
		cb(null, docs[0])
	});
}

acpModel.getRegDetails = function(appRegId,cb) {
	var dbConn = appdb.get();
	dbConn.registration.find({'_id': ObjectID(appRegId)},{}, function(err, result) {
		if (err) return cb(err)
		cb(null, result[0])
	});
}
acpModel.SaveRightAccess = function(data,acpId, cb) {
	var dbConn = appdb.get();
	if(acpId != '') { console.log('uuuuuu');console.log(acpId);
		dbConn.collection('rights').update(
		{'_id': ObjectID(acpId) },
		{ "$set": { "access": data.access}},
		function(err, result) { 
		console.log('---result---');
		console.log(result);
			if (err) return cb(err)
			cb(null, result)
		});
	} else { console.log('ssssssss');
		dbConn.rights.save(data,{},
		function(err, result) {
			if (err) return cb(err)
			cb(null, result)
		});	
	}		
}
acpModel.acpRightsgetRole = function(data, cb) {
	var dbConn = appdb.get();
	dbConn.rights.find({'roleID':data}).sort({_id:-1}).limit(1, 
	function(err, result) {
		if (err) return cb(err)
		cb(null, result)
	});
}
acpModel.acpRightsgetRoleAccess = function(data, cb) {
	var dbConn = appdb.get();
	console.log('---roleID roleID roleID---');
	console.log(data);
	if(data!=1) {
	dbConn.rights.find({roleID : data},{ access: 1, _id: 0 },(err, result) => {
		if (err) return cb(err)
		cb(null, result)
	});
	}
}
module.exports = acpModel;