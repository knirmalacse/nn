var db = require('../db/db');
var appdb = require('../db/appdb');

const ObjectID = require("mongodb").ObjectID;

let ruleengineModel = {};

//Ruleengine Model start  
ruleengineModel.ruleengineAdd = function(data, cb) {
	var dbConn = db.get();
	
	dbConn.ruleengine.save(data,{}, function(err, result) {
		if (err) return cb(err)
			//console.log('--------------model resultttttttttt------------');
			//console.log(result);
		cb(null, result)
	    
	});
}
ruleengineModel.ruleengineUpdate = function(data, accID, projID,appendField, _id, cb){
	var dbConn = db.get();
		
		dbConn.collection('ruleengine').update({'accountName':accID,'projectName':projID,'appendFieldLabel':appendField,'_id': {$ne: ObjectID(_id)} }, 
		{
		 $set: { 'rule_status': 'Inactive' }
		
	},function(err, result) {
		
		if (err) return cb(result)
		cb(null, result)
		 
	});
	 
} 
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//ruleengine Model start 
ruleengineModel.ruleengineAggregate = function(qryStrRuleArr,cb) {
	//console.log('------------modal aggregate--------');
	//console.log(qryStrRuleArr);
	var dbConn = db.get(); 
	dbConn.ruleengine.aggregate( [
	  { $match: qryStrRuleArr },
	  { $group : { _id:{appendFieldLabel:"$appendFieldLabel", ruleFor:"$ruleFor"},
	   ruleFor:{ $last: '$ruleFor' },
	   inputSelectInsert : { $last: '$inputSelectInsert' },
	   alertmsgstr : { $last: '$alertmsgstr' },
	   convertedStr : { $last: '$convertedStr' },
	   accountName : { $last: '$accountName' },
	   projectName : { $last: '$projectName' },
	   appendField : { $last: '$appendField' },
	   appendFieldLabel : { $last: '$appendFieldLabel' }, 
	   querybuiderconfig : {$last: '$querybuiderconfig'},
	   query : {$last: '$query'},
	   rulesJsonLogic : {$last: '$rulesJsonLogic'},
	   createdBy : {$last: '$createdBy'},
	   createdDate : {$last: '$createdDate'},
	   rule_status : {$last: '$rule_status'},
	   ruleid:{$last:'$_id'}
	   }},
	   { $sort : { createdDate:-1} }
	],(err, result) => {
		 if (err) return cb(err)
		// console.log(result);
		 cb(null, result);
	});
			
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Model start   
ruleengineModel.ruleenginegetruleengineById = function(ruleID, cb) {
	var dbConn = db.get();
	let whereCond = {};

	whereCond = {'_id':ObjectID(ruleID)}; 
	dbConn.ruleengine.find(whereCond,(err, rule) => {
		if (err) return cb(err)
		cb(null, rule)
	});
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//ruleengineremove Model start   
ruleengineModel.ruleengineremove = function(accID, projID, fieldName,applicationJson, typeStr,cb) {
	var dbConn = db.get();
	 console.log('-------------delete-------------');
	dbConn.ruleengine.remove({'projectName':projID,'appendField':fieldName,'ruleFor':typeStr},(err, rule) => {
		if (err) {
			return cb(err);
		} else {
			dbConn.collection('account').update({'_id': ObjectID(accID),'project._projectid':ObjectID(projID)},
			{$set: { 'project.$.application': applicationJson }},function(err, result) {
				if (err) return cb(err);
				cb(null, result);
			});
		}
	});
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//getageRelaxationList aggregate Model start 
ruleengineModel.ruleengineageAggregate = function(projID,cb) {
	var dbConn = db.get(); 
	dbConn.account.aggregate(
		{ $unwind :'$project'},
		{ $match : {status: 'Active', 'project._projectid': ObjectID(projID),'project.status': 'Active' }},
		{ $project : { _id:1, accountName:1, projectid : '$project._projectid', projectName : '$project.projectName', projectDetails : '$project.projectDetails', projectIdentifier : '$project.projectIdentifier', projectServices : '$project.projectServices', projectComponents : '$project.projectComponents' } }
		,function( err, data ) { 
			if (err) return cb(err)
			cb(null, data)
		});
}

//getageRelaxationList find Model start   
ruleengineModel.ruleenginegetageRelaxationFind = function(data, cb) {
	var dbConn = appdb.get();
	dbConn.collection('age').find({},{}, function(err, result) {
		if (err) return cb(err);
		cb(null, result);
	});
}

//getageRelaxationList find Model start   
ruleengineModel.ruleengineagerelaxFind = function(data, cb) {
	var dbConn = appdb.get();
	 
	dbConn.collection('ageRelax').find()
	.sort({_id: -1})
	.toArray(function(err, ageRelres) {
		if (err) return cb(err)
		cb(null, ageRelres)
	});
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//addageruleengine aggregate Model start 
ruleengineModel.ruleengineaddageruleAggregate = function(projID,cb) {
	var dbConn = db.get(); 
	dbConn.account.aggregate(
		{ $unwind :'$project'},
		{ $match : {status: 'Active', 'project._projectid': ObjectID(projID),'project.status': 'Active' }},
		{ $project : { _id:1, accountName:1, projectid : '$project._projectid', projectName : '$project.projectName', projectDetails : '$project.projectDetails', projectIdentifier : '$project.projectIdentifier', projectServices : '$project.projectServices', projectComponents : '$project.projectComponents' } }
		,function( err, result ) {
			if (err) return cb(err);
			cb(null, result);
		});
}

//addageruleengine find Model start   
ruleengineModel.ruleengineaddageruleFind = function(data, cb) {
	var dbConn = appdb.get();
	dbConn.collection('age').find({},{}, function(err, result) {
		if (err) return cb(err)
		cb(null, result)
	});
}

//addageruleengine save Model start   
ruleengineModel.ruleengineageRelaxsave = function(data, cb) {
	var dbConn = appdb.get();
	 
	dbConn.ageRelax.save(data,{}, function(err, result) {
		if (err) return cb(err)
		cb(null, result)
	});
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//workexperience modal
ruleengineModel.ruleworkexpAddModel = function(projID,cb) {
	var dbConn = db.get(); 
	dbConn.account.aggregate(
		{ $unwind :'$project'},
				{ $match : {status: 'Active', 'project._projectid': ObjectID(projID),'project.status': 'Active' }},
				{ $project : { _id:1, accountName:1, projectid : '$project._projectid', projectName : '$project.projectName', projectDetails : '$project.projectDetails', projectIdentifier : '$project.projectIdentifier', projectServices : '$project.projectServices', projectComponents : '$project.projectComponents' } }
		,function( err, result ) { 
			if (err) return cb(err)
			cb(null, result)
		});	
}

ruleengineModel.ruleworkexpAddModelSave = function(data,{}, cb) {
	var dbConn = appdb.get();
	 
	dbConn.workexp.save(data,{}, function(err, result) {
		if (err) return cb(err)
		cb(null, result)
	});
}

ruleengineModel.ruleworkexpEditModel = function(projID,cb) {
	var dbConn = db.get(); 
	dbConn.account.aggregate(
		{ $unwind :'$project'},
			{ $match : {status: 'Active', 'project._projectid': ObjectID(projID),'project.status': 'Active' }},
			{ $project : { _id:1, accountName:1, projectid : '$project._projectid', projectName : '$project.projectName', projectDetails : '$project.projectDetails', projectIdentifier : '$project.projectIdentifier', projectServices : '$project.projectServices', projectComponents : '$project.projectComponents' } }
		,function( err, result ) { 
			if (err) return cb(err)
			cb(null, result)
		});	
}

ruleengineModel.ruleengineworkexpFind = function(data, cb) {
	var dbConn = appdb.get();
	dbConn.collection('workexp').find({},{}, function(err, result) {
		if (err) return cb(err);
		cb(null, result);
	});
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


module.exports = ruleengineModel;