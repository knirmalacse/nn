var db = require('../db/db');
const ObjectID = require("mongodb").ObjectID;

let aclModel = {};

aclModel.acl = function(data, aclId, cb) {
	var dbConn = db.get();
	
	if(aclId != '') {
		dbConn.collection('acl').update(
		{'_id': ObjectID(aclId) },
		{ "$set": { "access": data.access}},
		function(err, result) {
			if (err) return cb(err)
			cb(null, result)
		});
	} else {
		dbConn.acl.save(data,{},
		function(err, result) {
			if (err) return cb(err)
			cb(null, result)
		});
	}
	
}
aclModel.aclGet = function(data, cb) {
	var dbConn = db.get();
	
	dbConn.acl.find({'roleID':data}).sort({_id:-1}).limit(1, 
	function(err, result) {
		if (err) return cb(err)
		cb(null, result)
	});
}
module.exports = aclModel;