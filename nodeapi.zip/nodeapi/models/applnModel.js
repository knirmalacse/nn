var db = require('../db/db');
const ObjectID = require("mongodb").ObjectID;

let applnModel = {};

applnModel.saveAppln = function(accountId, projectId, applnSjon, logUser, cb) {
	
	var dbConn = db.get();
	var applicationJson = {
		_applnid:ObjectID(),
		projectJson:applnSjon,
		status:'Active',
		createdBy:'User',
		createdDate:new Date(Date.now()),
		
	}
	 
	dbConn.collection('account').update(
	{'_id': ObjectID(accountId),'project._projectid':ObjectID(projectId)},
	{$set: { 'project.$.application': applicationJson }}, 
	function(err, result) {
		if (err) return cb(err)
		cb(null, result)
	});
}

applnModel.getAppln = function(accountId, projectId, cb) {
	
	var dbConn = db.get();
	dbConn.account.aggregate(
	{ $unwind :'$project'},
	{ $match : {_id: ObjectID(accountId), status: 'Active','project._projectid':ObjectID(projectId),'project.status':'Active','project.application.status':'Active' }},
	{ $project : { _id:1, accountName:1, projectid : '$project._projectid', projectName : '$project.projectName', applicationJson : '$project.application.projectJson',ProjectIdentifier:'$project.projectIdentifier' } } ,(err, data) => {
		if (err) return cb(err)
		cb(null, data)
	});
}

applnModel.getAccounts = function( cb) {
	
	var dbConn = db.get();
	dbConn.account.find({status : 'Active'},{"accountName":1,_id:1},(err, accounts) => {
		if (err) return cb(err)
		cb(null, accounts)
	});
}

applnModel.getAccProject = function(accountID, cb) {
	
	var dbConn = db.get();
	dbConn.account.aggregate(
	{ $unwind :'$project'},
	{ $match : {_id: ObjectID(accountID), status: 'Active','project.status': 'Active' }},
	{ $project : { _id:1, accountName:1, projectid : '$project._projectid', projectName : '$project.projectName' } }
	,function( err, data ) {
		if (err) return cb(err)
		cb(null, data)
	});
}


module.exports = applnModel;