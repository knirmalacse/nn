var db = require('../db/db');
const ObjectID = require("mongodb").ObjectID;

let emailSettingModel = {

	 
}; 

module.exports = emailSettingModel;