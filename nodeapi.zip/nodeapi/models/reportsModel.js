var db = require('../db/db');
var appdb = require('../db/appdb');
const ObjectID = require("mongodb").ObjectID;

let reportsModel = {};

reportsModel.getFieldWiseReportsEmpty = function(selectedFld, cb) {
	var dbConn = appdb.get();
	/* dbConn.registration.aggregate( [ 
	{ $match: { $or: [ { selectedFld: '' }, { selectedFld: null } ] } },
	{ $group : { _id : "Not Selected",count: { $sum: 1 } } } 
	] ,(err, result) => {
		if (err) return cb(err)
		cb(null, result)
	}) */
	let selField = "$"+selectedFld;
	var params = {};
	params[selectedFld] = '';
	var params1 = {};
	params1[selectedFld] = null;
	dbConn.registration.aggregate(
	{ $match: {  $or: [  params ,  params1  ]  } },//{ category: '' }, { category: null }
	{"$facet": {
		"Complete": [ {"$match" : {"formio_applstatus":"C"}},{ $group : { _id : selField,count: { $sum: 1 } } },],
		"InComplete": [ {"$match" : {"formio_applstatus":"IC"}},{ $group : { _id : selField,count: { $sum: 1 } } },],
		"Paid": [ { $match: { $and: [ { formio_applstatus: 'C' }, { formio_paystatus: 'Y' }]}},{ $group : { _id : selField,count: { $sum: 1 } } },],
		"Unpaid": [ { $match: { $and: [ { formio_applstatus: 'C' }, { formio_paystatus: 'N' }]}},{ $group : { _id : selField,count: { $sum: 1 } } },],
	}}
	,(err, result) => {
		if (err) return cb(err)
		cb(null, result)
	});

}
reportsModel.getFieldWiseReportsAll = function(selectedFld, cb) {
	var dbConn = appdb.get();
	/* dbConn.registration.aggregate( [ 
	{ $match: { $and: [ { formio_applstatus: 'C' }, { formio_paystatus: 'Y' } , {category : {$ne : ''}}, {category : {$ne : null}}] } },
	{ $group : { _id : "$category",count: { $sum: 1 } } } 
	] ,(err, result) => {
		if (err) return cb(err)
		cb(null, result)
	}) */
	let selField = "$"+selectedFld;
	var params = {};
	params[selectedFld] = {$ne : ''};
	var params1 = {};
	params1[selectedFld] = {$ne : null};
	dbConn.registration.aggregate(
	{ $match: { $and: [  params ,  params1  ] } },//{category : {$ne : ''}}, {category : {$ne : null}}
	{"$facet": {
		"Complete": [ {"$match" : {"formio_applstatus":"C"}},{ $group : { _id : selField,count: { $sum: 1 } } },],
		"InComplete": [ {"$match" : {"formio_applstatus":"IC"}},{ $group : { _id : selField,count: { $sum: 1 } } },],
		"Paid": [ { $match: { $and: [ { formio_applstatus: 'C' }, { formio_paystatus: 'Y' }]}},{ $group : { _id : selField,count: { $sum: 1 } } },],
		"Unpaid": [ { $match: { $and: [ { formio_applstatus: 'C' }, { formio_paystatus: 'N' }]}},{ $group : { _id : selField,count: { $sum: 1 } } },],
	}}
	,(err, result) => {
		if (err) return cb(err)
		cb(null, result)
	});	

}

reportsModel.getDatadownloadReport = function(selectedFld,fldValue,type,section, cb) {
	var dbConn = appdb.get();
	
	let whereCond = {};
	if(type == 'MS'){
		whereCond[selectedFld] = fldValue;
	} else if(type == 'MNS') {
		var params = {};
		params[selectedFld] = '';
		var params1 = {};
		params1[selectedFld] = null;
		let orVar = '$or';
		whereCond[orVar] = [];
		whereCond[orVar].push(params);
		whereCond[orVar].push(params1);
	}
	
	if(section == 'completed') {
		whereCond['formio_applstatus'] = 'C';
	}else if(section == 'incomplete') {
		whereCond['formio_applstatus'] = 'IC';
	}else if(section == 'paid') {
		whereCond['formio_applstatus'] = 'C';
		whereCond['formio_paystatus'] = 'Y';
	}else if(section == 'unpaid') {
		whereCond['formio_applstatus'] = 'C';
		whereCond['formio_paystatus'] = 'N';
	}
	
	dbConn.registration.find(
	whereCond,{'_id':0}
	,(err, result) => {
		if (err) return cb(err)
		cb(null, result)
	});	
	
}

module.exports = reportsModel;