var db = require('../db/db');
var appdb = require('../db/appdb');
const ObjectID = require("mongodb").ObjectID;

let depModel = {};

depModel.tblDatas = function(selectedFld,records, cb) {
	var dbConn = appdb.get();
	
	dbConn[selectedFld].save(records,{}, function(err, docs) {
		if (err) return cb(err)
		//console.log(docs[0]);
		cb(null, docs)
	});
}
depModel.gettblDatas = function(selectedFld, cb) {
	var dbConn = appdb.get();
	
	dbConn[selectedFld].find({},{_id: 0}, function(err, docs) {
		if (err) return cb(err)
		//console.log(docs[0]);
		cb(null, docs)
	});
}
depModel.saveMapping = function(records, cb) {
	var dbConn = appdb.get();
	
	dbConn.dataMapping.count({$and : [
        { parentField: records.parentField },
        { childField: records.childField }
    ]}, function(err, docs) {
		if (err) return cb(err)
		else if (docs == 0) {
			dbConn.dataMapping.save({parentField: records.parentField,childField: records.childField, mapping : [ {_mappingid:ObjectID(), parentData: records.parentData,childData: records.childData}]},{}, function(err, docs1) {
				if (err) return cb(err)
				cb(null, docs1)	
			});
		} else if (docs > 0) {
			dbConn.dataMapping.update(
			{ 
				$and : [{ parentField: records.parentField },{ childField: records.childField } ]  
			},
			{
				$push: { mapping: { "_mappingid" : ObjectID(),parentData: records.parentData,	childData: records.childData} }
			}, function(err, docs2) {
				if (err) return cb(err)
				cb(null, docs2)
			});
		}
	});
}

module.exports = depModel;