var db = require('../db/db');
const ObjectID = require("mongodb").ObjectID;

let accountModel = {};

accountModel.accountAdd = function(data, logUser, cb) { 
	var dbConn = db.get(); 
	dbConn.account.save(data,{}, function(err, docs) {
		if (err) return cb(err)
		//console.log(docs[0]);
		cb(null, docs)
	});
}
accountModel.accountEdit = function(data, logUser, accountId, cb) {
	
	var dbConn = db.get();
	dbConn.collection('account').update({'_id': ObjectID(accountId)},
	{
		/* $currentDate:{
			updatedDate:{$type:"timestamp"}
		}, */
		$set: data
	},function(err, result) {
		if (err) return cb(err)
		cb(null, result)
	});
}
accountModel.accountStatus = function(accountId, accountStatus, logUser, cb) {
	
	var dbConn = db.get();
	dbConn.collection('account').update({'_id': ObjectID(accountId)},
	{
		$currentDate:{
			updatedDate:{$type:"timestamp"}
		},
		$set: { status: accountStatus, updatedBy : logUser }
	},function(err, result) {
		if (err) return cb(result)
		cb(null, result)
	});
}

accountModel.accountDel = function(accountId, logUser, cb) {
	
	var dbConn = db.get();
	dbConn.collection('account').update({'_id': ObjectID(accountId)},
	{
		$currentDate:{
			updatedDate:{$type:"timestamp"}
		},
		$set: { isDeleted: 1, updatedBy : logUser }
	},function(err, result) {
		if (err) return cb(result)
		cb(null, result)
	});
}

accountModel.accountData = function(accountId, cb) {
	
	var dbConn = db.get();
	let whereCond = {};
	if(accountId) {
		whereCond = {'_id': ObjectID(accountId),  status : 'Active'};
	} else {
		whereCond = { isDeleted : 0};
	}
	dbConn.account.find(whereCond,(err, account) => {
		if (err) return cb(err)
		cb(null, account)
	});
}

accountModel.accountDBAggregate = function(offset,items_per_page,AccIDVal,cb) {
	
	var dbConn = db.get(); 
	var matchCond = {};
	if (AccIDVal !== ''){
		matchCond = {'_id': ObjectID(AccIDVal),status : 'Active' };
	} else {
		matchCond = {status : 'Active' };
	}
	dbConn.account.aggregate(
	{ $match : matchCond},
	{ $project: { 
		projectCount: {  "$size": { "$ifNull": [ "$project", [] ] } },_id:1, accountName:1,accountDetails:1,accountDomain:1,isDeleted:1,name: 1, project: { $slice: [ "$project", offset,items_per_page ]} }
	},
	{$sort: { '_id':-1 }},
	(err, accounts) => { 
		if (err) return cb(err)
		cb(null, accounts)
	});
}

accountModel.getAccountDetails = function(projectId,cb) {
	
	var dbConn = db.get(); 
	var matchCond = {};
	
	dbConn.account.find(
		{'project._projectid':ObjectID(projectId)},
		{_id:1,accountName:1},
	(err, accounts) => { 
		if (err) return cb(err)
		cb(null, accounts)
	});
}

accountModel.get = function(email, passwd, cb) {
	
	var dbConn = db.get();
	dbConn.account.find({}, function(err, docs) {
	if (err) return cb(err)
	//console.log(docs[0]);
	cb(null, docs[0])
	});
}

module.exports = accountModel;