var db = require('../db/db');
var appdb = require('../db/appdb');
const ObjectID = require("mongodb").ObjectID;

let projModel = {};
const lowerCaseChange = (s) => {
  if (typeof s !== 'string') return ''
  //return s.charAt(0).toUpperCase() + s.slice(1) // 1st letter uppercase
  return s.toLowerCase() // all letter lowercase
}
projModel.projectEdit = function(accID, projID, data, userName,genericService,genericComponent, cb) {
	
	var dbConn = db.get();
	dbConn.collection('account').update(
	{'_id': ObjectID(accID), "project._projectid": ObjectID(projID) },
	{ "$set": { "project.$.projectName": data.projectName,"project.$.projectIdentifier": lowerCaseChange(data.projectIdentifier),"project.$.projectDetails": data.projectDetails, "project.$.updatedBy":userName,"project.$.updatedDate":new Date(Date.now()),"project.$.projectServices": genericService,"project.$.projectComponents": genericComponent }},
	function(err, result) {
		if (err) return cb(err)
		cb(null, result)
	});
}

projModel.projectAdd = function(accID, data, userName,genericService,genericComponent, cb) {
	 
	var dbConn = db.get();
	var projectStore = {
		_projectid:ObjectID(),
		projectName:data.projectName,
		projectIdentifier:lowerCaseChange(data.projectIdentifier),
		projectDetails:data.projectDetails,
		status:'Active',
		createdBy:userName,
		//updatedBy: userName,
		createdDate:new Date(Date.now()),
		//updatedDate:new Date(Date.now()),
		projectServices:genericService,
		projectComponents:genericComponent,
		
	}
	dbConn.collection('account').update(
	{'_id': ObjectID(accID)},
	{$push: { project: projectStore }},
	function(err, result) {
		if (err) return cb(err)
		cb(null, result)
	});
}
projModel.createDbAdminuser = function(data, cb) {
	console.log('conteorller 33333333333');
	console.log(data);
	var dbConn = appdb.get();
	dbConn.admin_users.save(data,{}, function(err, result) {
			if (err) return cb(err)
			cb(null, result)
	});
	
}

projModel.projectDel = function(accID, projID, userName, cb) {
	
	var dbConn = db.get();
	dbConn.collection('account').update(
	{'_id': ObjectID(accID), "project._projectid": ObjectID(projID)},
	{$set: { "project.$.status": 'Deleted', 'updatedBy':userName, 'updatedDate':new Date(Date.now()) }},
	function(err, result) {
		if (err) return cb(err)
		cb(null, result)
	});
}

projModel.getProject = function(accID, projID, cb) {
	 	 
	var dbConn = db.get();
	let matchCond = {status : 'Active', 'project.status' : 'Active' };
	if(accID && projID) {
		matchCond = {_id: ObjectID(accID), status: 'Active', 'project._projectid': ObjectID(projID),'project.status': 'Active' };
	}
	dbConn.account.aggregate(
	{ $unwind :'$project'},
	{ $match : matchCond},
	{ $project : { _id:1, accountName:1, projectid : '$project._projectid', projectName : '$project.projectName', projectDetails : '$project.projectDetails', projectIdentifier : '$project.projectIdentifier', projectServices : '$project.projectServices', projectComponents : '$project.projectComponents' } },
	function(err, result) {
		if (err) return cb(err)
		cb(null, result)
	});
}

projModel.getProjectDetail = function(projID, cb) {
	
	var dbConn = db.get();
	let matchCond = {status : 'Active', 'project.status' : 'Active' };
	if(projID) {
		matchCond = {status: 'Active', 'project._projectid': ObjectID(projID),'project.status': 'Active' };
	}
	dbConn.account.aggregate(
	{ $unwind :'$project'},
	{ $match : matchCond},
	{ $project : { _id:1, accountName:1, projectid : '$project._projectid', projectName : '$project.projectName', projectDetails : '$project.projectDetails', projectIdentifier : '$project.projectIdentifier', projectServices : '$project.projectServices', projectComponents : '$project.projectComponents' } },
	function(err, result) {
		if (err) return cb(err)
		cb(null, result)
	});
}

projModel.saveProjectSetting = function(reqData, cb) {
	console.log('---7777---');
	var dbConn = appdb.get();
	let appStartDate = reqData['appStartDate']['formatted'];
	let appEndDate = reqData['appStartDate']['appEndDate'];
	let appPrintDate = reqData['appStartDate']['appPrintCloseDate'];
	
/* 	reqData['appStartDate'] = appStartDate;
	reqData['appEndDate'] = appEndDate;
	reqData['appPrintCloseDate'] = appPrintDate; */
	delete reqData['formData'];
	delete reqData['logoUp'];
	dbConn.appl_config.save(reqData,{},
	function(err, result) {
		console.log(err);
		if (err) return cb(err)
		cb(null, result)
	});
}

projModel.getProjectSetting = function(cb) {
	var dbConn = appdb.get();
	dbConn.appl_config.find().sort({_id:-1}).limit(1,
	function(err, result) {
		if (err) return cb(err)
		cb(null, result)
	});
}

module.exports = projModel;