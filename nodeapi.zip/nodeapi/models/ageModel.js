var db = require('../db/db');
var appdb = require('../db/appdb');
const ObjectID = require("mongodb").ObjectID;

let ageModel = {};

ageModel.getAgeConfig = function(projID, cb) {
	var dbConn = appdb.get();
	dbConn.age.find({'PID': projID, status : 'Active'},(err, result) => {
		if (err) return cb(err)
		cb(null, result)
	})
}

ageModel.saveAgeConfig = function(data,dataId, cb) {
	var dbConn = appdb.get();
	if(dataId != '') {
		dbConn.collection('age').update({'_id': ObjectID(dataId)},
		{
			$currentDate:{
				updatedDate:{$type:"timestamp"}
			},
			$set: data
		},
		function(err, result) {
			if (err) return cb(err)
			cb(null, result)
		});
	} else {
		dbConn.age.save(data,{}, function(err, result) {
			if (err) return cb(err)
			cb(null, result)
		});
	}
	
}


module.exports = ageModel;