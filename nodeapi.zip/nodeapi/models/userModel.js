var db = require('../db/db');
const ObjectID = require("mongodb").ObjectID;

let userModel = {};

userModel.userAdd = function(data, logUser, cb) {
	
	var dbConn = db.get();
	
	dbConn.users.save(data,{}, function(err, docs) {
		if (err) return cb(err)
		//console.log(docs[0]);
		cb(null, docs)
	});
}
userModel.userEdit = function(data, logUser, regID, cb) {
	
	var dbConn = db.get();
	dbConn.collection('users').update({'_id': ObjectID(regID)},
	{
		$currentDate:{
			updatedDate:{$type:"timestamp"}
		},
		$set: data
	},function(err, result) {
		if (err) return cb(result)
		cb(null, result)
	});
}
userModel.userStatus = function(userId, userStatus, logUser, cb) {
	
	var dbConn = db.get();
	dbConn.collection('users').update({'_id': ObjectID(userId)},
	{
		$currentDate:{
			updatedDate:{$type:"timestamp"}
		},
		$set: { status: userStatus, updatedBy : logUser }
	},function(err, result) {
		if (err) return cb(result)
		cb(null, result)
	});
}

userModel.userDel = function(userId, logUser, cb) {
	
	var dbConn = db.get();
	dbConn.collection('users').update({'_id': ObjectID(userId)},
	{
		$currentDate:{
			updatedDate:{$type:"timestamp"}
		},
		$set: { isDeleted: 1, updatedBy : logUser }
	},function(err, result) {
		if (err) return cb(result)
		cb(null, result)
	});
}
userModel.otpStatusChange=function(rowId, otpStatus, cb){
	var dbConn = db.get();
	dbConn.collection('otpsecure').update({'_id': ObjectID(rowId)},
	{
		$currentDate:{
			updatedDate:{$type:"timestamp"}
		},
		$set: { status: otpStatus}
	},function(err, result) {
		if (err) return cb(result)
		cb(null, result)
	});
}
userModel.userData = function(userId, cb) {
	
	var dbConn = db.get();
	let whereCond = {};
	if(userId) {
		whereCond = {'_id': ObjectID(userId), isDeleted : 0};
	} else {
		whereCond = { isDeleted : 0};
	}
	dbConn.users.find(whereCond,(err, users) => {
		if (err) return cb(err)
		cb(null, users)
	});
}

userModel.get = function(email, passwd, cb) {
	
	var dbConn = db.get();
	//dbConn.users.find({EmailID: email,Password: passwd}, function(err, docs) {
	dbConn.users.find({EmailID: email}, function(err, docs) {
	if (err) return cb(err)
	//console.log(docs[0]);
	cb(null, docs[0])
	});
}

userModel.getUserRole = function(role, cb) {
	
	var dbConn = db.get();
	dbConn.acl.find({isDeleted : 0}, {role:role},(err, role) => {
		if (err) return cb(err)
		cb(null, role)
	});
}

userModel.createUserRole = function(data, logUser, cb) {
	
	var dbConn = db.get();
	dbConn.acl.save(data,{}, function(err, role) {
		if (err) return cb(err)
		cb(null, role)
	});
}

userModel.editUserRole = function(data, roleID, logUser, cb) {
	
	var dbConn = db.get();
	dbConn.acl.update({'_id': ObjectID(roleID._id)},
	{
		$currentDate:{
			updatedDate:{$type:"timestamp"}
		},
		$set: { role: data}
	},function(err, result) {
		if (err) return cb(err)
		cb(null, result)
	});
}

userModel.userRoleData = function(roleID, logUser, cb) {
	
	var dbConn = db.get();
	dbConn.acl.find({roleID : roleID},{ access: 1, _id: 0 },(err, acl) => {
		if (err) return cb(err)
		cb(null, acl)
	});
}

userModel.getUserAccess = function(permID, cb) {
	
	var dbConn = db.get();
	dbConn.acl.find({'_id': ObjectID(permID)/* , status : 'Active' */},(err, acl) => {
		if (err) return cb(err)
		cb(null, acl)
	});
}

userModel.editUserAccess = function(data, accessId, cb) {
	
	var dbConn = db.get();
	dbConn.acl.update({'_id': ObjectID(accessId._id)},
	{
		$currentDate:{
			updatedDate:{$type:"timestamp"}
		},
		$set: { ACLSet: data}
	},(err, access) => {
		if (err) return cb(err)
		cb(null, access)
	});
}
////////////////////////forgot password Start////////////////
userModel.otpSave = function(data,  cb) {//new code generate in otpsecure collection
	
	var dbConn = db.get();
	
	dbConn.otpsecure.save(data, function(err, docs) {
		if (err) return cb(err)
		//console.log(docs[0]);
		cb(null, docs)
	});
}

userModel.userOtpValidate = function(email, fromdate, todate, cb) {///use entered code is valid or not
	
	var dbConn = db.get();
	dbConn.otpsecure.aggregate(
	{ $match : { ActivityDate: {$gte: todate, $lt: fromdate},EmailID : email,status : 'SENT' } },
    { $sort : { ActivityDate : -1 } }
	,(err, data) => {
		//console.log(data);
		if (err) return cb(err)
		cb(null, data[0])
	});
}

userModel.userChagePassword = function(data, cb) {///After code validation password updated in user collection against entered mail id
	
	var dbConn = db.get();
	dbConn.collection('users').update({'EmailID': data.EmailID},
	{
		$currentDate:{
			updatedDate:{$type:"timestamp"}
		},
		$set: data
	},function(err, result) {
		if (err) return cb(result)
		cb(null, result)
	}); 
}
////////////////////////forgot password End////////////////
module.exports = userModel;