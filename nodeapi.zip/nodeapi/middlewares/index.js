let jwt = require('jsonwebtoken');
var request = require('request');
//const config = require('../config/config.json')[process.env.NODE_ENV || "development"];

let checkToken = (req, res, next) => {
  let token = req.headers['authorization']; // Express headers are auto converted to lowercase
  if (token.startsWith('Bearer ')) {
    // Remove Bearer from string
    token = token.slice(7, token.length);
  } 
  let Forbidden = {
	  status: 403,
	  message : "Forbidden"
	};
  if (token) {
	jwt.verify(token, config.API.secretKey, function(err, payload) {
		//console.log(payload)
		if (payload) {
			 req.payload = payload;
			next();
		} else {
			res.send(Forbidden);
		}
	});
  } else {
    return res.json({
      success: false,
      message: 'Auth token is not supplied'
    });
  }
};

checkCaptcha = function(req, res, next){
	var secretKey = "6Lc6QLAUAAAAAMTQYWF_pUqe5vycIPpO1ymB_-2S";
	var verificationUrl = "https://www.google.com/recaptcha/api/siteverify?secret=" + secretKey + "&response=" + req.body['captcha'] + "&remoteip=" + req.connection.remoteAddress;
	request(verificationUrl,function(error,response,body) {
		body = JSON.parse(body);
		console.log(body);
		if(body.success !== undefined && !body.success) {
		  return res.json({"message":{'captcha':'Failed captcha verification'},"responseCode" : 1,"responseDesc" : "Failed captcha verification"});
		}
		//res.json({"responseCode" : 0,"responseDesc" : "Sucess"});
		next();
	});
}


module.exports = {
  checkToken: checkToken,
  checkCaptcha: checkCaptcha
}