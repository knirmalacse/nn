var express = require('express');
const ObjectID = require("mongodb").ObjectID;

const mongojs = require("mongojs");

var reportsModel = require('../models/reportsModel'); 
var projModel = require('../models/projModel');
var activityLog = require('../helpers/log_function');
//const config = require('../config/config.json')[process.env.NODE_ENV || "development"];
const jwt = require('jsonwebtoken');
var appdb = require('../db/appdb');

let reportsController = {};
var acppassport = require('../acppassport');

let response = {
 status: 200,
 data: [],
 message: null,
 success: false,
};



reportsController.getReportsFieldWise = function(req, res){
	var bodyLength = req.query; 
	
	let projID = bodyLength.projectId; 
	let selectedFld = bodyLength.selFldVal; 
	projModel.getProjectDetail(projID, function (err, data){
		let projectIdentifier = data[0].projectIdentifier;
		var applnDBConn = new Promise(function(resolve, reject) {
			appdb.connect(projectIdentifier,function(err) {
				 if (err) {
					reject(err);
				} else {
					resolve();
				}
			});
		});
		applnDBConn.then(function(){
			reportsModel.getFieldWiseReportsEmpty(selectedFld,function(err, result) {
				if(result){
					reportsModel.getFieldWiseReportsAll(selectedFld,function(err, result1) {
						if(result1){
								let reportDetails = {
									'notselected' : {
										'completed' : result['0']['Complete'].length > 0?result['0'].Complete[0]['count']:0,
										'incomplete' : result['0']['InComplete'].length > 0?getIncompleteCount(result['0'].InComplete):0,
										'paid' : result['0']['Paid'].length > 0?result['0'].Paid[0]['count']:0,
										'unpaid' : result['0']['Unpaid'].length > 0?result['0'].Unpaid[0]['count']:0,
									},
									'others' : {
										'completed' : result1['0']['Complete'].length > 0?getOthersCount(result1['0'].Complete):0,
										'incomplete' : result1['0']['InComplete'].length > 0?getOthersCount(result1['0'].InComplete):0,
										'paid' : result1['0']['Paid'].length > 0?getOthersCount(result1['0'].Paid):0,
										'unpaid' : result1['0']['Unpaid'].length > 0?getOthersCount(result1['0'].Unpaid):0,
									}
								}; 
							//console.log(reportDetails);
							response.message = '';
							response.data = reportDetails;
							response.success = true;
							res.send(response);
						} else {
							response.message = err;
							response.data = {};
							response.success = false;
							res.send(response);
						}
					})
				}else {
					response.message = err;
					response.data = {};
					response.success = false;
					res.send(response);
				}
			});
		})
		.catch(function(err){
			response.message = err;
			response.data = {};
			response.success = false;
			res.send(response);
		});
		
		/* appdb.connect(projectIdentifier,function(err) {
			if (err) {
				//console.log('Unable to connect to Mongo.')
				//process.exit(1)
			}else{
				acpModel.getAdminUser('',function(err, result) {
					if(result){
						//jsonLogObj['ActivityDataID'] = result._id;
						//delete jsonLogObj['_id'];
						//logFunct.createUpdateLog(jsonLogObj,db,fs,configJSON.ActivityLog);
						//response.message = "Settings saved successfully";
						response.data = result;
						response.success = true;
						res.send(response);
					}else {
						response.data = {};
						response.success = true;
						res.send(response);
					}
				});
			}
		}); */
	});		
}
reportsController.getDownloadDataFieldWise = function(req,res){
	var bodyLength = req.query;
	
	let projID = bodyLength.projectId; 
	let selectedField = bodyLength.selectedField; 
	let fldArr = selectedField.split('-');
	let type = bodyLength.type; 
	let section = bodyLength.section; //completed,incomplete,paid
	let fldValue = bodyLength.fldValue; 
	console.log(selectedField,type,section,fldValue);
	projModel.getProjectDetail(projID, function (err, data){
		let projectIdentifier = data[0].projectIdentifier;
		var applnDBConn = new Promise(function(resolve, reject) {
			appdb.connect(projectIdentifier,function(err) {
				 if (err) {
					reject(err);
				} else {
					resolve();
				}
			});
		});
		applnDBConn.then(function(){
			reportsModel.getDatadownloadReport(fldArr[1],fldValue,type,section,function(err, result) {
				if(result.length > 0) {
					let headerData = Object.keys(result['0']);
					response.data = { 'csvHeader': headerData, 'list' : result};
					response.success = true;
					res.send(response);
				} else {
					response.message = err;
					response.data = {};
					response.success = false;
					res.send(response);
				}
			});
		})
		.catch(function(err){
			response.message = err;
			response.data = {};
			response.success = false;
			res.send(response);
		});
	});
}

function getIncompleteCount(datas) {
	let totCount = 0;
	for (data of datas) {
		totCount = totCount + data.count;
	}
	return totCount;
}
function getOthersCount(datas) {
	let rtnData = [];
	for (data of datas) {
		//console.log(data['_id']);
		let dataObj = {};
		dataObj[data['_id']] = data.count;
		rtnData.push(dataObj);
	}
	return rtnData;
}

module.exports = reportsController;