var express = require('express'); 
var ruleengineModel = require('../models/ruleengineModel');
var ageModel = require('../models/ageModel');
var activityLog = require('../helpers/log_function');
//const config = require('../config/config.json')[process.env.NODE_ENV || "development"];
const jwt = require('jsonwebtoken');
var appdb = require('../db/appdb');

let ageController = {};
let response = {
 status: 200,
 data: [],
 message: null,
 success: false,
};

ageController.saveAgeConfig = function(req, res){
	const acctID = JSON.parse(req.body.AID);
	const projID = JSON.parse(req.body.PID);
	const ID = JSON.parse(req.body.ID);
	
	req.body.AID = acctID;
	req.body.PID = projID;
	//jsonLogObj = req.body;
	//jsonLogObj["ActivityCollectionName"] = "age";
	//jsonLogObj["ActivityDate"] = new Date(Date.now());
	req.body.status = 'Active';
	req.body.createdDate = new Date(Date.now());
	if(projID) {
		ruleengineModel.ruleengineageAggregate(projID,function (err, data) {
			if(err){
				response.data = '';
				response.message = err;
				response.success =  false;
				res.json(response);
			}else{ 
				let projectIdentifier = data[0].projectIdentifier;
				var applnDBConn = new Promise(function(resolve, reject) {
					appdb.connect(projectIdentifier,function(err) {
						 if (err) {
							reject(err);
						} else {
							resolve();
						}
					});
				});
				applnDBConn.then(function(){
					const getFormValueInArray = JSON.parse(req.body.formJSON)
					var ageConfigFinalArray={};
					var rows="1";
					getFormValueInArray.forEach(function(element) {
						temparray={};
						temparray['ageAsonDate']=element.ageAsonDate.formatted;//mm/dd/yyyy
						temparray['ageMinDate']=element.ageMinDate.formatted;//mm/dd/yyyy
						temparray['ageMaxDate']=element.ageMaxDate.formatted;//mm/dd/yyyy
						temparray['ageMin']=element.ageMin;
						temparray['ageMax']=element.ageMax;
						temparray['ageRel']=element.ageRel;
						ageConfigFinalArray[rows]=temparray;
						rows++;
					});
					req.body.formJSON = JSON.parse(req.body.formJSON);
					req.body.genFormJSON = ageConfigFinalArray;
					req.body.ageArrayCount = (rows-1);
					
					if(ID) {
						//jsonLogObj['ActivityDataID'] = ObjectID(ID);
						//if(jsonLogObj['_id']) delete jsonLogObj['_id'];
						//jsonLogObj['ActivityDataType'] = "Update";
						ageModel.saveAgeConfig(req.body,ID,function (err, result) {
							if(err){
								//jsonLogObj["ActivityError"] =  "{ error: "+err.stack+" }";
								//logFunct.QryErrorLogFn(jsonLogObj,fs);
							}else{
								if(result){
									//logFunct.createUpdateLog(jsonLogObj,db,fs,configJSON.ActivityLog);
								}
							}
							response.message = "Age updated successfully";
							response.success = true;
							res.json(response);
						});
					} else {
						ageModel.saveAgeConfig(req.body,'',function (err, result) {
							if(err){
								//jsonLogObj["ActivityError"] =  "{ error: "+err.stack+" }";
								//logFunct.QryErrorLogFn(jsonLogObj,fs);
							}else{
								if(result){
									response.message = "Age saved successfully";
									response.data = result;
									response.success = true;
									res.json(response);
								}
							}
						});
					}
				});
			}
		});
	}
}

ageController.getAgeConfig = function(req, res){
	const acctID = JSON.parse(req.query.AID);
	const projID = JSON.parse(req.query.PID);
	
	if(projID) {
		ruleengineModel.ruleengineageAggregate(projID,function (err, data) {
			if(err){
				response.data = '';
				response.message = err;
				response.success =  false;
				res.json(response);
			}else{ 
				let projectIdentifier = data[0].projectIdentifier;
				var applnDBConn = new Promise(function(resolve, reject) {
					appdb.connect(projectIdentifier,function(err) {
						 if (err) {
							reject(err);
						} else {
							resolve();
						}
					});
				});
				applnDBConn.then(function(){
					var bodyLength = req.query;
					if (bodyLength.hasOwnProperty("PID")){  
						ageModel.getAgeConfig(projID,function (err, result) {
							if (err) return next(err);
							else if(result && result[0]){
								response.data = result[0];
								response.success =  true;
								response.message = '';
							}
							else {
								response.success =  false;
								response.data = '';
								response.message = '';
							}
							res.json(response);
						});
					} else {
						response.data = '';
						response.message = 'Invalid API';
						response.success =  false;
						res.json(response);
					}
				},function(err) {
						response.data = '';
						response.message = err;
						response.success =  false;
						res.json(response);
				});
			}
		});
	}
}

module.exports = ageController;