var express = require('express'); 
//var dependentModel = require('../models/dependentModel');
var activityLog = require('../helpers/log_function');
//const config = require('../config/config.json')[process.env.NODE_ENV || "development"];
const jwt = require('jsonwebtoken');
var appdb = require('../db/appdb');
var projModel = require('../models/projModel');
var depModel = require('../models/depModel');

const csv = require('csv-parser');
const fs = require('fs');
const multer = require('multer');

const upload = multer();

let dependentController = {};
let response = {
 status: 200,
 data: [],
 message: null,
 success: false,
};


dependentController.getFldData = function(req, res){
	var postData = req.body; 
	
	let projID = postData.projectId; 
	let selectedFld = postData.fldName;
	projModel.getProjectDetail(projID, function (err, data){
		let projectIdentifier = data[0].projectIdentifier;
		var applnDBConn = new Promise(function(resolve, reject) {
			appdb.connect(projectIdentifier,function(err) {
				 if (err) {
					reject(err);
				} else {
					resolve();
				}
			});
		});
		applnDBConn.then(function(){
			depModel.gettblDatas(selectedFld, function(err, result) {
				//console.log(result);
				if(err) {
					response.message = err;
					response.data = {};
					response.success = false;
				} else if(result.length > 0) {
					response.message = 'Success';
					response.data = result;
					response.success = true;
				}
				res.send(response);
			});
			
		})
		.catch(function(err){
			response.message = err;
			response.data = {};
			response.success = false;
			res.send(response);
		});
	});	
	
	/* if(req.query.state == 'State 1'){
		response.data = ['District 1'];
	} else if(req.query.state == 'State 2'){
		response.data = ['District 2'];
	} else if(req.query.state == 'State 3'){
		response.data = ['District 3'];
	}
	res.send(response); */
}
dependentController.saveFldData = function(req, res){
	//console.log(req.body);
	//console.log(req.file);
	
	var postData = req.body; 
	
	let projID = postData.projectId; 
	let selectedFld = postData.depField; 
	projModel.getProjectDetail(projID, function (err, data){
		let projectIdentifier = data[0].projectIdentifier;
		var applnDBConn = new Promise(function(resolve, reject) {
			appdb.connect(projectIdentifier,function(err) {
				 if (err) {
					reject(err);
				} else {
					resolve();
				}
			});
		});
		applnDBConn.then(function(){
			let dbDatas = [];
			fs.createReadStream(req.file.path)
			.pipe(csv())
			.on('data', (row) => {
				//console.log(row);
				dbDatas.push(row);
			})
			.on('end', () => {
				//console.log('CSV file successfully processed');
				//console.log(dbDatas);
				depModel.tblDatas(selectedFld, dbDatas, function(err, result) {
					//console.log(result);
					if(err) {
						response.message = err;
						response.data = {};
						response.success = false;
					} else if(result.length > 0) {
						response.message = 'data added successfully';
						response.data = result;
						response.success = true;
					}
					res.send(response);
				});
			});
			//res.send(response);
		})
		.catch(function(err){
			response.message = err;
			response.data = {};
			response.success = false;
			res.send(response);
		});
	});	
	
}

dependentController.dataMapping = function(req, res){
	try {
		var postData = req.body; 
	
		let projID = postData.projectId; 
		let formData = postData.formData; 
		projModel.getProjectDetail(projID, function (err, data){
			let projectIdentifier = data[0].projectIdentifier;
			var applnDBConn = new Promise(function(resolve, reject) {
				appdb.connect(projectIdentifier,function(err) {
					 if (err) {
						reject(err);
					} else {
						resolve();
					}
				});
			});
			applnDBConn.then(function(){
				depModel.saveMapping(formData, function(err, result) {
					if(err) {
						response.message = err;
						response.data = {};
						response.success = false;
					} else {
						response.message = 'Success';
						response.data = {};
						response.success = true;
					}
					res.send(response);
				});
				
			})
			.catch(function(err){
				response.message = err;
				response.data = {};
				response.success = false;
				res.send(response);
			});
		});	
	} catch (e) {
		response.message = e;
		response.data = {};
		response.success = false;
		res.send(response);
	}
	
	
}

module.exports = dependentController;