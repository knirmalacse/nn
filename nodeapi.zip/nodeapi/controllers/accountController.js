var express = require('express');
var accountModel = require('../models/accountModel');
var activityLog = require('../helpers/log_function');
//const config = require('../config/config.json')[process.env.NODE_ENV || "development"];
const jwt = require('jsonwebtoken');
 
let accountController = {};
let response = {
 status: 200,
 data: [],
 message: null,
 success: false,
};
 

accountController.createAccount = function(req, res){
	const accID = req.body.AID;
	const curUsrName = req.payload._id;
	req.body = JSON.parse(req.body.formJSON);	
	
	/* var jsonLogObj = '';
	jsonLogObj = req.body;
	jsonLogObj['ActivityUsername'] = req.session.usrName;
	jsonLogObj["ActivityCollectionName"] = "account";
	jsonLogObj["ActivityIpAddress"] = user_ip_address;
	jsonLogObj["ActivityDate"] = new Date(Date.now()); */

	if(accID){
		/* jsonLogObj['ActivityDataID'] = ObjectID(accID);
		if(jsonLogObj['_id']) delete jsonLogObj['_id']; */
		req.body.updatedBy = curUsrName;
		req.body.updatedDate = new Date(Date.now());
		//jsonLogObj['ActivityDataType'] = "Update";

		accountModel.accountEdit(req.body, curUsrName, accID , function (err, account) {
			if(err){
				//jsonLogObj["ActivityError"] =  "{ error: "+err.stack+" }";
				//activityLog.QryErrorLogFn(jsonLogObj);
				response.message = "Account update failed";
				response.success = false;
				res.send(response);
			}else{
				//jsonLogObj['ActivityDataID'] = user._id;
				//delete jsonLogObj['_id'];
				//activityLog.createUpdateLog(jsonLogObj,db,fs,config.ActivityLog);
				
				response.message = "Account updated successfully";
				response.success = true;
				res.send(response);
			}
		});	
	  
	} else { 
		req.body.status = 'Active'; 
		req.body.createdBy = curUsrName; 
		req.body.createdDate = new Date(Date.now()); 
		//jsonLogObj['ActivityDataType'] = "Insert";	
		accountModel.accountAdd(req.body, curUsrName , function (err, account) {
			if(err){
				//jsonLogObj["ActivityError"] =  "{ error: "+err.stack+" }";
				response.message = "Account added Failed";
				response.success = false;
				res.send(response);
			//	logFunct.QryErrorLogFn(jsonLogObj,fs);
			}else{
				if(account){
					//jsonLogObj['ActivityDataID'] = account._id; 
					//delete jsonLogObj['_id']; 
					//logFunct.createUpdateLog(jsonLogObj,db,fs,configJSON.ActivityLog); 
					response.message = "Account added successfully";
					response.success = true;
					res.send(response);
					
				}
			}
		 });  
	}
	
}

accountController.editAccount = function(req, res){
	const curUsrName = req.payload._id;
	userModel.accountStatus(req.body.AID, req.body.status, curUsrName , function (err, user) {
		if(err) {
			response.message = "Account Status change failed";
			response.success = false;
		} else {
			response.message = "Account Status changed successfully";
			response.success = true;
		}
		res.send(response);
	});
}

accountController.getAccount = function(req, res){
	var bodyLength = req.query;    
	if (bodyLength.hasOwnProperty("AID")){ 
		accountModel.accountData(req.query.AID, function (err, account) {
			response.message = "";
			if (err) {
				response.data = '';
				response.message = err;
				response.success =  false;
			} else if(account && account[0]){
				response.data = account[0];
				response.success =  true;
			} else {
				response.success =  false;
				response.data = '';
				response.message = 'API Failed';
			}
			res.send(response);
		});
		
	} else {  
		response.message = "";
		if (bodyLength.hasOwnProperty("pageNo")){  
			let items_per_page = 5;
			let offset = (req.query.pageNo - 1) * items_per_page;
			let AccIDVal = req.query.AccIDVal;
			if (AccIDVal !== ''){
				accountModel.accountDBAggregate(offset,items_per_page,AccIDVal,function (err, accounts) {
					response.data = accounts;
					res.json(response);
				}); 
			}else{ 
				accountModel.accountDBAggregate(0,items_per_page,'',function (err, accounts) {
					response.data = accounts;
					res.json(response);
				});
			}
		  
		}else{ 
			accountModel.accountData('', function (err, account) {
				if (err) {
					response.data = '';
					response.message = err;
					response.success =  false;
				} else if(account && account[0]){
					response.data = account[0];
					response.success =  true;
				} else {
					response.success =  false;
					response.data = '';
					response.message = 'API Failed';
				}
				res.send(response);
			}); 
		}
	}
}

accountController.deleteAccount = function(req, res){
	const curUsrName = req.payload._id; 
	/* jsonLogObj = req.query;
	jsonLogObj['ActivityUsername'] = payload.UserName;
	jsonLogObj["ActivityCollectionName"] = "users";
	jsonLogObj["ActivityIpAddress"] = user_ip_address;
	jsonLogObj["ActivityDate"] = new Date(Date.now());
	jsonLogObj['ActivityDataType'] = "Delete";
	jsonLogObj['ActivityDataID'] = ObjectID(curUsrName);
	
	if(jsonLogObj['_id']) delete jsonLogObj['_id']; */
	accountModel.accountDel(req.query.AID, curUsrName , function (err, account) {
		if(err) {
			//jsonLogObj["ActivityError"] =  "{ error: "+err.stack+" }";
			//logFunct.QryErrorLogFn(jsonLogObj,fs);
			response.message = "Account delete failed";
			response.success = false;
		} else {
			//logFunct.createUpdateLog(jsonLogObj,db,fs,configJSON.ActivityLog);
			response.message = "Account deleted successfully";
			response.success = true;
		}
		res.send(response);
	});
}

accountController.getAccountDetails = function(req, res){
	var bodyLength = req.query;    
	if (bodyLength.hasOwnProperty("projectId")){
		accountModel.getAccountDetails(req.query.projectId, function (err, account) {
			response.message = "";
			if (err) {
				response.data = '';
				response.message = err;
				response.success =  false;
			} else if(account && account[0]){
				response.data = account[0];
				response.success =  true;
			} else {
				response.success =  false;
				response.data = '';
				response.message = 'API Failed';
			}
			res.send(response);
		});
	}
}	

module.exports = accountController;