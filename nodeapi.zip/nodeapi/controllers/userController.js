var express = require('express');
var userModel = require('../models/userModel');
var activityLog = require('../helpers/log_function');
//const config = require('../config/config.json')[process.env.NODE_ENV || "development"];
const jwt = require('jsonwebtoken'); 
///password bcrypt starts//
const bcrypt = require('bcrypt');
const saltRounds = 10;
///password bcrypt ends//
var request = require('request');
///randomstring Start/////
var randomstring = require("randomstring");
///randomstring End/////
///date subtract and add strat///////
const addSubtractDate = require("add-subtract-date");
///date subtract and add End///////
///////////Api service include end/////
var APIservice = require('../helpers/APIservice');// when email sms required
///////////Api service include end/////

let userController = {};
let response = {
 status: 200,
 data: [],
 message: null,
 success: false,
};

userController.userLogin = function(req, res){
	userModel.get(req.body.usrName, req.body.usrPwd, function (err, user) {
		
		if(user) { var hashpwd =user['Password']; } else { var hashpwd =''; }
		var passwordStatus = bcrypt.compareSync(req.body.usrPwd, hashpwd);
		if(!passwordStatus)
		{
			response.success = false;
			response.message = "Invalid Password";
		}
		else if (err) {
			response.success = false;
			response.message = "Invalid Email or Password";
		} else if (user) {
			response.uData = user;
			var token = jwt.sign(user, config.API.secretKey,{ expiresIn: '30m' });

			response.token = token;
			response.success = true;
			response.message = "Success";
		} else {
			response.success = false;
			response.message = "Invalid Email or Password";
		}
		res.send(response);
	});
}

userController.createUser = function(req, res){
	
	const regID = req.body.formUID;
	const curUsrName = req.payload._id;
	req.body = JSON.parse(req.body.formJSON);	
	
	req.body.Password = bcrypt.hashSync(req.body.Password, saltRounds);
	jsonLogObj = req.body;
	jsonLogObj['ActivityUsername'] = req.payload.UserName;
	jsonLogObj["ActivityCollectionName"] = "users";
	jsonLogObj["ActivityIpAddress"] = user_ip_address;
	jsonLogObj["ActivityDate"] = new Date(Date.now());
	
	if(regID){
		req.body.updatedBy = curUsrName;
		userModel.userEdit(req.body, curUsrName, regID , function (err, user) {
			//jsonLogObj['ActivityDataID'] = ObjectID(regID);
			//if(jsonLogObj['_id']) delete jsonLogObj['_id'];
			//jsonLogObj['ActivityDataType'] = "Update";
			if(err){
				//jsonLogObj["ActivityError"] =  "{ error: "+err.stack+" }";
				//activityLog.QryErrorLogFn(jsonLogObj);
				response.message = "User update failed";
				response.success = false;
				res.send(response);
			}else{
				//jsonLogObj['ActivityDataID'] = user._id;
				//delete jsonLogObj['_id'];
				//activityLog.createUpdateLog(jsonLogObj,db,fs,config.ActivityLog);
				
				response.message = "User updated successfully";
				response.success = true;
				res.send(response);
			}
		});
	} else {
		req.body.isDeleted = 0;
		req.body.createdBy = curUsrName;
		req.body.createdDate = new Date(Date.now());
		
		jsonLogObj['ActivityDataType'] = "Insert";	
		userModel.userAdd(req.body, curUsrName , function (err, user) {
			if(err){
				jsonLogObj["ActivityError"] =  "{ error: "+err.stack+" }";
				//activityLog.QryErrorLogFn(jsonLogObj);
				response.message = "User add failed";
				response.success = false;
				res.send(response);
			}else{
				if(user){
					jsonLogObj['ActivityDataID'] = user._id;
					delete jsonLogObj['_id'];
					//activityLog.createUpdateLog(jsonLogObj,db,fs,config.ActivityLog);
					
					response.message = "User added successfully";
					response.success = true;
					res.send(response);
				}
			}
		});
	}
}

userController.editUser = function(req, res){
	const curUsrName = req.payload._id;
	userModel.userStatus(req.body.userID, req.body.status, curUsrName , function (err, user) {
		if(err) {
			response.message = "User Status change failed";
			response.success = false;
		} else {
			response.message = "User Status changed successfully";
			response.success = true;
		}
		res.send(response);
	});
}

userController.getUser = function(req, res){
	var bodyLength = req.query;  
	if (bodyLength.hasOwnProperty("userID")){ 
		userModel.userData(req.query.userID, function (err, users) {
			if (err) {
				response.data = '';
				response.message = err;
				response.success =  false;
			} else if(users && users[0]){
				response.data = users[0];
				response.success =  true;
			} else {
				response.success =  false;
				response.data = '';
				response.message = 'API Failed';
			}
			res.send(response);
		});
	} else {
		userModel.userData('', function (err, users) {
			if (err) {
				response.data = '';
				response.message = err;
				response.success =  false;
			} else {
				response.data = users;
				response.success =  true;
			}
			res.send(response);
		});
	}
}

userController.deleteUser = function(req, res){
	const curUsrName = req.payload._id; 
	/* jsonLogObj = req.query;
	jsonLogObj['ActivityUsername'] = payload.UserName;
	jsonLogObj["ActivityCollectionName"] = "users";
	jsonLogObj["ActivityIpAddress"] = user_ip_address;
	jsonLogObj["ActivityDate"] = new Date(Date.now());
	jsonLogObj['ActivityDataType'] = "Delete";
	jsonLogObj['ActivityDataID'] = ObjectID(curUsrName);
	
	if(jsonLogObj['_id']) delete jsonLogObj['_id']; */
	userModel.userDel(req.query.userID, curUsrName , function (err, user) {
		if(err) {
			//jsonLogObj["ActivityError"] =  "{ error: "+err.stack+" }";
			//logFunct.QryErrorLogFn(jsonLogObj,fs);
			response.message = "User delete failed";
			response.success = false;
		} else {
			//logFunct.createUpdateLog(jsonLogObj,db,fs,configJSON.ActivityLog);
			response.message = "User deleted successfully";
			response.success = true;
		}
		res.send(response);
	});
}

userController.logout = function(req, res){
	response={
		status: 200,
		success:false,
		message: "success"
	};
	res.send(response);
}

userController.checkUserLogin = function(req, res){
	const payload = req.payload; 
	response={
		status: 200,
		success:true,
		message: "success",
		data:payload
	}  
	res.send(response);
}

userController.getLoggedUserData = function(req, res){
	
	response={
		status: 200,
		success:true,
		message: "success",
		data:req.payload.UserName
	}  
	res.json(response);
}

userController.getUserRoleData = function(req, res){
	
	//console.log(req.body);
	var currentRole = req.body.roleID;
	var ACLSet = [];
	userModel.userRoleData(req.body.roleID, req.payload.UserName , function (err, acl) {
		if(err) {
			response.message = err;
			response.success = false;
			res.send(response);
		} else {
			//response.message = "";
			//response.success = true;
			res.send(acl[0].access);
		}
	});
}

userController.getUserRole = function(req, res){
	const userRole = req.payload.UserRole; 
	userModel.getUserRole(userRole, function (err, role) {
		if (err) {
			response.data = '';
			response.message = err;
			response.success =  false;
		} else {
			response.data = role;
			response.success =  true;
		}
		res.send(response);
	});
}

userController.createUserRole = function(req, res){
	const curUsrName = req.payload._id; 
	req.body.isDeleted = 0;
	req.body.createdDate = new Date(Date.now());
	req.body.updatedDate = new Date(Date.now());
	userModel.createUserRole(req.body, curUsrName, function (err, role) {
		if (err) {
			response.data = '';
			response.message = err;
			response.success =  false;
		} else {
			response.message = "Role added successfully";
			response.success = true;
		}
		res.send(response);
	});
}

userController.editUserRole = function(req, res){
	const curUsrName = req.payload._id; 
	let header = JSON.parse(req.headers.body);
	//req.body = JSON.parse(req.body.Role);
	userModel.editUserRole(req.body, header, curUsrName, function (err, role) {
		if (err) {
			response.data = '';
			response.message = err;
			response.success =  false;
		} else {
			response.message = "Role updated successfully";
			response.success = true;
		}
		res.send(response);
	});
}

userController.getUserAccess = function(req, res){
	let bodyLength = req.body; 
	if (bodyLength.hasOwnProperty("_id")){  
		userModel.getUserAccess(req.body._id, function (err, acl) {
			if (err) {
				response.data = '';
				response.message = err;
				response.success =  false;
			} else if(acl && acl[0]){
				response.data = acl[0];
				response.success =  true;
			} else {
				response.success =  false;
				response.data = '';
			}
			res.json(response);
		});
	} else {
		response.success =  false;
		response.data = '';
		res.json(response);
	}
}

userController.editUserAccess = function(req, res){
	let header = JSON.parse(req.headers.body);
	req.body = JSON.parse(req.body.PermissionSet);
	userModel.editUserAccess(req.body, header, function (err, access) {
		if (err) {
			response.data = '';
			response.message = err;
			response.success =  false;
		} else {
			response.success =  true;
			response.message = "Permission updated successfully";
			response.data = '';
		}
		res.send(response);
	});
}

userController.checkCaptcha = function(req, res){
	var secretKey = "6Lc6QLAUAAAAAMTQYWF_pUqe5vycIPpO1ymB_-2S";
	var verificationUrl = "https://www.google.com/recaptcha/api/siteverify?secret=" + secretKey + "&response=" + req.body['captcha'] + "&remoteip=" + req.connection.remoteAddress;
	request(verificationUrl,function(error,response,body) {
		body = JSON.parse(body);
		console.log(body);
		if(body.success !== undefined && !body.success) {
		  return res.json({"responseCode" : 1,"responseDesc" : "Failed captcha verification"});
		}
		res.json({"responseCode" : 0,"responseDesc" : "Sucess"});
	});
}

userController.forgotUser = function(req, res){//////////////intial mail genration and new code inser into otpsecure collection///////////
	req.body = JSON.parse(req.body.formJSON);
	let appData = req.body;
	
	userModel.get(appData.EmailID,'', function (err, user) {
		if (err) {
			response.data = '';
			response.message = err;
			response.success =  false;
		} else if(user){
			let randorandomstringcode = randomstring.generate({
			  length: 8,
			  charset: 'alphanumeric',
			  capitalization:'uppercase'
			});
			
			jsonLogObj = req.body;
			jsonLogObj["OtpCode"] = randorandomstringcode;
			jsonLogObj["status"] = "SENT";
			jsonLogObj["ActivityCollectionName"] = "forgot";
			jsonLogObj["ActivityIpAddress"] = user_ip_address;
			jsonLogObj["ActivityDate"] = new Date(Date.now());
			
			let MsgContent = "Hi "+user.UserName+",<br><br>Forgot password Code is "+randorandomstringcode+". Valid only for 10 minutes.";
			let requestData = {"from":"IBPS <itestreg@gmail.com>", "to":appData.EmailID, "subject":"Application Forgot Password", "content":MsgContent};
			let postData = JSON.stringify(requestData);
			let routerKey = 'sendMail';
			userModel.otpSave(req.body,function (err, user) {
				if(err){
					response.message = "CODE Generation failed";
					response.success = false;
					res.send(response);
				}
				else
				{
					APIservice.sendAPIService(requestData,routerKey,function(responseAPI){
						if(responseAPI == 'success') { 
							response.message = 'CODE SENT TO YOUR REGISTERED MAIL ID';
							response.success =  true;
						}
						else
						{
							response.message = "Invalid Mail Id";
							response.success =  false;
						} 
						res.send(response);
					});
				}
			});
		} else {
			response.success =  false;
			response.data = '';
			response.message = 'PLEASE ENTER REGISTERED E-MAIL ID';
			res.send(response);
		}
	});
}
userController.passwordReset = function(req, res){//////////////Code validation and code status update in otpsecure collection///////////
	req.body = JSON.parse(req.body.formJSON);	
	
	req.body.Password = bcrypt.hashSync(req.body.Password, saltRounds);
	req.body.frmPassword2 = bcrypt.hashSync(req.body.frmPassword2, saltRounds);
	jsonLogObj = req.body;
	jsonLogObj["ActivityCollectionName"] = "users";
	jsonLogObj["ActivityIpAddress"] = user_ip_address;
	jsonLogObj["ActivityDate"] = new Date(Date.now());
	let fromdate = new Date(Date.now());
	let todate = addSubtractDate.subtract(new Date(Date.now()), 10, "minutes");
	let otpStatus = "FAILED";
	userModel.userOtpValidate(req.body.EmailID,fromdate,todate, function (err, user) {
		if(err || user.OtpCode=='')
		{
			response.message = "YOUR ENTERED CODE IS INVALID";////////db error
			response.success = false;
			res.send(response);
		}
		else
		{
			if(user && req.body.Code==user.OtpCode)
			{
				userModel.userChagePassword(req.body,function (err, cpsw) {
					if(err){
						
						response.message = "Password update failed";
						response.success = false;
						
					}else{
						response.message = "Password updated successfully";
						response.success = true;
						otpStatus = "VERIFIED";
					}
					userModel.otpStatusChange(user._id,otpStatus, function (err, otpsec) {
						res.send(response);
					});
					 
						
				});
			}
			else
			{
				response.message = "YOUR ENTERED CODE IS INVALID";
				response.success = false;
				res.send(response);
			}
		}
	}); 
}
////////////////////////forgot password End////////////////

module.exports = userController;