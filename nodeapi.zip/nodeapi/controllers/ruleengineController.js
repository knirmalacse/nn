var express = require('express');
var ruleengineModel = require('../models/ruleengineModel');
var activityLog = require('../helpers/log_function');
//const config = require('../config/config.json')[process.env.NODE_ENV || "development"];
const jwt = require('jsonwebtoken'); 
var appdb = require('../db/appdb');

let ruleengineController = {};
const ObjectID = require("mongodb").ObjectID;
let response = {
 status: 200,
 data: [],
 message: null,
 success: false,
};

//Ruleengine Controller start
ruleengineController.ruleengine = function(req, res){
		
		//console.log("req control");
		const accID = req.body.accountName;
		const projID = req.body.projectName;
		const appendField = req.body.appendField;
		const appendFieldLabel = req.body.appendFieldLabel;

		req.body.createdBy = 'User';
		req.body.createdDate = new Date(Date.now()); 
		req.body.rule_status = 'Active'; 
	
			if(accID && projID){
				ruleengineModel.ruleengineAdd(req.body, function (err, result){
					if(err){
						response.message = "Rule failed to save";
						response.success = false;
						res.json(response);
					}else{
						if(result){ 
							ruleengineModel.ruleengineUpdate(req.body, accID ,projID,appendField, result._id, function (err, result) {
								if(err){
									response.message = "Rule failed to save";
									response.success = false;
									response.data = '';
									res.send(response);
								}else{
									response.message = "Rule Saved successfully";
									response.success = true;
									response.data = '';
									res.send(response);
								}
							});
						}
					}
				});	 
			} else {
				response.success = false;
				res.json(response);
			}
	 	  
}
//Ruleengine Controller End

//Controller start
ruleengineController.getruleengine = function(req, res){
	//console.log('--------------getruleengine--------');
	
	const accID = req.query.accountID;
		const projID = req.query.projectID;
		const searchInp = req.query.searchInp;
		 
		const searchInpStr = '.*'+searchInp+'.*';
		const searchInpStrStatus = '^'+searchInp+'.*';
		 
		  if(accID && projID) {
			/* console.log('----------accID && projID enter------------------------------------');
			console.log(accID);
			console.log(projID); */
			if(searchInp!=""){
				var qryStrRule = JSON.stringify({
					$and : [
							{ $and : [ { 'accountName' : accID }, { 'projectName' : projID } ] },
							{ $or : [ { "appendFieldLabel" : {$regex: searchInpStr,$options: 'i'} } ] } 
						   ]
				});
				
			}else{
				var qryStrRule = JSON.stringify({$and:[{'accountName':accID,'projectName':projID}]});
			}
			var qryStrRuleArr = JSON.parse(qryStrRule);
			 
					ruleengineModel.ruleengineAggregate(qryStrRuleArr,function (err, result) {
						if(err) {
							response.data = '';
							response.success =  false;
							res.json(response);
						}else{
							response.data = result;
							response.success =  true;
							res.json(response);
						}
						 
					});
		}  
}
// Controller end

ruleengineController.getruleengineById = function(req, res){
	const ruleID = req.query.ruleID;		
		if(ruleID) {
			ruleengineModel.ruleenginegetruleengineById(req.query.ruleID, function (err, result) {
				if(err) {
					response.data = '';
					response.success =  false;
					res.json(response);
				}else{
					response.data = result;
					response.success =  true;
					res.json(response);
				}
			});
		}
}
ruleengineController.delruleengine = function(req, res){
	const accID = req.body.accountID;
		const projID = req.body.projectID;
		const fieldName = req.body.fieldName;
		const appln = req.body.compObj;
		const ruleID = req.body.ruleID;
		const typeStr = req.body.typeStr;
		//console.log(fieldName+'-'+accID+'-'+fieldName);
		req.header('Cache-Control', 'no-cache');
		
		var applicationJson = {
			_applnid:ObjectID(),
			projectJson:appln,
			status:'Active',
			createdBy:'User',
			createdDate:new Date(Date.now()),
		}
		var fieldNameStr = JSON.stringify({'_id':ObjectID(ruleID)});
		var fieldNameStrArr = JSON.parse(fieldNameStr);
		if(accID && projID && fieldName && ruleID && typeStr) { 
			ruleengineModel.ruleengineremove(accID,projID, fieldName,applicationJson,typeStr, function (err, result) {
				if(err){
					console.log('-------------delete error-------------');
					response.data = '';
					response.success =  false;
					res.json(response);
				}else{
					console.log('-------------delete success-------------');
					response.message = 'Rule Deleted Successfully';
					response.data = '';
					response.success =  true;	
					res.json(response);
				}
			});
		}
}

ruleengineController.getageRelaxationList = function(req, res){
	 
		const acctID = req.query.accountID;
		const projID = req.query.projectID;
		
		if(projID) {
			ruleengineModel.ruleengineageAggregate(projID,function (err, data) {
				if(err){
					response.data = '';
					response.success =  false;
					res.json(response);
				}else{ 
					let projectIdentifier = data[0].projectIdentifier;
					var applnDBConn = new Promise(function(resolve, reject) {
						appdb.connect(projectIdentifier,function(err) {
							if (err) {
								reject(err);
							} else {
								resolve();
							}
						});
					});
					applnDBConn.then(function(){
						ruleengineModel.ruleenginegetageRelaxationFind(req.query, function (err, result) {
							if(err){
								 console.log(err);
							}else{  
								let returnData={};
								result=result[0]; 
								if(result){  
									if(result.ageArrayCount > 0){ 
										returnData.genFormJSON =JSON.stringify(result['genFormJSON']);  
										returnData.genFormStatus ="update"; 
											ruleengineModel.ruleengineagerelaxFind(req.query, function (err, ageRelres) {
												
											if(err){
												 console.log(err);
											}else{   
												ageRelres=ageRelres[0]; 
												if(ageRelres){ 
														returnData.genFormStatus ="Success"; 	
														returnData.genRelaxAgeJSON =JSON.stringify(ageRelres);  
												}
											}
											//console.log(returnData);
											//console.log(returnData);
											appdb.close(function(err){
												if(err) {
													console.log(err);
												} else {
													res.json(returnData);
												}
											});
												
										}); 			
									}else{console.log('here');} 
								} else {
									response.message = 'No data found';
									response.data = '';
									response.success =  false;	
									appdb.close(function(err){
										if(err) {
											console.log(err);
										} else {
											res.json(response);
										}
									});
								}
							}
						});
					})
					.catch((error) => {
						console.log('here');
					});
					/* appdb.connect(projectIdentifier,function(err) {
						
					}); */
					 
				}
								
			});
		}

}	

ruleengineController.addageruleengine = function(req, res){	
	   const errorFormatter = ({ location, msg, param, value }) => {
			return `${msg}`;
		}; 
	req.header('Cache-Control', 'no-cache'); 
	  
	//console.log("vv--vv--"); 
	//console.log(req.body); 
	const projID =req.body.formVal.PID; 
	const AID =req.body.formVal.AID; 
	const ID =req.body.ID; 
	req.body.status = 'Active';
	req.body.createdDate = new Date(Date.now());
	//console.log('projID'); console.log(projID); 
	req.body.PID=projID;
	req.body.AID=AID;
	req.body.ID=ID;
	if(projID){
		ruleengineModel.ruleengineaddageruleAggregate(projID,function (err, data){ 
			if(err){
				response.data = '';
				response.success =  false;
				res.json(response);
			}else{ 	
				let projectIdentifier = data[0].projectIdentifier;
				appdb.connect(projectIdentifier,function(err) {
					ruleengineModel.ruleengineaddageruleFind(req.query, function (err, result) {
						if(err){
							
						}else{
							result=result[0]; 
							if(result){
								if(result.ageArrayCount > 0){  
									tempMain={};
									 for(var i=1;i <= result.ageArrayCount; i++)
									 {  temparray={};
										var rel='rel'+i;
										var iterArray=req.body.formVal[rel];  
										if(typeof iterArray !== "undefined" ){
											var rows="1";  
											temparray['postcode']=i;
											temparray['ageConfig']=i;
											//console.log('iterArray');console.log(iterArray);
											iterArray.forEach(function(element) { 
												temparray[element.relaxFormField]=element;   
												rows++; 
											});
										}
											tempMain[i]=temparray;
										 
									 } 
									 
									req.body.genRelaxAgeJSON = tempMain; 	
									ruleengineModel.ruleengineageRelaxsave(req.body, function (err, result1) {
										if(err){
											 
										}else{
											if(result1){ 
												response.message = "Age Relax saved successfully";
												response.data = result1;
												response.genFormJSON = result.genFormJSON;
												response.success = true;
												res.json(response);
											}
										}
									});  
										 
								}else{} 
							}
						}
					});
				});
				
			}
	   }); 			
	} 	  
	response.message = "age added successfully";
} 

ruleengineController.ruleworkexpAdd = function(req, res){
	const acctID = JSON.parse(req.body.AID);
	const projID = JSON.parse(req.body.PID);
	const totexp = req.body.totexp;
	var WorkExpId = "";
	if(req.body.WorkExpId) {
		WorkExpId = req.body.WorkExpId; 
		req.body._id = ObjectID(WorkExpId);
	}
	req.body.AID = acctID;
	req.body.PID = projID;
	 
	//console.log("hhhh");
	jsonLogObj = req.body;
	//console.log(projID);
	jsonLogObj["ActivityCollectionName"] = "workexp";
	jsonLogObj["ActivityDate"] = new Date(Date.now());
	
	if(projID) {
	  ruleengineModel.ruleworkexpAddModel(projID,function (err, data) {
		if(err) {
			response.data = '';
			response.success =  false;
			res.json(response);
		}else{
			let projectIdentifier = data[0].projectIdentifier;
			appdb.connect(projectIdentifier,function(err) {
				const getFormValueInArray = JSON.parse(req.body.formJSON)
				var  totaldatas={};
				var rows="1";
				  getFormValueInArray.forEach(function(element) {
					temparray={};
					temparray['fromdate']=element.fromdate.formatted;//mm/dd/yyyy
					temparray['todate']=element.todate.formatted;//mm/dd/yyyy
					temparray['CalcAppendField']=element.CalcAppendField; 
					totaldatas[rows]=temparray;
					rows++;
				}); 
				req.body.formJSON = JSON.parse(req.body.formJSON);
				req.body.workExpArrayCount = (rows-1);  	
			});
			
			ruleengineModel.ruleworkexpAddModelSave(req.body, {}, function (err, result){
			   if(err){
					 
				}else{
					if(result){
						response.message = "Work Experience added successfully";
						response.data = result;
						response.success = true;
						res.json(response);
					}
				} 
			}); 
		} 
	}); 
 }
}

ruleengineController.ruleworkexpEdit = function(req, res){
	const acctID = JSON.parse(req.query.AID);
	const projID = JSON.parse(req.query.PID);
	//console.log(acctID + "--"+projID);
	if(projID) {
		ruleengineModel.ruleworkexpEditModel(projID,function (err, data) {
			if(err) {
				response.data = '';
				response.success =  false;
				res.json(response);
			}else{
				let projectIdentifier = data[0].projectIdentifier;
				appdb.connect(projectIdentifier,function(err) {
					ruleengineModel.ruleengineworkexpFind(req.query, function (err, result) {
						if (err) {
							response.data = '';
							response.message = '';
							response.success = false;
							res.json(response);
						}else{
							response.data = result[0];
							response.message = '';
							response.success =  true;
							res.json(response);
						}
					});
				});
			}
		});
	}
}

module.exports = ruleengineController;