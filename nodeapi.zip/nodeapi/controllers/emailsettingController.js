'use strict';
var express = require('express'); 
const ObjectID = require("mongodb").ObjectID;

const mongojs = require("mongojs");

var acpModel = require('../models/acpModel');
var projModel = require('../models/projModel');
const ruleengineModel = require('../models/ruleengineModel');
var activityLog = require('../helpers/log_function');
//const config = require('../config/config.json')[process.env.NODE_ENV || "development"];
const jwt = require('jsonwebtoken');
const db = require('../db/db');
const appdb = require('../db/appdb');
const commonQuery = require('../config/commonQuery.js')

// let emailSettingController = {};
var acppassport = require('../acppassport');

let response = {
    status: 200,
    data: [],
    message: null,
    success: false,
};

module.exports = {
    addEditEmail: addEditEmail,
    getNotificationById: getNotificationById
}

async function addEditEmail(req, res) {
    try {
        var dbConn = db.get();
        let obj = {
            notificationType: req.body.contentType,
            NotificationOption: req.body.contentOptionType,
            content: req.body.content ? req.body.content : ""
        };
        if (req.body.contentType == 'email')
            obj.subject = req.body.subject;

        console.log("reqqq ")
        let matchCond = { status: 'Active', 'project.status': 'Active' };
        if (req.body.projId) {
            matchCond = { status: 'Active', 'project._projectid': ObjectID(req.body.projId), 'project.status': 'Active' };
        }
        var aggrcond = [
            { $unwind: "$project" }, { $match: matchCond },
            {
                $project: {
                    _id: 1, accountName: 1, projectid: '$project._projectid', projectName: '$project.projectName',
                    projectDetails: '$project.projectDetails', projectIdentifier: '$project.projectIdentifier',
                    projectServices: '$project.projectServices', projectComponents: '$project.projectComponents'
                }
            }
        ];
        var projectIdentifier = await commonQuery.fetchAggregate(dbConn.account, aggrcond);
        if (projectIdentifier.length > 0) {
            var projectidentifier = projectIdentifier[0].projectIdentifier;
            console.log("projectIdentifier ", projectIdentifier)
            console.log("projectidentifier ", projectidentifier)
            await commonQuery.dbConnStart(appdb, projectidentifier).then(async conx => {
                var dbConnA = appdb.get(); 
                var fetchemailsettigbyid = await commonQuery.fetchAllDocument(dbConnA.emailsetting, { '_id': ObjectID(req.body.notificationId) });
                if (fetchemailsettigbyid.length == 0) {
                    await commonQuery.insertDocument(dbConnA.emailsetting, obj).then(data => {
                        let message = (req.body.contentType == 'email') ? "Email notification added successfully" : "SMS notification added successfully";
                        response.message = message;
                        response.status = 200;
                        response.success = true;
                        res.send(response);
                    }).catch(e => {
                        let message = (req.body.contentType == 'email') ? "Email notification failed" : "SMS notification failed";
                        response.status = 403;
                        response.message = message;
                        response.data = [];
                        response.success = false;
                        res.send(response);
                    });
                } else { 
                    let condin = {
                        _id: ObjectID(req.body.notificationId),
                        $and: [{ notificationType: req.body.contentType }, { NotificationOption: req.body.contentOptionType }]
                    }
                    await commonQuery.updateDocument(dbConnA.emailsetting, condin, obj).then(data => {
                        let message = (req.body.contentType == 'email') ? "Email notification updated successfully" : "SMS notification updated successfully";
                        response.message = message;
                        response.status = 200;
                        response.success = true;
                        res.send(response);
                    }).catch(e => {
                        let message = (req.body.contentType == 'email') ? "Email notification failed to update" : "SMS notification failed to update";
                        response.status = 403;
                        response.message = message;
                        response.data = [];
                        response.success = false;
                        res.send(response);
                    });
                }
                await commonQuery.dbConnClose(appdb);

                console.log("ssss ", conx)
            }).catch(ex => {
                let message = "Failed to connect database";
                response.status = 403;
                response.message = message;
                response.data = [];
                response.success = false;
                res.send(response);
            })
        } else {
            let message = "Invalid Application";
            response.status = 403;
            response.message = message;
            response.data = [];
            response.success = false;
            res.send(response);
        }

    } catch (e) {
        console.log("errr ", e)
        response.status = 500;
        response.data = [];
        response.message = "Exception Error";
        response.success = false;
        res.send(response);
    }
}

async function getNotificationById(req, res) {
    try {
        var dbConn = db.get();
        let matchCond = { status: 'Active', 'project.status': 'Active' };
        if (req.body.projId) {
            matchCond = { status: 'Active', 'project._projectid': ObjectID(req.body.projId), 'project.status': 'Active' };
        }
        var aggrcond = [
            { $unwind: "$project" }, { $match: matchCond },
            {
                $project: {
                    _id: 1, accountName: 1, projectid: '$project._projectid', projectName: '$project.projectName',
                    projectDetails: '$project.projectDetails', projectIdentifier: '$project.projectIdentifier',
                    projectServices: '$project.projectServices', projectComponents: '$project.projectComponents'
                }
            }
        ];
        var projectIdentifier = await commonQuery.fetchAggregate(dbConn.account, aggrcond);
        if (projectIdentifier.length > 0) {
            var projectidentifier = projectIdentifier[0].projectIdentifier;
            console.log("projectIdentifiers ", projectIdentifier) 
            await commonQuery.dbConnStart(appdb, projectidentifier).then(async conx => {
                var dbConnA = appdb.get(); 
                let obj = {
                    // _id: ObjectID(req.body.notificationId),
                    $and: [{ notificationType: req.body.contentType }, { NotificationOption: req.body.contentOptionType }]
                }
                await commonQuery.fetchOneDocument(dbConnA.emailsetting, obj).then(data => {
                    if(data != null){
                        console.log("data ",data)
                    let message = (req.body.contentType == 'email') ? "Email notification fetch successfully" : "SMS notification fetch successfully";
                    response.message = message;
                    response.status = 200;
                    response.success = true;
                    response.data = data;
                    res.send(response);
                    } else {
                        let message = "No template found";
                        response.status = 204;
                        response.data = [];
                        response.message = message;
                        response.success = false;
                        res.send(response); 
                    } 
                }).catch(ex => {
                    let message = (req.body.contentType == 'email') ? "Email notification failed to fetch" : "SMS notification failed to fetch";
                    response.status = 403;
                    response.data = [];
                    response.message = message;
                    response.success = false;
                    res.send(response);
                });
                await commonQuery.dbConnClose(appdb);
            }).catch(ex => {
                let message = "Failed to connect database";
                response.status = 403;
                response.message = message;
                response.data = [];
                response.success = false;
                res.send(response);
            })
        } else {
            let message = "Invalid Application";
            response.status = 403;
            response.message = message;
            response.data = [];
            response.success = false;
            res.send(response);
        } 
    } catch (e) {
        console.log("errr ", e)
        response.status = 500;
        response.data = [];
        response.message = "Exception Error";
        response.success = false;
        res.send(response);
    }
}