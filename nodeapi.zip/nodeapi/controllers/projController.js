var express = require('express');
var projModel = require('../models/projModel'); 
var ruleengineModel = require('../models/ruleengineModel');
var activityLog = require('../helpers/log_function');
//const config = require('../config/config.json')[process.env.NODE_ENV || "development"];
const jwt = require('jsonwebtoken');
var appdb = require('../db/appdb');
///password bcrypt starts//
const bcrypt = require('bcrypt');
const saltRounds = 10;
var mkdirp = require('mkdirp');
const AWS = require('aws-sdk');
const http = require('http');
///password bcrypt ends//
let projController = {};
let response = { 
 status: 200,
 data: [],
 message: null,
 success: false,
};

projController.createProject = function(req, res){
	let userName = req.payload.UserName;
	
	const accID = req.body.AID;
	const projID = req.body.PID;
	req.body = JSON.parse(req.body.formJSON);	
	var genericService = {
		'hasEmail': false,
		'hasSms': false,
		'hasCaptcha': false,
		'hasBarcode': false,
		'hasUploads': false,
		'hasPayment': false,
		//payment: { mode: '', type:''}
	};
	var genericComponent = {
		'hasRegistration': false,
		'hasReRegistration': false,
		'hasCallletter': false,
		'hasResults': false,
	};
	
	var projServices = req.body.projectServices;
	console.log('1111');
	console.log(projServices);
	var projComponents = req.body.projectComponents;
	console.log('22222');
	console.log(projComponents);
	 for(var myKey in projServices) {
	   if(genericService.hasOwnProperty(myKey)){					   
		   genericServiceAss = myKey;
		   genericService[genericServiceAss] = projServices[myKey];		
	   }
	}  
	for(var myKey in projComponents) {
	   if(genericComponent.hasOwnProperty(myKey)){					   
		   genericComponentAss = myKey;
		   genericComponent[genericComponentAss] = projComponents[myKey];		
	   }
	}

	/* jsonLogObj = req.body;
	jsonLogObj['ActivityUsername'] = userName;
	jsonLogObj["ActivityCollectionName"] = "account.project";
	jsonLogObj["ActivityIpAddress"] = user_ip_address;
	jsonLogObj["ActivityDate"] = new Date(Date.now()); */
	if(projID && accID){
		console.log('projID projID projID');
		console.log(projID);
		response.message = "Account updated successfully";
		req.body.status = 'Active';
		//req.body._projectid = ObjectID(projID);

		/* jsonLogObj['ActivityDataType'] = "Update";
		jsonLogObj['ActivityDataID'] = ObjectID(accID);
		if(jsonLogObj['_id']) delete jsonLogObj['_id']; */
		
		projModel.projectEdit(accID, projID, req.body, userName,genericService,genericComponent , function (err, user) {
			if(err){
				response.message = "Account update failed";
				response.success = false;
				//jsonLogObj["ActivityError"] =  "{ error: "+err.stack+" }";
				//logFunct.QryErrorLogFn(jsonLogObj,fs);
			}else{
				//logFunct.createUpdateLog(jsonLogObj,db,fs,configJSON.ActivityLog);
				response.message = "Account updated successfully";
				response.success = true;
			}
			res.send(response);
		});
	} else {
		req.body.status = 'Active';
		//jsonLogObj['ActivityDataType'] = "Insert";
		console.log("ad jsonACPDefaultInfo");
		
		config.ACPDefaultInfo.userPwd=bcrypt.hashSync(config.ACPDefaultInfo.userPwd, saltRounds);
		jsonACPDefaultInfo=config.ACPDefaultInfo;
		console.log('11111');
		console.log(config.ACPDefaultInfo.userPwd);
		
		console.log('2222222222');
		console.log(jsonACPDefaultInfo);
		
		projModel.projectAdd(accID, req.body, userName,genericService,genericComponent , function (err, result) {
			if(err){
				response.message = "Account add failed";
				response.success = false;
				//jsonLogObj["ActivityError"] =  "{ error: "+err.stack+" }";
				//logFunct.QryErrorLogFn(jsonLogObj,fs);
			}else{
				//jsonLogObj['ActivityDataID'] = ObjectID(accID);
				//delete jsonLogObj['_id'];
				//logFunct.createUpdateLog(jsonLogObj,db,fs,configJSON.ActivityLog);
				var applnDBConn = new Promise(function(resolve, reject) {
					appdb.connect(req.body.projectIdentifier,function(err) {
						 if (err) {
							reject(err);
						} else {
							resolve();
						}
					});
				});
				applnDBConn.then(function(){
					projModel.createDbAdminuser(jsonACPDefaultInfo,function (err, result) {
    					response.message = "Account added successfully";
    					response.success = true;
    					// res.send(response);
				    });
				});
			
			}
			res.send(response);
		});
	}
}

projController.getProject = function(req, res){
	var bodyLength = req.query; 
    if (bodyLength.hasOwnProperty("PID")){  
		projModel.getProject(req.query.AID, req.query.PID, function (err, result) {
			if(err){
				response.message = err;
				response.data = '';
				response.success = false;
			}else if(result[0]){
				response.data = result[0];
				response.success =  true;
			} else {
				response.success =  false;
				response.data = '';
				response.message = "No Results Found";
			}
			res.send(response);
		});
	} else { 
		projModel.getProject('', '', function (err, result) {
			if(err){
				response.message = err;
				response.data = '';
				response.success = false;
			}else if(result[0]){
				response.data = result;
				response.success =  true;
			} else {
				response.success =  false;
				response.data = '';
				response.message = "No Results Found";
			}
		});
		res.send(response);
	}
}

projController.deleteProject = function(req, res){
	let userName = req.payload.UserName;
	
	/* jsonLogObj = req.body;
	jsonLogObj['ActivityUsername'] = req.session.usrName;
	jsonLogObj["ActivityCollectionName"] = "account.project";
	jsonLogObj["ActivityIpAddress"] = user_ip_address;
	jsonLogObj["ActivityDate"] = new Date(Date.now());
	jsonLogObj['ActivityDataType'] = "Delete";
	jsonLogObj['ActivityDataID'] = ObjectID(req.body.AID); 
	
	if(jsonLogObj['_id']) delete jsonLogObj['_id'];*/
	projModel.projectDel(req.body.AID, req.body.PID, userName, function (err, result) {
		if(err){
			response.message = "Account delete failed";
			response.success = false;
			//jsonLogObj["ActivityError"] =  "{ error: "+err.stack+" }";
			//logFunct.QryErrorLogFn(jsonLogObj,fs);
		}else{
			//logFunct.createUpdateLog(jsonLogObj,db,fs,configJSON.ActivityLog);
			response.message = "Account deleted successfully";
			response.success = true;
		}
		res.send(response1);
	});
}

projController.getProjectDetail = function(req, res){
	var bodyLength = req.query; 
    if (bodyLength.hasOwnProperty("PID")){  
		projModel.getProjectDetail(req.query.PID, function (err, result) {
			if(err){
				response.message = err;
				response.data = '';
				response.success = false;
			}else if(result[0]){
				response.data = result[0];
				response.success =  true;
			} else {
				response.success =  false;
				response.data = '';
				response.message = "No Results Found";
			}
			res.send(response);
		});
	} else {
		response.success =  false;
		response.data = '';
		response.message = "API failed";
		res.send(response);
	} 
}

projController.createProjectSetting = function(req, res,next){
	var multer = require('multer');
	var path = require('path');
	var fs = require('fs');
	var acppassport = require('../acppassport');
	const validation = require('../helpers/validation');
	
	var staticDocUploadPath = config.staticDocUpload;
	var storage = multer.diskStorage({
		
		destination: (req, file, cb) => {
		 projectIdentifier = req.body['projectIdentifier'];
		 
		  mkdirp(staticDocUploadPath+req.body['projectIdentifier'], function(err) { 
			if(err) { } else {
				cb(null, staticDocUploadPath+req.body['projectIdentifier']);
			}
		  });	

		},
		filename: (req, file, cb) => {
		  cb(null,  'logo.jpg')  
		}
	});
	
	
	var upload = multer({
			limits: { fileSize: 50*1024 },//50 KB
			fileFilter: function(req, file, callback) {
				if(file.mimetype != 'image/jpeg' && file.mimetype != 'image/jpg') {
					callback('Only jpg / jpeg images are allowed', null);
					
				}else{
					callback(null, true);
					//callback(new Error('Only jpg files allowed!'));
				} 
			},
			storage: storage
	});
	
	var UploadData = upload.single('filed');
	UploadData(req, res, function (err) {
		//console.log(err);
		if (err) {
			if(err.code && err.code == 'LIMIT_FILE_SIZE'){
				response.data = '';
				response.message = {'file':err.message};
				response.success =  false;
				res.json(response);
			}else{
				response.data = '';
				response.message = {'file':err};
				response.success =  false;
				res.json(response);
			}
		}else{
			validation.projectSetting(req, res, function (err) {
				if(err){
					response={
						status: 200,
						success:false,
						message: "Settings save failed",
						data:'' 
					}
					res.send(response);
				}else{
					var projId = req.body['projId'];
					/* console.log("ininin4");
					console.log(projId); */
					//login check - JWT Passport
					acppassport.authenticate('jwt', {session: false}, (err, user,info) => {
						if(user){
							if(projId) {
								// console.log("inside check");
								 ruleengineModel.ruleengineageAggregate(projId,function (err, data) {
									if(err){
										response.data = '';
										response.message = err;
										response.success =  false;
										res.json(response);
									}else{ 
										let projectIdentifier = data[0].projectIdentifier;
										var applnDBConn = new Promise(function(resolve, reject) {
											appdb.connect(projectIdentifier,function(err) {
												 if (err) {
													reject(err);
												} else {
													resolve();
												}
											});
										});
										applnDBConn.then(function(){
											var logo_path = staticDocUploadPath+req.body['projectIdentifier'];
											req.body['logo_path'] = logo_path;
											projModel.saveProjectSetting(req.body, function (err, result) {
												if(err){
													response.message = err;
													response.data = '';
													response.success = false;
												}else if(result){
													response.success =  true;
													response.data = result;
													response.message = "Settings saved successfully";
												} else {
													response.success =  false;
													response.data = '';
													response.message = "Settings save failed";
												}
												appdb.close(function(err){
													if(err) {
														//console.log(err);
													} else {
														res.json(response);
													} 
												});
												
											});
										});
									}
								}); 
							}
						}else{
							response={
								status: 200,
								success:false,
								message: "Settings save failed",
								data:'' 
							}
							res.send(response);
						}
					})(req, res, next) 
				}
			});
		}
	});
}
projController.createProjectSetting_FileUpload = function(req, res){
	  let projId = req.body.PID;
	  let logo_path = req.body.logoPath;
 
	  let projectIdentifier = req.body.projectIdentifier;
		req.body = req.body.data;
		
		 const bucket = new AWS.S3(
			  {
				accessKeyId: 'AKIATUXKDK3XI6MTIGGS',
				secretAccessKey: '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',
				region: 'ap-south-1'
			  }
			);
		var key1 = projectIdentifier+"/logo/"+logo_path;  	
		 
			const params = {
			  Bucket: 'uploaddt',
			  Key: key1,
			  ACL: 'public-read',
			  Body: logo_path
			};
			 
			bucket.upload(params, function (err, data) {
			  if (err) {  
				console.log('There was an error uploading your file: ', err);
				return false;
			  } 
				console.log('---ggggggggggggg----');   
				console.log(data);   
			  return true; 
			  
			}); 

    	    
}

projController.getProjectSetting = function(req, res){
	var bodyLength = req.query; 
	ruleengineModel.ruleengineageAggregate(bodyLength.PID,function (err, data) {
		if(err){
			response.data = '';
			response.message = err;
			response.success =  false;
			res.json(response);
		}else{ 
			let projectIdentifier = data[0].projectIdentifier;
			var applnDBConn = new Promise(function(resolve, reject) {
				appdb.connect(projectIdentifier,function(err) {
					 if (err) {
						reject(err);
					} else {
						resolve();
					}
				});
			});
			applnDBConn.then(function(){
				projModel.getProjectSetting(function (err, result) {
					if(err){
						//jsonLogObj["ActivityError"] =  "{ error: "+err.stack+" }";
						//logFunct.QryErrorLogFn(jsonLogObj,fs);
					}else{
						if(result[0]){
							//jsonLogObj['ActivityDataID'] = result._id;
							//delete jsonLogObj['_id'];
							//logFunct.createUpdateLog(jsonLogObj,db,fs,configJSON.ActivityLog);
							//response.message = "Settings saved successfully";
							response.data = result[0];
							response.success = true;
							res.json(response);
						}else {
							response.data = {};
							response.success = true;
							res.json(response);
						}
					}
					appdb.close(function(err){
						if(err) {
							console.log(err);
						} 
					});
				});
			});
		}
	});
}

module.exports = projController;