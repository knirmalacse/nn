var express = require('express'); 
var applnModel = require('../models/applnModel');
var activityLog = require('../helpers/log_function');
//const config = require('../config/config.json')[process.env.NODE_ENV || "development"];
const jwt = require('jsonwebtoken');

let applnController = {};
let response = {
 status: 200,
 data: [],
 message: null,
 success: false,
};

applnController.saveAppln = function(req, res){
	const accID = req.body.accountName;
	const projID = req.body.projectName;
	const appln = req.body.formJson;
	const curUsrName = req.payload._id;
	if(accID && projID) {
		req.body.updatedBy = 'User';//userName;
		req.body.updatedDate = new Date(Date.now());
		applnModel.saveAppln(accID, projID, appln, curUsrName, function (err, data) {
			if (err) {
				response.success = false;
				response.message = "Application failed to save";
			} else {
				response.message = "Application saved successfully";
				response.success = true;
			}
			res.json(response);
		});
	} else {
		response.message = "Invalid Request";
		response.success = false;
		res.json(response);
	}
};

applnController.getAppln = function(req, res){
	const accID = req.query.accountID;
	const projID = req.query.projectID;
	
	if(accID && projID) {
		applnModel.getAppln(accID, projID, function (err, data) {
			response.message = "";
			if (err) {
				response.data = '';
				response.success =  false;
			}else if(data['0'] == ''){
				response.data = '';
				response.success =  false;
			} else {
				response.data = data;
				response.success =  true;
			}
			res.json(response);
		});
	}
};

applnController.getApplnData = function(req, res){
	const accID = req.query.accountID;
	const projID = req.query.projectID;
	
	if(accID && projID) {
		applnModel.getAppln(accID, projID, function (err, data) {
			response.message = "";
			if (err) {
				response.data = '';
				response.success =  false;
			}else if(data['0'] == ''){
				response.data = '';
				response.success =  false;
			} else {
				var jsonFormBuild = {'components':data['0'].applicationJson,display: 'wizard'};
				var componentFinalValid = true;
				var testfo = true;
				for(let key in jsonFormBuild){
					var value = jsonFormBuild[key];
					for(let keyV in value){
						var valueC = value[keyV];
						
						for(let keyComp in valueC['components']){
							var valueComp = valueC['components'][keyComp];
							var apiKeyValue = valueComp['key'];
							
							var ValidateArr = [];
							for(let keyCompValidate in valueComp['validate']){
								var valueCompValidate = valueComp['validate'][keyCompValidate];
								//console.log(keyCompValidate+"--"+valueCompValidate);
								if(valueCompValidate == true ||  valueCompValidate!=''){
									ValidateArr.push(keyCompValidate);
									
								}
							}
							var ValidationValueVar = eval("dataJsonVal"+"['"+apiKeyValue+"']");
							var jsonCreate = {"validationValue" : ValidationValueVar,"validators": ValidateArr,"component":valueComp};
							testfo = formioValid.default.check(jsonCreate, dataJsonVal);
							if(!testfo) {
								componentFinalValid = testfo;
							}
						}
					}
				}
				response.data = componentFinalValid;
				response.success =  true;
			}
			res.send(response);
		});
	} else {
		response.message = "Invalid Request";
		response.success = false;
		res.json(response);
	}
};

applnController.getAccounts = function(req, res){
	applnModel.getAccounts(function (err, accounts) {
		response.message = "";
		if(err) {
			response.data = '';
			response.success =  false;
		} else {
			response.data = accounts;
			response.success =  true;
		}
		res.json(response);
	});
};

applnController.getAccProject = function(req, res){
	var accountID = req.body.accountID;
	applnModel.getAccProject(accountID, function (err, accounts) {
		response.message = "";
		if ( err ){
			response.data = '';
			response.success =  false;
		} else if(accounts[0]){
			response.data = accounts;
			response.success =  true;
		} else {
			response.success =  false;
			response.data = '';
		}    
		res.send(response);
	});
};

module.exports = applnController;