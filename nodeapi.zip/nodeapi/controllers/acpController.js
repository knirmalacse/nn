var express = require('express');
const ObjectID = require("mongodb").ObjectID;
const mongojs = require("mongojs"); 
var acpModel = require('../models/acpModel');
var projModel = require('../models/projModel');
var activityLog = require('../helpers/log_function');
//const config = require('../config/config.json')[process.env.NODE_ENV || "development"];
const jwt = require('jsonwebtoken');
var appdb = require('../db/appdb');
let acpController = {};
var acppassport = require('../acppassport');
var mkdirp = require('mkdirp');
///password bcrypt starts//
const bcrypt = require('bcrypt');
var fs = require('fs');
const saltRounds = 10;
///password bcrypt ends//
let response = {
 status: 200,
 data: [],
 message: null,
 success: false,
};

acpController.userMgmt = function(req, res){
		let projID = req.body.PID;
		let uId = req.body.uId;		
		req.body = req.body.data;
		req.body.userPwd = bcrypt.hashSync(req.body.userPwd, saltRounds);
		
		if(projID) {
			projModel.getProjectDetail(projID, function (err, data){
				let projectIdentifier = data[0].projectIdentifier;
				appdb.connect(projectIdentifier,function(err) {
					if (err) {
					}else{
						req.body.userCPwd='';
						if(uId) {
							acpModel.saveAdminUser(req.body,uId,function(err, result) {
								if(err){
									//jsonLogObj["ActivityError"] =  "{ error: "+err.stack+" }";
									//logFunct.QryErrorLogFn(jsonLogObj,fs);
								}else{
									if(result){
										//logFunct.createUpdateLog(jsonLogObj,db,fs,configJSON.ActivityLog);
										response.message = "User updated successfully";
										response.data = result;
										response.success = true;
										res.send(response);
									}
								}
							});
						}else{
							acpModel.saveAdminUser(req.body,'',function(err, result) {
								if(err){ }else{
									 if(result){
										response.message = "User saved successfully";
										response.data = result;
										response.success = true;
										res.send(response); 
									}
								}
							});
						}
					}
				});
			});
		}else {
			response.data = [];
			response.success = false;
			res.send(response);
		} 
}

acpController.getuserAdmin = function(req, res){
	var bodyLength = req.query; 
	var projID = bodyLength.PID; 
	projModel.getProjectDetail(projID, function (err, data){
		let projectIdentifier = data[0].projectIdentifier;
		appdb.connect(projectIdentifier,function(err) {
			if (err) { }else{
				acpModel.getAdminUser('',function(err, result) {
					if(result){
						//jsonLogObj['ActivityDataID'] = result._id;
						//delete jsonLogObj['_id'];
						//logFunct.createUpdateLog(jsonLogObj,db,fs,configJSON.ActivityLog);
						//response.message = "Settings saved successfully";
						response.data = result;
						response.success = true;
						res.send(response);
					}else {
						response.data = {};
						response.success = true;
						res.send(response);
					}
				});
			}
		});
	});		
}
acpController.getLsearchuser = function(req, res){
	var bodyLength = req.body; 
	var projID = bodyLength.PID; 
	var searchtype = bodyLength.searchtype; 
	var searchval = bodyLength.searchval; 
	
	projModel.getProjectDetail(projID, function (err, data){
		let projectIdentifier = data[0].projectIdentifier;
		appdb.connect(projectIdentifier,function(err) {
			if (err) {
				response.data = '';
				response.success = false;
				response.message = "failed";
				res.send(response); 
			}else{
				acpModel.getLsearchuser(searchtype,searchval,function(err, result) {
					if(result){
						//jsonLogObj['ActivityDataID'] = result._id;
						//delete jsonLogObj['_id'];
						//logFunct.createUpdateLog(jsonLogObj,db,fs,configJSON.ActivityLog);
						//response.message = "Settings saved successfully";
						response.data = result;
						response.success = true;
						res.send(response);
					}else {
						response.data = '';
						response.success = false;
						response.message = "failed";
						res.send(response);
					}
				});
			}
		});
	});		
}
acpController.GetunblkaccessRouteVal = function(req, res){
	var bodyLength = req.body; 
	var projID = bodyLength.PID; 
	var unblkaccesstype = bodyLength.unblkaccesstype; 
	var unblkaccessval = bodyLength.unblkaccessval; 
	
	projModel.getProjectDetail(projID, function (err, data){
		let projectIdentifier = data[0].projectIdentifier;
		appdb.connect(projectIdentifier,function(err) {
			if (err) {
				response.data = '';
				response.success = false;
				response.message = "failed";
				res.send(response); 
			}else{
				acpModel.getunblkaccessRouteFind(unblkaccesstype,unblkaccessval,function(err, datas) {
					if(err || datas==''){ 
						response.data = "";
						response.success = false;
						response.message = "Invalid Datas";
						res.send(response);
					} else {	
						acpModel.getunblkaccessRouteModel(unblkaccesstype,unblkaccessval,function(err, result) {
						if(result){
							response.data = result;
							response.success = true;
							response.message = "IP Address / Username has been unbloked.";
							res.send(response);
						}else {
							response.data = result;
							response.success = false;
							response.message = "Invalid Datas";
							res.send(response);
						} 
						});
					}		 
				});
			}
		});
	});		
} 
acpController.getReportsValue = function(req, res){
	var bodyLength = req.body; 
	var projID = bodyLength.PID; 	  
	projModel.getProjectDetail(projID, function (err, data){
		let projectIdentifier = data[0].projectIdentifier;
		appdb.connect(projectIdentifier,function(err) {
			if (err) {
				response.data = '';
				response.success = false;
				response.message = "failed";
				res.send(response); 
			}else{
				acpModel.getLreportsuser('',function(err, result) {					 
					if(result){
						response.data = result;
						response.success = true;
						res.send(response);
					}else {
						response.data = '';
						response.success = false;
						response.message = "failed";
						res.send(response);
					}
				});
			}
		});
	});		
}

acpController.getuser = function(req, res){
	var bodyLength = req.query; 
	var projID = bodyLength.PID; 
	var userID = bodyLength.userID; 
	
	projModel.getProjectDetail(projID, function (err, data){
		let projectIdentifier = data[0].projectIdentifier;
		appdb.connect(projectIdentifier,function(err) {
			if (err) {
			}else{
				acpModel.getAdminUser(userID,function(err, result) {
					if(err){
						//jsonLogObj["ActivityError"] =  "{ error: "+err.stack+" }";
						//logFunct.QryErrorLogFn(jsonLogObj,fs);
					}else{
						if(result){
							//jsonLogObj['ActivityDataID'] = result._id;
							//delete jsonLogObj['_id'];
							//logFunct.createUpdateLog(jsonLogObj,db,fs,configJSON.ActivityLog);
							//response.message = "Settings saved successfully";
							response.data = result;
							response.success = true;
							res.send(response);
						}else {
							response.data = {};
							response.success = true;
							res.send(response);
						}
					}
				});
			}
		});
	});
}
function IploginstatusCheck(nameKey, myArray){
    for (var i=0; i < myArray.length; i++) {
        if (myArray[i].iplogin_status === nameKey) {
			 
            return true;
        }
    }
	return false;
}

acpController.userLogin = function(req, res, next){
	 var usrName = req.body.usrName;
     var usrPwd = req.body.usrPwd;

	let projectId = req.body.projectIdentifier;		
	let date_ob = new Date();
	let date = ("0" + date_ob.getDate()).slice(-2);
	let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
	let year = date_ob.getFullYear();
	let hours = date_ob.getHours();
	let minutes = date_ob.getMinutes();
	let seconds = date_ob.getSeconds();
	let access_timeval = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds;
	let access_dateval = year + "-" + month + "-" + date;
	let Countdatas_Result = {'user_ip': req.header('x-forwarded-for') || req.connection.remoteAddress, 'username': usrName, 'access_time': access_timeval,'access_date': access_dateval,'server_ip': config.APIGateway.url };
	let CountdatasSuccess_Insert = {'user_ip': req.header('x-forwarded-for') || req.connection.remoteAddress,'username': usrName,'access_time': access_timeval,'access_date': access_dateval,'server_ip': config.APIGateway.url,'iplogin_status': 'SUCCESS','iplogin_reset_status':1};
	let CountdatasFailure_Insert = {'user_ip': req.header('x-forwarded-for') || req.connection.remoteAddress,'username': usrName,'access_time': access_timeval,'access_date': access_dateval,'server_ip': config.APIGateway.url,'iplogin_status': 'FAILURE','iplogin_reset_status':1};
	acppassport.authenticate('local', {session: false}, (err, user,info) => {
		 //console.log(info.message);
	   if(err || !user) {
				acpModel.CountIpLogCheck(Countdatas_Result,function(err, result) {	  
					if(err){ } else {						 
						acpModel.saveIpLogCheck(CountdatasFailure_Insert,function(err, user) { //INSERT STATUS FAILURE
						if(err){ }else{
							if(user){													 
								response.message = "saved successfully";
								response.data = user;
								response.success = true;
							}
						}
						}); 
						let array_elements_count = result.filter(it => it.iplogin_status.includes('FAILURE'));
							if(result!='' && array_elements_count.length>=5) {
							response.count = 0;
							} else {
							response.count = 1;
							}  
							 
							response.success = false;
							response.messageCommon = info.message;
							response.data = '';
							res.send(response);	
							 
			
					}
				});
        }else{
			req.login(user, {session: false}, (err) => {
			   if (err) {
				   response.success = false;
				   response.message = info.message;
				   response.data = '';
				   response.count = 1;
				   res.send(response);			 
			   }else{
					acpModel.CountIpLogCheck(Countdatas_Result,function(err, result) {	  
						if(err){ } else {
							let array_elements_count = result.filter(it => it.iplogin_status.includes('FAILURE'));  
							if(result!='' && array_elements_count.length>=5) {
							   response.count = 0;							  
							} else {
								acpModel.saveIpLogCheck(CountdatasSuccess_Insert,function(err, user) {
								if(err){ }else{
									if(user){													 
										response.message = "saved successfully";
										response.data = user;
										response.success = true;
										
									}
								}
								}); 
							   response.count = 1;							   
							}
						   const token = jwt.sign(user, config.API.secretKey ,{ expiresIn: '30m' });
						   response.success = true;
						   response.data = user;
						   response.uData = user;
						   response.token = token;
						   res.send(response);	
						}
					});
			    }
			}); 
		}
	})(req, res, next)
}


acpController.usrLogCheck = function(req, res,next){
	let projectId = req.body.projectId;
	projModel.getProjectDetail(projectId, function (err, data) {
		if ( err ) {
			response.success =  false;
			response.data = err;
		}else{
			if(data[0]) {
				req.body.projectIdentifier = data[0]['projectIdentifier'];
				acppassport.authenticate('jwt', {session: false}, (err, user,info) => {
					if(user){
						response={
							status: 200,
							success:true,
							message: "success",
							data:user
						}  
					  res.send(response);
					}else{
						response={
							status: 200,
							success:false,
							message: "failed",
							data:'' 
						}
						res.send(response);
					}
				})(req, res, next)
			}
		}
	});
}

acpController.logout = function(req, res){
	req.logout();
	response={
		status: 200,
		success:false,
		message: "success",
		data:''
	};
	res.send(response);
}

acpController.saveDocMgmt = function(req, res,next){
	
	var multer = require('multer');
	var path = require('path');
	var staticDocUploadPath = config.staticDocUpload;
	var storage = multer.diskStorage({
		destination: (req, file, cb) => {
		 projectIdentifier = req.body['projectIdentifier'];
		 
		  mkdirp(staticDocUploadPath+req.body['projectIdentifier'], function(err) { 
			if(err) { } else {
				cb(null, staticDocUploadPath+req.body['projectIdentifier']);
			}
		  });	

		},
		filename: (req, file, cb) => {
		  cb(null,  req.body['doccategory'] + path.extname(file.originalname))  
		}
	});
	var upload = multer({storage: storage});
	var UploadData = upload.single('filed');
	UploadData(req, res, function (err) {
		if(err){
			response={
				status: 200,
				success:false,
				message: "failed1",
				data:''
			}
			res.send(response);
		}else{
			let responseResult = res['req']['file'];
			let projectIdentifier = req.body['projectIdentifier'];
			let docfilename = req.body['doccategory'] + path.extname(req.file.originalname);
			appdb.connect(projectIdentifier,function(err) {
				if (err) {
					response={
						status: 200,
						success:false,
						message: "failed2",
						data:''
					}
					res.send(response);
				}else{
					let date_ob = new Date();
					let date = ("0" + date_ob.getDate()).slice(-2);
					let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
					let year = date_ob.getFullYear();
					let hours = date_ob.getHours();
					let minutes = date_ob.getMinutes();
					let seconds = date_ob.getSeconds();
					let createdDate = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds;
					let dataStaticdoc = {
					 'doccategory': req.body['doccategory'],
					 'docname': req.body['docname'],
					 'docfile': req.body['doccategory'] + path.extname(req.file.originalname),					
					 'docPath': staticDocUploadPath+req.body['projectIdentifier'],
					 'createdDate': createdDate
					};

					acpModel.saveStaticDoc(dataStaticdoc,function(err, result) {
						if(result){
							response={
								status: 200,
								success:true,
								message: "success",
								data:responseResult
							}
							res.send(response);
						}else{
							response={
								status: 200,
								success:false,
								message: "failed3",
								data:''
							}
							res.send(response);
						}
					});
				}
			});
		}
	});
}
acpController.saveDocMgmt_FileUpload = function(req, res){
	let projId = req.body.PID;
	let logo_path = req.body.logoPath;
	let projectIdentifier = req.body.projectIdentifier;
	req.body.projId = projId;
	req.body.projectIdentifier = projectIdentifier;
	
	let date_ob = new Date();
	let date = ("0" + date_ob.getDate()).slice(-2);
	let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
	let year = date_ob.getFullYear();
	let hours = date_ob.getHours();
	let minutes = date_ob.getMinutes();
	let seconds = date_ob.getSeconds();
	let createdDate = year + "-" + month + "-" + date + " " + hours + ":" + minutes + ":" + seconds;
	
	
	req.body = req.body.data;
	req.body.createdDate = createdDate;
	req.body.docPath = logo_path;
			acpModel.saveStaticDoc(req.body, function(err, result) {
				if(result){
					response={
						status: 200,
						success:true,
						message: "success",
						data:result
					}
					res.send(response);
				}else{
					response={
						status: 200,
						success:false,
						message: "failed",
						data:''
					}
					res.send(response);
				}
			});	 
}
acpController.getdocs = function(req, res){
	var bodyLength = req.query; 
	var projID = bodyLength.PID; 
	var projectIdentifier = bodyLength.projectIdentifier; 

	appdb.connect(projectIdentifier,function(err) {
		if (err) {
			response.data = {};
			response.success = false;
			res.send(response);
		}else{
			acpModel.getDocs(function(err, result) {
				if(result){
					//jsonLogObj['ActivityDataID'] = result._id;
					//delete jsonLogObj['_id'];
					//logFunct.createUpdateLog(jsonLogObj,db,fs,configJSON.ActivityLog);
					//response.message = "Settings saved successfully";
					response.data = result;
					response.success = true;
					response.message = 'success';
					res.send(response);
				}else {
					response.data = {};
					response.success = false;
					response.message = 'failed';
					res.send(response);
				}
			});
		}
	});
}
acpController.getRegDetails = function(req, res){
	var bodyLength = req.body; 
	var projID = bodyLength.PID; 
	var projectIdentifier = bodyLength.projectIdentifier; 
	var appRegId = bodyLength.appRegId; 
	appdb.connect(projectIdentifier,function(err) {
		if (err) {
			response={
				status: 200,
				success:false,
				message: "failed",
				data:''
			}
			res.send(response);
		}else{
			acpModel.getRegDetails(appRegId,function(err, result) {
				if(result){
					//jsonLogObj['ActivityDataID'] = result._id;
					//delete jsonLogObj['_id'];
					//logFunct.createUpdateLog(jsonLogObj,db,fs,configJSON.ActivityLog);
					//response.message = "Settings saved successfully";
					response.data = result;
					response.success = true;
					response.message = 'success';
					res.send(response);
				}else {
					response.data = '';
					response.success = false;
					response.message = 'failed';
					res.send(response);
				}
			});
		}
	});
}
acpController.acprightssave = function(req, res){
	const regACLID = req.body.roleIDDet;
	var bodyLength = req.body; 
	var projID = bodyLength.PID; 
	var projectIdentifier = bodyLength.projectIdentifier;    
	appdb.connect(projectIdentifier,function(err) {
		if (err) {
			response={
				status: 200,
				success:false,
				message: "failed",
				data:''
			}
			res.send(response);
		}else{				   
			  var accessdatavalue= {
					PID: req.body.PID,
					projectIdentifier: req.body.projectIdentifier,
					roleID: req.body.dataDets.roleID,
					access: req.body.dataDets.access
				};  
			acpModel.SaveRightAccess(accessdatavalue, regACLID, function (err, result) {	  
				if(err){
					response.message = "Failed to update Rights";
					response.success = false;
					response.data = '';
				}else{
					response.data = req.body['_id'];
					response.message = "Rights added successfully";
					response.success = true;
				}
				res.send(response);
			});
					 
		}
	});
}
acpController.acpRightsgetRole = function(req, res){
	var bodyLength = req.body; 
	var projID = bodyLength.PID; 
	var projectIdentifier = bodyLength.projectIdentifier; 
	var appRegId = bodyLength.appRegId;   
	appdb.connect(projectIdentifier,function(err) {
		if (err) {
			response={
				status: 200,
				success:false,
				message: "failed",
				data:''
			}
			res.send(response);
		}else{
			acpModel.acpRightsgetRole(req.body.roleID, function (err, result) {
			if(err){
				response.data = '';
				response.message = err;
				response.success = false;
			}else{
				if(result[0]){
					response.data = result[0];
					response.success = true;
				}else {
					response.data = {};
					response.message = "No data found";
					response.success = false;
				}
			}
			res.json(response);
			});			 
		}
	});
}
acpController.acpRightsgetRoleAccess = function(req, res){
	 var bodyLength = req.body;  
	var projID = bodyLength.PID; 
	
	var projectIdentifier = bodyLength.projectIdentifier;   
	appdb.connect(projectIdentifier,function(err) {
		if (err) {
			response={
				status: 200,
				success:false,
				message: "failed",
				data:''
			}
			res.send(response);
		}else{
			 /* console.log('---success---');
			 console.log(req.body.roleID); */
			acpModel.acpRightsgetRoleAccess(req.body.roleID,  function (err, result) {
				if(err) {
					response.message = err;
					response.success = false;
					res.send(response);
				} else {
					
					if(result){
					res.send(result[0].access);
					response.success = true;
					} else {
						response.data = {};
						response.message = "No data found";
						response.success = false;
					}
				
					//response.message = "";
					//response.success = true;
					//res.send(result[0].access);
				}
			});		 
		}
	});    
} 
acpController.readviewImage = function(req, res){
	var projectId = req.query.projectIdentifier;
	var staticDocUploadPath = config.staticDocUpload;
	
	projModel.getProjectDetail(projectId, function (err, data) {
		if ( err ) {
			/* response.success =  false;
			response.data = err; */
		}else{
			if(data[0]) {
				let projectIdentifier = data[0]['projectIdentifier'];
				var logoPath = staticDocUploadPath+projectIdentifier+'/logo.jpg';
				res.writeHead(200, {
					'Content-Type' : 'image/jpg'
				});
				if (fs.existsSync(logoPath)) {
					//file exists
					var readStream = fs.createReadStream(logoPath);
				
					readStream.pipe(res); 
					
					readStream.on('end', function() {
						readStream.destroy(); 
						/* if(type == 'bc'){
							let QRimgPath = imgPathDir.
							fs.unlink(imgPath, (err) => {
								// console.log(err);
							});
							fs.unlink(imgPath, (err) => {
								// console.log(err);
							});
						} */
					});
				}
			}
		}
	});
}
module.exports = acpController;