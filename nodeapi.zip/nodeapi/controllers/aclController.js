var express = require('express');
var aclModel = require('../models/aclModel');
var activityLog = require('../helpers/log_function');
//const config = require('../config/config.json')[process.env.NODE_ENV || "development"];
const jwt = require('jsonwebtoken'); 

let aclController = {};
let response = {
 status: 200,
 data: [],
 message: null,
 success: false,
};

aclController.aclSave = function(req, res){
	const regACLID = req.body.roleIDDet;
	req.body = req.body.dataDets;
	  
	if(regACLID!='') {
		aclModel.acl(req.body, regACLID, function (err, result) {
			if(err){
				response.data = '';
				response.message = err;
				response.success = false;
			}else{
				response.data = regACLID;
				response.message = "ACL settings updated successfully";
				response.success = true;
			}
			res.send(response);
		});
	} else {
		/* var accessdatavalue= {
				roleID: req.body.dataDets.roleID,
				access: req.body.dataDets.access
			}; */
		aclModel.acl(req.body, '', function (err, result) {
			  
			if(err){
				//error
				response.message = "Problem in acl creating";
				response.success = false;
				response.data = '';
			}else{
				response.data = req.body['_id'];
				response.message = "ACL settings added successfully";
				response.success = true;
			}
			res.send(response);
		});
	}
}

aclController.aclGet = function(req, res){
	var bodyLength = req.query; 
	aclModel.aclGet(req.query.roleID, function (err, result) {
		if(err){
			response.data = '';
			response.message = err;
			response.success = false;
		}else{
			if(result[0]){
				response.data = result[0];
				response.success = true;
			}else {
				response.data = {};
				response.message = "No data found";
				response.success = false;
			}
		}
		res.json(response);
	});
}

module.exports = aclController;