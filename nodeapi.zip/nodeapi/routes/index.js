const express = require("express");
const router = express.Router();

//Route files
const userRoutes = require('./user.js');
const accountRoutes = require('./account.js');
const applnRoutes = require('./application.js');
const projRoutes = require('./project.js');
const ruleengineRoutes = require('./ruleengine.js');
const aclRoutes = require('./acl.js');
const ageRoutes = require('./age.js');
const acpRoutes = require('./acp.js');
const reportsRoutes = require('./reports.js');
const DependentRoutes = require('./dependent.js');

//router.use("/", rootRoutes);
router.use("/user", userRoutes);
router.use("/account", accountRoutes);
router.use("/application", applnRoutes);
router.use("/account/project", projRoutes);
router.use("/ruleengine", ruleengineRoutes);
router.use("/acl", aclRoutes);
router.use("/age", ageRoutes);
router.use("/acp", acpRoutes);
router.use("/account/project/reports", reportsRoutes);
router.use("/dependent", DependentRoutes);

module.exports = router;