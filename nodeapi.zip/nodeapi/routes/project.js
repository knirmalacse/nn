const express = require("express");
const projController = require("../controllers/projController");
const router = express.Router();
const validator = require('express-validator');
const middlewares = require('../middlewares');
const validation = require('../helpers/validation');
const customValidation = require('../helpers/customValidation');

var db = require('../db/db');
var dbConn = db.get();

router.use(validator(customValidation));

router.post("/",middlewares.checkToken,validation.project,projController.createProject);
router.get("/",middlewares.checkToken,projController.getProject);
router.get("/projectDetails",projController.getProjectDetail);
router.post("/projectSetting",middlewares.checkToken,validation.projectSetting,projController.createProjectSetting);
router.get("/projectSetting",/* middlewares.checkToken, */projController.getProjectSetting);
router.delete("/",middlewares.checkToken,projController.deleteProject);

module.exports = router;