const express = require("express");
const dependentController = require("../controllers/dependentController");
const router = express.Router();
const validator = require('express-validator');
const middlewares = require('../middlewares');
const validation = require('../helpers/validation');
const customValidation = require('../helpers/customValidation');

const multer = require('multer');

var storage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, 'public/uploads')
    },
    filename: (req, file, cb) => {
      cb(null, Date.now()+ '-' +file.originalname  )
    }
});
const upload = multer({storage: storage});


var db = require('../db/db');
var dbConn = db.get();

//router.get("/",dependentController.getDependentFldData);
router.post("/saveData",middlewares.checkToken, upload.single('depData'),dependentController.saveFldData);
router.post("/getListData",middlewares.checkToken,dependentController.getFldData);
router.post("/dataMapping",middlewares.checkToken,dependentController.dataMapping);


module.exports = router;