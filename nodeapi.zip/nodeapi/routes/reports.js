const express = require("express");
const reportsController = require("../controllers/reportsController");
const router = express.Router();
const validator = require('express-validator');
const middlewares = require('../middlewares');
const validation = require('../helpers/validation');
const customValidation = require('../helpers/customValidation');

var db = require('../db/db');
var dbConn = db.get();

router.use(validator(customValidation));

router.get("/",middlewares.checkToken,reportsController.getReportsFieldWise);
router.get("/download",middlewares.checkToken,reportsController.getDownloadDataFieldWise);

module.exports = router;