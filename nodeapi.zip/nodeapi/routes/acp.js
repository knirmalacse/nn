const express = require("express");
const acpController = require("../controllers/acpController");
const applnController = require("../controllers/applnController");
const projController = require("../controllers/projController");
const reportsController = require("../controllers/reportsController");
const router = express.Router();
const validator = require('express-validator');
const middlewares = require('../middlewares');
const customValidation = require('../helpers/customValidation');
const validation = require('../helpers/validation');
const emailsettingController = require("../controllers/emailsettingController");
 
router.use(validator(customValidation));
var db = require('../db/db');
var dbConn = db.get();
var acppassport = require('../acppassport');
router.post("/login",validation.acplogin,acpController.userLogin);
router.post("/usrLogCheck",acpController.usrLogCheck);
router.get('/logout', 
    acppassport.authenticate('jwt', { 
     /*    successRedirect: '/',
        failureRedirect: '/404' */
    }),
    acpController.logout // accepts (req, res, next)
);
router.post("/userMgmt",acppassport.authenticate('jwt', {}),validation.acpuserMgmt,acpController.userMgmt);
router.get("/userMgmt",acppassport.authenticate('jwt', {}),acpController.getuserAdmin);
router.post("/lSearch",acppassport.authenticate('jwt', {}),acpController.getLsearchuser);
router.post("/GetunblkaccessRoute",acppassport.authenticate('jwt', {}),acpController.GetunblkaccessRouteVal);
router.post("/GetReports",acppassport.authenticate('jwt', {}),acpController.getReportsValue);
router.get("/user",acppassport.authenticate('jwt', {}),acpController.getuser);
router.post("/saveDocMgmt",acpController.saveDocMgmt);
router.post("/saveDocMgmt_FileUpload",acpController.saveDocMgmt_FileUpload);
router.get("/docMgmt",acppassport.authenticate('jwt', {}),acpController.getdocs);
router.post("/getRegDetails",acpController.getRegDetails);
router.get("/getAppln",applnController.getAppln);
router.post("/projectSetting",projController.createProjectSetting);/** JWT Passport Validation & Field validations are inside of this function**/
router.post("/projectSetting_FileUpload",projController.createProjectSetting_FileUpload);
router.post("/acp_rightssave",acppassport.authenticate('jwt', {}),acpController.acprightssave);
router.post("/acp_getRole",acppassport.authenticate('jwt', {}),acpController.acpRightsgetRole);
router.post("/acp_getRoleAccess",acppassport.authenticate('jwt', {}),acpController.acpRightsgetRoleAccess);
router.post("/addEditEmail",acppassport.authenticate('jwt', {}),validation.emailsettingAddEdit,emailsettingController.addEditEmail);
router.post("/getNotificationById",acppassport.authenticate('jwt', {}),validation.fetchOneById,emailsettingController.getNotificationById);
router.get("/readviewImage",acpController.readviewImage);
module.exports = router;
 