const express = require("express");
const userController = require("../controllers/userController");
const router = express.Router();
const validator = require('express-validator');
const middlewares = require('../middlewares');
const validation = require('../helpers/validation');
const customValidation = require('../helpers/customValidation');

var db = require('../db/db');
var dbConn = db.get();

router.use(validator(customValidation));
router.post("/login",validation.login,middlewares.checkCaptcha,userController.userLogin);

//user CRUD
router.post("/",middlewares.checkToken,validation.userAddEdit,userController.createUser);
router.put("/",middlewares.checkToken,validation.userStatus,userController.editUser);
router.get("/",middlewares.checkToken,userController.getUser);
router.delete("/",middlewares.checkToken,userController.deleteUser);
router.post("/forgot",validation.userForget,userController.forgotUser);
router.post("/forgotreset",validation.passwordReset,userController.passwordReset);

router.post("/captcha",userController.checkCaptcha);

//user Role
router.get("/role",middlewares.checkToken,userController.getUserRole);
router.post("/role",middlewares.checkToken,validation.userRole,userController.createUserRole);
router.put("/role",middlewares.checkToken,validation.userRole,userController.editUserRole);

router.post("/roles/data",middlewares.checkToken,userController.getUserRoleData);

//user Role Permission
router.get("/role/PermissionSet",middlewares.checkToken,userController.getUserAccess);
router.put("/role/PermissionSet",middlewares.checkToken,userController.editUserAccess);

router.get("/usrLogCheck",middlewares.checkToken,userController.checkUserLogin); 
router.get("/usrDetails",middlewares.checkToken,userController.getLoggedUserData); 
router.get("/logout",middlewares.checkToken,userController.logout);

module.exports = router;