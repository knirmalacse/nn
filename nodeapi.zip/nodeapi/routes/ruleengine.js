const express = require("express");
const ruleengineController = require("../controllers/ruleengineController");
const router = express.Router();
const validator = require('express-validator');
const middlewares = require('../middlewares');
const validation = require('../helpers/validation');
const customValidation = require('../helpers/customValidation');

var db = require('../db/db');
var dbConn = db.get();

router.post("/ruleengineSubmit",middlewares.checkToken,validation.ruleengine,ruleengineController.ruleengine);
router.get("/getruleengineSubmit",middlewares.checkToken,ruleengineController.getruleengine);
router.get("/getruleengineByIdSubmit",middlewares.checkToken,ruleengineController.getruleengineById);
router.post("/delruleengineSubmit",middlewares.checkToken,ruleengineController.delruleengine);
router.get("/getageRelaxationListSubmit",middlewares.checkToken,ruleengineController.getageRelaxationList);
router.post("/addageruleengineSubmit",middlewares.checkToken,ruleengineController.addageruleengine);
router.post("/workexpSubmit",middlewares.checkToken,ruleengineController.ruleworkexpAdd);
router.get("/workexpDetSubmit",middlewares.checkToken,ruleengineController.ruleworkexpEdit);

module.exports = router;