const express = require("express");
const ageController = require("../controllers/ageController");
const router = express.Router();
const validator = require('express-validator');
const middlewares = require('../middlewares');
const validation = require('../helpers/validation');
const customValidation = require('../helpers/customValidation');

var db = require('../db/db');
var dbConn = db.get();

router.post("/",middlewares.checkToken,ageController.saveAgeConfig);
router.get("/",middlewares.checkToken,ageController.getAgeConfig);

module.exports = router;