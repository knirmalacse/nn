const express = require("express");
const applnController = require("../controllers/applnController");
const router = express.Router();
const validator = require('express-validator');
const middlewares = require('../middlewares');
const validation = require('../helpers/validation');
const customValidation = require('../helpers/customValidation');

router.post("/",middlewares.checkToken,validation.applnMapping,applnController.saveAppln);
router.get("/",middlewares.checkToken,applnController.getAppln);
router.post("/submitFormioApp",middlewares.checkToken,applnController.getApplnData);

router.get("/accounts",middlewares.checkToken,applnController.getAccounts);
router.post("/projects",middlewares.checkToken,applnController.getAccProject);


module.exports = router;