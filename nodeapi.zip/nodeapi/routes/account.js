const express = require("express");
const accountController = require("../controllers/accountController");
const router = express.Router();
const validator = require('express-validator');
const middlewares = require('../middlewares');
const validation = require('../helpers/validation');
const customValidation = require('../helpers/customValidation');

var db = require('../db/db');
var dbConn = db.get();

router.use(validator(customValidation)); 

//user CRUD
router.post("/",middlewares.checkToken,validation.accountAddEdit,accountController.createAccount);
router.put("/",middlewares.checkToken,validation.accountStatus,accountController.editAccount);
router.get("/",middlewares.checkToken,accountController.getAccount);
router.delete("/",middlewares.checkToken,accountController.deleteAccount);

router.get("/accountDetails",middlewares.checkToken,accountController.getAccountDetails);


module.exports = router;