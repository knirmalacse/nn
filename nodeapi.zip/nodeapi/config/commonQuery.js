"use strict";
module.exports = {
    dbConnStart: dbConnStart,
    dbConnClose: dbConnClose,
    insertDocument:insertDocument,
    updateDocument: updateDocument,
    fetchOneDocument: fetchOneDocument,
    fetchAllDocument: fetchAllDocument,
    fetchAggregate : fetchAggregate
};
// Start Connection 
function dbConnStart(appdb, projectIdentifier){
    return new Promise((resolve, reject)=>{
        appdb.connect(projectIdentifier,function(err, result) {
            if (err) {
               reject(err);
           } else {
               console.log("fdfdfdfd ",result)
               resolve('success');
           }
       });
    })
}
// Stop Connection 
function dbConnClose(appdb){
    return new Promise((resolve, reject)=>{
        appdb.close(function(err){
            if (err) {
                reject(err);
            } else {
                resolve('closed');
            }
        });
    })
}
// Insert Query
function insertDocument(modelName,data){
	return new Promise((resolve, reject)=>{ 
        // data._id= ObjectId("5dad54350f7b7b7b956246e8");
		modelName.insert(data,function(err, docs) {
            if(err) {
                console.log("error ",err)
                reject(err)
            } 
			resolve(docs)
		})
	})
}  

// update Document
function updateDocument(modelName,cond,data){
    return new Promise((resolve, reject)=> {
        console.log("data ",data)
        console.log("cond ",cond)
        modelName.update(cond,{$set:data},function(err, docs) {
            if(err) {
                console.log("error ",err)
                reject(err)
            } 
			resolve(docs)
		})
    })
}

//Fetch One document 
function fetchOneDocument(modelName,cond){
    return new Promise((resolve, reject)=> { 
        console.log("cond ",cond)
        modelName.findOne(cond,function(err, docs) {
            if(err) {
                console.log("error ",err)
                reject(err)
            } 
			resolve(docs)
		})
    })
}
//Fetch All document 
function fetchAllDocument(modelName,cond){
    return new Promise((resolve, reject)=> { 
        console.log("cond ",cond)
        modelName.find(cond,function(err, docs) {
            if(err) {
                console.log("error ",err)
                reject(err)
            } 
			resolve(docs)
		})
    })
}

//Fetch All query 
function fetchAggregate(modelName, aggrcond){
    return new Promise((resolve, reject)=> {  
        modelName.aggregate(aggrcond,function(err, docs) {
            if(err) {
                console.log("error ",err)
                reject(err)
            } 
			resolve(docs)
		})
    })
}