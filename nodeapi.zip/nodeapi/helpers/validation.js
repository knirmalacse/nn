var express = require('express');
var router = express.Router();

const validator = require('express-validator');
const { check, oneOf, validationResult } = require('express-validator/check');
const { matchedData, sanitize } = require('express-validator/filter');
const ObjectID = require("mongodb").ObjectID;

const lowerCaseChange = (s) => {
  if (typeof s !== 'string') return ''
  //return s.charAt(0).toUpperCase() + s.slice(1) // 1st letter uppercase
  return s.toLowerCase() // all letter lowercase
}

let response = {
 status: 200,
 data: [],
 message: null,
 success: false,
};
let validation = {};

validation.login = function(req, res, next) {
	const errorFormatter = ({ location, msg, param, value }) => {
		// Build your resulting errors however you want! String, object, whatever - it works!
		return `${msg}`;
	};
	req.check("usrName")
		.notEmpty().withMessage("Please enter Email Address")
		.isEmail().withMessage("Please enter a valid Email Address");
	req.assert('usrPwd', 'Please enter Password')
		.notEmpty();
	var errors = req.validationErrors();
	const results = validationResult(req).formatWith(errorFormatter);
	if (errors) {
		response.message = results.mapped();
		response.success = false;
		res.send(response);
	} else {
		next();
	}
}
validation.userForget = function(req, res, next) {
	const errorFormatter = ({ location, msg, param, value }) => {
		// Build your resulting errors however you want! String, object, whatever - it works!
		return `${msg}`;
	};
	//console.log(req.body);
	let formJSON = req.body.formJSON;
	req.body = JSON.parse(req.body.formJSON);
	req.checkBody('EmailID', "Please enter  email address.").notEmpty();
	req.checkBody('EmailID', "Please enter valid email address.").isEmail();
	
	req.asyncValidationErrors().then(() => {
		//req.body.formUID = regID;
		req.body.formJSON = formJSON;
		next();
	}).catch((errors) => {
		const results = validationResult(req).formatWith(errorFormatter);
		response.success = false;
		response.message = results.mapped();
		/* if(JSON.stringify(response.message)=='{}'){
			jsonLogObj["ActivityError"] = "{ error: "+errors.stack+" }";
			logFunct.QryErrorLogFn(jsonLogObj,fs);
		} */
		res.send(response);
	});
}
validation.passwordReset = function(req, res, next) {
	const errorFormatter = ({ location, msg, param, value }) => {
		// Build your resulting errors however you want! String, object, whatever - it works!
		return `${msg}`;
	};
	//console.log(req.body);
	let formJSON = req.body.formJSON;
	req.body = JSON.parse(req.body.formJSON);	
	//req.body = req.body.formJSON;
	req.checkBody('EmailID', "Please enter  email address.").notEmpty();
	req.checkBody('EmailID', "Please enter valid email address.").isEmail();
	
	req.checkBody('Code', "Please enter Code").notEmpty();
	req.checkBody('Code', "Code should more than 4 characters").isLength({ min: 4 });
	
	req.checkBody('Password', "Please enter  Password").notEmpty();
	req.checkBody('Password', "Password should more than 4 characters").isLength({ min: 4 });
		
	req.checkBody('frmPassword2', "Please enter Confirm Password").notEmpty();
	req.checkBody('frmPassword2', "Confirm Password should more than 4 characters").isLength({ min: 4 });
	req.check('frmPassword2', 'Confirm Password must have the same value as the password').custom((value) => value === req.body.Password);
	
	req.asyncValidationErrors().then(() => {
		req.body.formJSON = formJSON;
		next();
	}).catch((errors) => {
		const results = validationResult(req).formatWith(errorFormatter);
		response.success = false;
		response.message = results.mapped();
		
		res.send(response);
	});
}
validation.userAddEdit = function(req, res, next) {
	const errorFormatter = ({ location, msg, param, value }) => {
		// Build your resulting errors however you want! String, object, whatever - it works!
		return `${msg}`;
	};
	
	const regID = req.body.formUID;
	let formJSON = req.body.formJSON;
	req.body = JSON.parse(req.body.formJSON);	
	req.checkBody('UserName', "Please enter  Display Name.").notEmpty();
	//req.checkBody('frmusername', "This User Name is already in use").isUserNameExists({usernm: req.body.frmusername, uid : regID});	
	if(regID == ''){
		req.checkBody('EmailID', "Please enter  email address.").notEmpty();
		req.checkBody('EmailID', "Please enter valid email address.").isEmail();
		req.checkBody('EmailID', "This email is already in use").isEmailExists({usernm: req.body.EmailID, uid : regID});
	}
	
	
	req.checkBody('Password', "Please enter  Password").notEmpty();
	req.checkBody('Password', "Password should more than 4 characters").isLength({ min: 4 });
		
	req.checkBody('frmPassword2', "Please enter Confirm Password").notEmpty();
	req.checkBody('frmPassword2', "Confirm Password should more than 4 characters").isLength({ min: 4 });
	req.check('frmPassword2', 'Confirm Password must have the same value as the password').custom((value) => value === req.body.Password);
	
	req.checkBody('Mobile', "Please enter Mobile No").notEmpty();	
	req.check('Mobile','Invalid Mobile No').isInt(10).isLength({ min: 10, max:10 });
	req.checkBody('Mobile', "Mobile No already in use").isMobileExists({usernm: req.body.Mobile, uid : regID});
	
	req.checkBody('UserRole', "Please select User Type").notEmpty();	
	req.check('UserRole','Invalid User Type').isIn(['1', '2', '3', '4','5']);
	
	req.checkBody('status', "Please select Status").notEmpty();
	req.check('status','Invalid Status').isIn(['Y', 'N']);
	
	req.asyncValidationErrors().then(() => {
		req.body.formUID = regID;
		req.body.formJSON = formJSON;
		next();
	}).catch((errors) => {
		const results = validationResult(req).formatWith(errorFormatter);
		response.success = false;
		response.message = results.mapped();
		/* if(JSON.stringify(response.message)=='{}'){
			jsonLogObj["ActivityError"] = "{ error: "+errors.stack+" }";
			logFunct.QryErrorLogFn(jsonLogObj,fs);
		} */
		res.send(response);
	});
}

validation.userStatus = function(req, res, next) {
	const errorFormatter = ({ location, msg, param, value }) => {
		// Build your resulting errors however you want! String, object, whatever - it works!
		return `${msg}`;
	};
	
	req.check('status','Invalid Status').isIn(['Y', 'N']);	
	var errors = req.validationErrors();
	const results = validationResult(req).formatWith(errorFormatter);
	if (errors) {
		response.message = results.mapped();
		response.success = false;
		res.send(response);
	} else {
		next();
	}
}

validation.accountAddEdit = function(req, res, next) {
	const errorFormatter = ({ location, msg, param, value }) => {
		// Build your resulting errors however you want! String, object, whatever - it works!
		return `${msg}`;
	  };
    req.header('Cache-Control', 'no-cache');
	const accID = req.body.AID;
	console.log('---accID--');
	console.log(accID);
	// const userName = req.body.curUsr.frmusername;
	// const userName = req.session.usrName;
	const curUsrName = req.payload._id;
	let formJSON = req.body.formJSON;
	req.body = JSON.parse(req.body.formJSON);	
	 
	
	var accname = lowerCaseChange(req.body.accountName); 

		req.checkBody('accountName', "Please enter Account Name.").notEmpty();
	req.checkBody('accountName', " Account Name should more than 4 characters or less than 50 characters").isLength({ min: 4, max:50 });
		req.checkBody('accountName', "This AccountName is already in use").isAccountNameExists({accountName: accname, uid : accID});
	 	  
	req.checkBody('registrationType', "Please select Registration Type").notEmpty();	
	req.check('registrationType','Invalid Registration Type').isIn(['1', '2']);
	
	req.checkBody('accountDetails', "Please enter Account Details.").notEmpty();
	req.checkBody('accountDetails', " Account Details should more than 4 characters or less than 100 characters").isLength({ min: 4, max:100 });
	
	req.checkBody('accountDomain', "Please enter Account Domain.").notEmpty();
	req.check("accountDomain", "Invalid Account Domain").matches(/^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$/gm, "i"); 
	
	req.asyncValidationErrors().then(() => {
		req.body.AID = accID;
		req.body.formJSON = formJSON;
		next();
	}).catch((errors) => {
		const results = validationResult(req).formatWith(errorFormatter);
		response.success = false;
		response.message = results.mapped();
		/* if(JSON.stringify(response.message)=='{}'){
			jsonLogObj["ActivityError"] = "{ error: "+errors.stack+" }";
			logFunct.QryErrorLogFn(jsonLogObj,fs);
		} */
		res.send(response);
	});
}



validation.accountStatus = function(req, res, next) {
	const errorFormatter = ({ location, msg, param, value }) => {
		// Build your resulting errors however you want! String, object, whatever - it works!
		return `${msg}`;
	};
	
	req.check('status','Invalid Status').isIn(['Y', 'N']);	
	var errors = req.validationErrors();
	const results = validationResult(req).formatWith(errorFormatter);
	if (errors) {
		response.message = results.mapped();
		response.success = false;
		res.send(response);
	} else {
		next();
	}
}

validation.userRole = function(req, res, next) {
	const errorFormatter = ({ location, msg, param, value }) => {
		// Build your resulting errors however you want! String, object, whatever - it works!
		return `${msg}`;
	};
	
	req.body = JSON.parse(req.body.Role);	
	var whereCond = {};
	req.checkBody('role', "Please enter role").notEmpty();
	req.checkBody('role', "Role should be unique").isUniqueExists({tableName: 'acl',fieldName: "role", fieldValue: req.body.role,whereCond : whereCond});
		
	req.asyncValidationErrors().then(() => {
		next();
	}).catch((errors) => {
		const results = validationResult(req).formatWith(errorFormatter);
		response.success = false;
		response.message = results.mapped();
		res.send(response);
	});
}

validation.applnMapping = function(req, res, next) {
	const errorFormatter = ({ location, msg, param, value }) => {
		// Build your resulting errors however you want! String, object, whatever - it works!
		return `${msg}`;
	};
	
	let accID = req.body.formVal.accountName;
	let projID = req.body.formVal.projectName;
	let appln = req.body.formJson;
	req.body.formVal.formJson = req.body.formJson;
	req.body = req.body.formVal;	
	req.checkBody('accountName', "Please select Account Name.").notEmpty();
	req.checkBody('projectName', "Please select Project Name.").notEmpty();
		
	req.asyncValidationErrors().then(() => {
		next();
	}).catch((errors) => {
		const results = validationResult(req).formatWith(errorFormatter);
		response.success = false;
		response.message = results.mapped();
		res.send(response);
	});
}
const capitalize = (s) => {
  if (typeof s !== 'string') return ''
  //return s.charAt(0).toUpperCase() + s.slice(1) // 1st letter uppercase
  return s.toUpperCase() // all letter uppercase
}
validation.project = function(req, res, next) {
	const errorFormatter = ({ location, msg, param, value }) => {
		// Build your resulting errors however you want! String, object, whatever - it works!
		return `${msg}`;
	};
	
	let accID = req.body.AID;
	let projID = req.body.PID;
	
	 
	
	let formJSON = req.body.formJSON;
	req.body = JSON.parse(req.body.formJSON);
	
	req.checkBody('projectName', "Please enter Project Nameee.").notEmpty();
	req.checkBody('projectName', " Project Name should more than 4 characters or less than 50 characters").isLength({ min: 4, max:100 });
	var whereCond = {_id: ObjectID(accID),status : 'Active', 'project.status' : 'Active'};
	if(projID){
		var whereCond = {_id: ObjectID(accID),status : 'Active', 'project.status' : 'Active', 'project._projectid': {$ne: ObjectID(projID)}};
	}
	req.checkBody('projectIdentifier', "Please enter Project Identifier.").notEmpty();
	req.checkBody('projectIdentifier', " Project Identifier should more than 4 characters or less than 50 characters").isLength({ min: 4, max:50 });
	
	req.checkBody('projectIdentifier', "This Project Identifier is already in use").isUniqueExistsAggre({tableName: 'account',fieldName: "project.projectIdentifier", fieldValue: req.body.projectIdentifier, uid : projID, whereCond : whereCond});
	
	req.checkBody('projectDetails', "Please enter Project Details.").notEmpty();
	req.checkBody('projectDetails', " Project Details should more than 4 characters or less than 100 characters").isLength({ min: 4, max:100 });
	
	
    var genericServiceValid = [ 'hasEmail', 'hasSms', 'hasCaptcha', 'hasBarcode', 'hasUploads', 'hasPayment' ];
    var genericComponentsValid = [ 'hasRegistration', 'hasReRegistration', 'hasCallletter', 'hasResults' ];
	console.log('service'+req.body.projectServices);
	//if(!req.body.projectServices){
		req.check('projectServices', "Please select Project Services.").isArrayEmpty({ fieldValue: req.body.projectServices, arrayCheck : genericServiceValid});
		//req.check('projectServices','Invalid Project Services').isIn(['hasEmail', 'hasSms']);
		req.check('projectServices','Invalid Project Services').isArrayExistsProj({ fieldValue: req.body.projectServices, arrayCheck : genericServiceValid}); 
		
		req.check('projectComponents', "Please select Project Components.").isArrayEmpty({ fieldValue: req.body.projectComponents, arrayCheck : genericComponentsValid});
		req.check('projectComponents','Invalid Project Components').isArrayExistsProj({ fieldValue: req.body.projectComponents, arrayCheck : genericComponentsValid}); 
	//}
		
	req.asyncValidationErrors().then(() => {
		req.body.AID = accID;
		req.body.PID = projID;
		req.body.formJSON = formJSON;
		next();
	}).catch((errors) => {
		const results = validationResult(req).formatWith(errorFormatter);
		response.success = false;
		response.message = results.mapped();
		res.send(response);
	});
}

validation.ruleengine = function(req, res, next) {
	const errorFormatter = ({ location, msg, param, value }) => {
			return `${msg}`;
		};
	
		const accID = req.body.formVal.accountName;
		const projID = req.body.formVal.projectName;
		const appendField = req.body.formVal.appendField;
		const appendFieldLabel = req.body.formVal.appendFieldLabel;
		const querybuiderconfig = req.body.formVal.querybuiderconfig;
		const query = req.body.formVal.query;
		const rulesJsonLogic = req.body.formVal.rulesJsonLogic;
		const ruleFor = req.body.formVal.ruleFor;
		
		req.body = req.body.formVal;	
		req.body.createdBy = 'User';
		req.body.createdDate = new Date(Date.now()); 
		req.body.rule_status = 'Active'; 
	
		req.checkBody('accountName', "Please select Account Name.").notEmpty();
		req.checkBody('projectName', "Please select Project Name.").notEmpty();
		req.checkBody('appendFieldLabel', "Please select append Field").notEmpty();
		req.checkBody('query', "Please enter rule").notEmpty();
		req.checkBody('rulesJsonLogic', "Please enter rule").notEmpty();
		req.checkBody('ruleFor', "Please enter Rule For").notEmpty();
		
	 
	req.asyncValidationErrors().then(() => {
		//req.body = req.body.formVal;	
		//req.body.formVal = req.body;	
		next();
	}).catch((errors) => {
		const results = validationResult(req).formatWith(errorFormatter);
		response.success = false;
		response.message = results.mapped();
		res.send(response);
	});
}

validation.acl = function(req, res, next) {
	const errorFormatter = ({ location, msg, param, value }) => {
		// Build your resulting errors however you want! String, object, whatever - it works!
		return `${msg}`;
	};
	
	let regACLID = req.body.roleIDDet;
	let dataDets = req.body.dataDets;
	req.body = req.body.dataDets;
	req.checkBody('roleID', "Please select User Type.").notEmpty();
	
	req.asyncValidationErrors().then(() => {
		req.body.roleIDDet = regACLID;
		req.body.dataDets = dataDets;
		next();
	}).catch((errors) => {
		const results = validationResult(req).formatWith(errorFormatter);
		response.success = false;
		response.message = results.mapped();
		res.json(response);
	});
}

validation.projectSetting = function(req, res, next) {
	const errorFormatter = ({ location, msg, param, value }) => {
		return `${msg}`;
	};
	
	var projId = req.body.projId;
	var projectIdentifier = req.body.projectIdentifier;
	var logoUp = req.body.logoUp;
	//req.checkBody('filed', "Please Upload Application Logo").notEmpty();
	
	var formData = JSON.parse(req.body.formData);
	//let formData = req.body.formData;
	req.body = formData;
	req.checkBody('appStartDate', "Please Select Start Date").isValidDate(req.body.appStartDate);
	req.checkBody('appEndDate', "Please Select End Date").isValidDate(req.body.appEndDate);
	
	req.checkBody('appEndDate', "End Date should be greater than Start date").compareDateNotequal({'date1':req.body.appStartDate,'date2':req.body.appEndDate,'date1Hour':req.body.appStartTimeHour,'date1Min':req.body.appStartTimeMin,'date1Sec':req.body.appStartTimeSec,'date2Hour':req.body.appEndTimeHour,'date2Min':req.body.appEndTimeMin,'date2Sec':req.body.appEndTimeSec});
	
	req.checkBody('appPrintCloseDate', "Please Select Re-print Close Date").isValidDate(req.body.appPrintCloseDate);
	
	req.checkBody('appPrintCloseDate', "Re-print Date should be greater than End date").compareDate({'date1':req.body.appEndDate,'date2':req.body.appPrintCloseDate,'date2Hour':req.body.appPrintCloseTimeHour,'date2Min':req.body.appPrintCloseTimeMin,'date2Sec':req.body.appPrintCloseTimeSec,'date1Hour':req.body.appEndTimeHour,'date1Min':req.body.appEndTimeMin,'date1Sec':req.body.appEndTimeSec});
	
	/* req.checkBody('appPrintCloseDate', "Re-print Date should be greater than Start date").compareDate({'date1':req.body.appStartDate,'date2':req.body.appPrintCloseDate,'date2Hour':req.body.appPrintCloseTimeHour,'date2Min':req.body.appPrintCloseTimeMin,'date2Sec':req.body.appPrintCloseTimeSec,'date1Hour':req.body.appStartTimeHour,'date1Min':req.body.appStartTimeMin,'date1Sec':req.body.appStartTimeSec}); */
	
	req.checkBody('appStatus', "Please Select Application Mode").isBtnSel(req.body.appStatus);
	if(req.body.appStatus == 'N')
		req.checkBody('privateIp', "Please Enter Private IP's").notEmpty();
	req.checkBody('appFromEmail', "Please Enter From Email").notEmpty();
	req.checkBody('appBounceEmail', "Please Enter Bounce Email").notEmpty();
	req.checkBody('appSMSSenderId', "Please Enter SMS Sender ID").notEmpty();
	req.checkBody('appMobNo', "Please Enter Mobile Numbers").notEmpty();
	req.checkBody('appEmailId', "Please Enter Email IDs").notEmpty();
	/* if()
	req.checkBody('appReplyEmail', "Please Enter Bounce Email").notEmpty(); */
	
	req.checkBody('appSMSService', "Please Select Enable SMS service").isBtnSel(req.body.appSMSService);
	//req.checkBody('appEmailService', "Please Select Enable Email service").isBtnSel(req.body.appEmailService);
	req.checkBody('appCapthchaService', "Please Select Enable Application Captcha").isBtnSel(req.body.appCapthchaService);
	
	if(logoUp == 'Y'){
		//req.checkBody('file', "Please upload application logo").notEmpty();
	}
	
	
	req.asyncValidationErrors().then(() => {
		//console.log("in next");
		req.body.projId = projId;
		req.body.projectIdentifier = projectIdentifier;
		req.body.formData = formData;
		//next();
		return next(); 
	}).catch((errors) => {
		//console.log("in validation");
		const results = validationResult(req).formatWith(errorFormatter);
		response.success = false;
		response.message = results.mapped();
		res.json(response);
	});
	
}
validation.projectSetting_FileUpload = function(req, res, next) {
	const errorFormatter = ({ location, msg, param, value }) => {
		return `${msg}`;
	};
	
	var projId = req.body.projId;
	var projectIdentifier = req.body.projectIdentifier;
	let formData = req.body.data;
	 
	req.body = req.body.data;
	console.log('---req.body req.body---');
	console.log(req.body);
	req.checkBody('appStartDate', "Please Select Start Date").isValidDate(req.body.appStartDate);
	req.checkBody('appEndDate', "Please Select End Date").isValidDate(req.body.appEndDate);
	
	req.checkBody('appEndDate', "End Date should be greater than Start date").compareDateNotequal({'date1':req.body.appStartDate,'date2':req.body.appEndDate,'date1Hour':req.body.appStartTimeHour,'date1Min':req.body.appStartTimeMin,'date1Sec':req.body.appStartTimeSec,'date2Hour':req.body.appEndTimeHour,'date2Min':req.body.appEndTimeMin,'date2Sec':req.body.appEndTimeSec});
	
	req.checkBody('appPrintCloseDate', "Please Select Re-print Close Date").isValidDate(req.body.appPrintCloseDate);
	
	req.checkBody('appPrintCloseDate', "Re-print Date should be greater than End date").compareDate({'date1':req.body.appEndDate,'date2':req.body.appPrintCloseDate,'date2Hour':req.body.appPrintCloseTimeHour,'date2Min':req.body.appPrintCloseTimeMin,'date2Sec':req.body.appPrintCloseTimeSec,'date1Hour':req.body.appEndTimeHour,'date1Min':req.body.appEndTimeMin,'date1Sec':req.body.appEndTimeSec});
	
	/* req.checkBody('appPrintCloseDate', "Re-print Date should be greater than Start date").compareDate({'date1':req.body.appStartDate,'date2':req.body.appPrintCloseDate,'date2Hour':req.body.appPrintCloseTimeHour,'date2Min':req.body.appPrintCloseTimeMin,'date2Sec':req.body.appPrintCloseTimeSec,'date1Hour':req.body.appStartTimeHour,'date1Min':req.body.appStartTimeMin,'date1Sec':req.body.appStartTimeSec}); */
	
	req.checkBody('appStatus', "Please Select Application Mode").isBtnSel(req.body.appStatus);
	if(req.body.appStatus == 'N')
		req.checkBody('privateIp', "Please Enter Private IP's").notEmpty();
	req.checkBody('appFromEmail', "Please Enter From Email").notEmpty();
	req.checkBody('appBounceEmail', "Please Enter Bounce Email").notEmpty();
	req.checkBody('appSMSSenderId', "Please Enter SMS Sender ID").notEmpty();
	req.checkBody('appMobNo', "Please Enter Mobile Numbers").notEmpty();
	req.checkBody('appEmailId', "Please Enter Email IDs").notEmpty();
	/* if()
	req.checkBody('appReplyEmail', "Please Enter Bounce Email").notEmpty(); */
	
	req.checkBody('appSMSService', "Please Select Enable SMS service").isBtnSel(req.body.appSMSService);
	//req.checkBody('appEmailService', "Please Select Enable Email service").isBtnSel(req.body.appEmailService);
	req.checkBody('appCapthchaService', "Please Select Enable Application Captcha").isBtnSel(req.body.appCapthchaService);
	
 
	req.asyncValidationErrors().then(() => {
		//console.log("in next");
		req.body.projId = projId;
		req.body.projectIdentifier = projectIdentifier;
		req.body.formData = formData;
		//next();
		return next(); 
	}).catch((errors) => {
		//console.log("in validation");
		const results = validationResult(req).formatWith(errorFormatter);
		response.success = false;
		response.message = results.mapped();
		res.json(response);
	});
	
}
validation.acpuserMgmt = function(req, res, next) {
	const errorFormatter = ({ location, msg, param, value }) => {
			return `${msg}`;
		};
	
	let projID = req.body.PID;
	let uId = req.body.uId;
	let formData = req.body.data;
	//const accID = req.body.data.accountName;
	//const projID = req.body.formVal.projectName;
	//const appln = req.body.formJson;
	//console.log(appln);
	//const userName = req.session.usrName;
	//console.log(projID);
	req.body = req.body.data;
	
	req.checkBody('userName', "Please Enter Username").notEmpty();
	req.checkBody('userName', " Username should more than 4 characters or less than 50 characters").isLength({ min: 4, max:50 });
	
	if(projID) {
		var whereCond = {'userName': req.body['userName'],'userStatus' : 'Y'};
		if(uId) {
			var whereCond = {'userName': req.body['userName'],'userStatus' : 'Y', 'project.status' : 'Active', '_id': {$ne: ObjectID(uId)}};
		}
		
		req.checkBody('userName', "Username is already in use").isAcpUserNameExists({'projID': projID, 'whereCond': whereCond});
	}
	
	req.checkBody('emailID', "Please Enter Email ID").notEmpty();
	req.checkBody('mobileNo', "Please Enter Mobile No.").notEmpty();
	req.checkBody('userType', "Please Select Admin Type").notEmpty();
	req.checkBody('userStatus', "Please Select Status").notEmpty();
	
	if(req.body.userPwd !='') {
		req.checkBody('userCPwd', "Confirm Password should be same as Password").isSame(req.body.userPwd);
	}
	if(req.body.userCPwd != '') {
		req.checkBody('userPwd', "Please Enter Password").notEmpty();
	}
	req.asyncValidationErrors().then(() => {
		req.body.PID = projID;
		req.body.uId = uId;
		req.body.data = formData;
		next();
	}).catch((errors) => {
		const results = validationResult(req).formatWith(errorFormatter);
		response.success = false;
		response.message = results.mapped();
		res.json(response);
	});
}


validation.acplogin = function(req, res, next) {
	const errorFormatter = ({ location, msg, param, value }) => {
		// Build your resulting errors however you want! String, object, whatever - it works!
		return `${msg}`;
	};
	console.log(req);
	req.check("usrName")
		.notEmpty().withMessage("Please enter Username");
	req.assert('usrPwd', 'Please enter Password')
		.notEmpty();
		
	req.asyncValidationErrors().then(() => {
		//req.body = req.body.formVal;	
		//req.body.formVal = req.body;	
		next();
	}).catch((errors) => {
		console.log(errors);
		const results = validationResult(req).formatWith(errorFormatter);
		response.success = false;
		response.message = results.mapped();
		res.json(response); 
	});
}

/*======================= Email Settings ==================*/
validation.emailsettingAddEdit = function(req, res, next) {
	console.log("vvvvvvvvvvvv")
	const errorFormatter = ({ location, msg, param, value }) => {
		// Build your resulting errors however you want! String, object, whatever - it works!
		return `${msg}`;
	  };
    req.header('Cache-Control', 'no-cache'); 
	// let formJSON = req.body.formJSON; 
	// console.log("formJSON ",formJSON)
	// req.body = (Object.keys(req.body).length > 0)? JSON.parse(req.body.formJSON): {};	
	console.log('req.body ',req.body)
	req.checkBody('projId',"Application id can't be null").notEmpty();
	req.checkBody('contentType', "Please enter 'contentType' should be email/SMS.").notEmpty();
	req.check('contentType','Invalid Type').isIn(['email', 'sms']);
	req.checkBody('contentOptionType', " please enter option tyle (initial/paid/nofee)").notEmpty();
	req.check('contentOptionType','Invalid option Type').isIn(['initial', 'paid','nofee']);
		
	req.checkBody('content', "Content can't null").notEmpty();	 
	 
	req.asyncValidationErrors().then(() => {
		// req.body.AID = accID;
		// req.body.formJSON = formJSON;
		next();
	}).catch((errors) => {
		console.log("errrrrrrrrrrrrrrrr")
		const results = validationResult(req).formatWith(errorFormatter);
		response.success = false;
		response.message = results.mapped();
		/* if(JSON.stringify(response.message)=='{}'){
			jsonLogObj["ActivityError"] = "{ error: "+errors.stack+" }";
			logFunct.QryErrorLogFn(jsonLogObj,fs);
		} */
		res.send(response);
	});
}
validation.fetchOneById = function(req, res, next){
	console.log("get one by id")
	const errorFormatter = ({ location, msg, param, value }) => { 
		return `${msg}`;
	  };
    req.header('Cache-Control', 'no-cache');  	
	console.log('req.body ',req.body)
	req.checkBody('projId',"Application id can't be null").notEmpty();
	// req.checkBody('notificationId', "Please enter 'notificationId' id").notEmpty();
	req.checkBody('contentType', "Please enter 'contentType' should be email/SMS.").notEmpty();
	req.check('contentType','Invalid Type').isIn(['email', 'sms']);
	req.checkBody('contentOptionType', " please enter option tyle (initial/paid/nofee)").notEmpty();
	req.check('contentOptionType','Invalid option Type').isIn(['initial', 'paid','nofee']); 
	 
	req.asyncValidationErrors().then(() => {
		// req.body.AID = accID;
		// req.body.formJSON = formJSON;
		next();
	}).catch((errors) => { 
		const results = validationResult(req).formatWith(errorFormatter);
		response.success = false;
		response.status = 404;
		response.message = results.mapped(); 
		res.send(response);
	});
}

module.exports = validation;