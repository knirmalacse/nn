var request = require('request');
//const config = require('../config/config.json')[process.env.NODE_ENV || "development"];

var headerData = {
	'Content-Type': 'application/json',
	'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhcGlHYXRld2F5IiwibmFtZSI6ImlUZXN0R3JvdXAiLCJpYXQiOjE1MTYyMzkwMjJ9.3rlUhxmc_KTgeyw1HU6neIhZg4mqs7P0lx3HVxwppgo'
}; 

module.exports = {
	sendAPIService: function(postData,routerKey,callback){
		request({
			method: 'post',
			url: config.APIGateway.url+':'+config.APIGateway.port+'/'+routerKey,
			body:JSON.stringify(postData),
			headers: headerData
		}, function (error, response, body) {
			/* console.log("response end");
			console.log(error); */
			//console.log(response);
			//console.log(response.statusCode); 
			if(!error && response.statusCode == 200) {
				//console.log(response);
				return callback('success');
			} else {
				console.log(error);
				//return callback('failedar');
			}
		});
	}
}