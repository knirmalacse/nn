var db = require('../db/db');

var appdb = require('../db/appdb');
var projModel = require('../models/projModel');
const lowerCaseChange = (s) => {
  if (typeof s !== 'string') return ''
  //return s.charAt(0).toUpperCase() + s.slice(1) // 1st letter uppercase
  return s.toLowerCase() // all letter lowercase
}

let customValidation = {
    customValidators: {
		isAccountNameExists(value, udetails) {	 
        return new Promise((resolve, reject) => {
			 var dbConn = db.get();
         dbConn.account.find({"accountName":value,"status" : 'Active'}, function (err, account){
            if (err) reject();
            if(account && account[0]) {
					if(account[0]._id == udetails.uid && udetails.uid != ''){
					resolve();
					} else {
						reject();
					}
            } else {
              resolve();
            }
          });
        });
      },
	  
	  isUniqueExists(value, fielddetails) {
		
        return new Promise((resolve, reject) => {
		 var fieldValue = fielddetails.fieldValue;
		 var query = fielddetails.whereCond;
		 var fieldName = fielddetails.fieldName;
		 query[fieldName] = value;
		  
		 var tblName = fielddetails.tableName;
		 var dbConn = db.get();
         dbConn.collection(tblName).find(query, function (err, tblDetails){
			 console.log('-----tblDetails------');
				 console.log(tblDetails);
            if (err) { reject();}
			if(tblDetails && tblDetails[0]) {
			  reject();
            } else {
              resolve();
            }
          });
        });
      },
	   isUniqueExistsAggre(value, fielddetails) {
		   
        return new Promise((resolve, reject) => {
		 var fieldValue = fielddetails.fieldValue;
		 var query = fielddetails.whereCond;
		 var fieldName = fielddetails.fieldName;
		 query[fieldName] = lowerCaseChange(value); 
		 //query[fieldName] = value;
		 var tblName = fielddetails.tableName;
		 var dbConn = db.get();
		  dbConn.collection(tblName).aggregate(
			{ $unwind :'$project'},
			{ $match : query},
			{ $project : { _id:1, accountName:1, projectid : '$project._projectid', projectName : '$project.projectName' } } ,(err, data) => {
				 
				 if (err) reject();
					//console.log(data)
				if(data && data[0]) { 
				  reject();
				} else {
				  resolve();
				}
			});
        });
      },
	  isArrayExistsProj(value, fielddetails) {
		  
        return new Promise((resolve, reject) => {
			var fieldValue = fielddetails.fieldValue;
			var arrayCheck = fielddetails.arrayCheck;
		    var error = error1 = true;
			for(var myKey in fieldValue) {
				//console.log(myKey);
			   if(!arrayCheck.includes(myKey)){	//fieldValue[myKey]
				   error = false;
			   }
			 }  
			if(error == true){
			   resolve()
			} else {
			   reject();
			}
        });
      },
	  isArrayExists(value, fielddetails) {
		  
        return new Promise((resolve, reject) => {
			var fieldValue = fielddetails.fieldValue;
			var arrayCheck = fielddetails.arrayCheck;
		    var error = error1 = true;
			for(var myKey in fieldValue) {
			   if(!arrayCheck.includes(fieldValue[myKey])){	
				   error = false;
			   }
			 }  
			if(error == true){
			   resolve()
			} else {
			   reject();
			}
        });
      },
      isEmailExists(value, udetails) {
        return new Promise((resolve, reject) => {
			 var dbConn = db.get();
         dbConn.users.find({EmailID: value, isDeleted : 0}, function (err, user){
			 console.log(err);
            if (err) reject();
            if(user && user[0]) {
              //reject();
			  if(user[0]._id == udetails.uid && udetails.uid != ''){
					resolve();
				} else {
					reject();
				}
            } else {
              resolve();
            }
          });
        });
      },
	  
	  isUserNameExists(value, udetails) {
        return new Promise((resolve, reject) => {
			 var dbConn = db.get();
         dbConn.users.find({UserName: value, isDeleted : 0}, function (err, user){
            if (err) reject();
            if(user && user[0]) {		;
				if(user[0]._id == udetails.uid && udetails.uid != ''){
					resolve();
				} else {
					reject();
				}
            } else {
              resolve();
            }
          });
        });
      },
	  
	  isAcpUserNameExists(value, udetails) {
        return new Promise((resolve, reject) => {
			projModel.getProjectDetail(udetails.projID, function (err, data){
				let projectIdentifier = data[0].projectIdentifier;
				appdb.connect(projectIdentifier,function(err) {
					var dbConn = appdb.get();
					dbConn.collection('admin_users').find(udetails.whereCond,{'userPwd':0},{'limit':1},function(err, docs) {
						if (err) reject();
						if(docs && docs[0]) {		
							reject();
						}else{
							resolve();
						}
					});
				});
			});
        });
      },
	  
	  isMobileExists(value, udetails) {
        return new Promise((resolve, reject) => {
			 var dbConn = db.get();
         dbConn.users.find({Mobile: value, isDeleted : 0}, function (err, user){
            if (err) reject();
            if(user && user[0]) {		;
				if(user[0]._id == udetails.uid && udetails.uid != ''){
					resolve();
				} else {
					reject();
				}
            } else {
              resolve();
            }
          });
        });
      },
	  isArrayEmpty(value, fielddetails) {
		  
        return new Promise((resolve, reject) => {
			var fieldValue = fielddetails.fieldValue;
			var arrayCheck = fielddetails.arrayCheck;
		    var error = error1 = false;
			for(var myKey in fieldValue) {
				//console.log(myKey);
			   if(fieldValue[myKey] === true){	
				   error = true;
			   }
			 }  
			if(error == true){
			   resolve()
			} else {
			   reject();
			}
        });
      },
	  isValidDate(value,fldData) {
		  //console.log(value);
		  //console.log(fldData);
         return new Promise((resolve, reject) => {
			let year = fldData.date.year;
			let month = fldData.date.month;
			let day = fldData.date.day;
		    var error = error1 = false;
			if(year =='' || month =='' || day ==''){
				error = true;
			} /* else if() {
				
			} */
			
			if(error == false){
			   resolve()
			} else {
			   reject();
			}
        }); 
      },
	  isBtnSel(value,selVal) {
		  //console.log(value);
		  //console.log(fldData);
          return new Promise((resolve, reject) => {
			let optAvail = ['Y','N'];
		    var error = error1 = false;
			if(!optAvail.includes(selVal)){
				error = true;
			} 
			
			if(error == false){
			   resolve()
			} else {
			   reject();
			}
        }); 
      },
	  compareDateNotequal(vale,dateField) {
         return new Promise((resolve, reject) => {
		    var error = false;
			let date1Time = new Date(dateField['date1']['date']['year'],dateField['date1']['date']['month'],dateField['date1']['date']['day'],dateField['date1Hour'],dateField['date1Min'],dateField['date1Sec']).getTime();
			let date2Time = new Date(dateField['date2']['date']['year'],dateField['date2']['date']['month'],dateField['date2']['date']['day'],dateField['date2Hour'],dateField['date2Min'],dateField['date2Sec']).getTime();
			/* console.log(dateField);
			console.log(date1Time+"=="+date2Time); */
			if(date2Time <= date1Time){
				error = true;
			}
			
			if(error == false){
			   resolve()
			} else {
			   reject();
			}
        }); 
      },
	  compareDate(vale,dateField) {
         return new Promise((resolve, reject) => {
		    var error = false;
			let date1Time = new Date(dateField['date1']['date']['year'],dateField['date1']['date']['month'],dateField['date1']['date']['day'],dateField['date1Hour'],dateField['date1Min'],dateField['date1Sec']).getTime();
			let date2Time = new Date(dateField['date2']['date']['year'],dateField['date2']['date']['month'],dateField['date2']['date']['day'],dateField['date2Hour'],dateField['date2Min'],dateField['date2Sec']).getTime();
			console.log(date1Time+"=="+date2Time);
			
			console.log(dateField);
			if(date2Time < date1Time){
				error = true;
			}
			
			console.log(error);
			
			if(error == false){
			   resolve()
			} else {
			   reject();
			}
        }); 
      },
	  isSame(value,pwdVal) {
		 return new Promise((resolve, reject) => {
			var error = error1 = false;
			if(value ==''){
				error = true;
			} else if(value != pwdVal ) {
				error = true;
			} 
			
			if(error == false){
			   resolve()
			} else {
			   reject();
			}
		}); 
	  } 
    }
}
module.exports = customValidation;