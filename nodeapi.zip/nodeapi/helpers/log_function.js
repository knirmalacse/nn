module.exports = {
	createUpdateLog: function(jsonLogObj,db,fs,ActivityLogType) {
		if(ActivityLogType == '0'){
			let curdate = new Date();
			var YearVal = curdate.getFullYear();   
			var MonthVal = ("0" + (curdate.getMonth() + 1)).slice(-2);   
			var DayVal = ("0" + curdate.getDate()).slice(-2);
			var HourVal = ("0" + curdate.getHours()).slice(-2);
			var pathLogDir = "/home/Applogs/"+DayVal+"-"+MonthVal+"-"+YearVal;
			var FilePathLog = "/home/Applogs/"+DayVal+"-"+MonthVal+"-"+YearVal+'/'+HourVal+'.txt';

			if (!fs.existsSync(pathLogDir)){
				fs.mkdirSync(pathLogDir);
			}
			fs.appendFile(FilePathLog, JSON.stringify(jsonLogObj), function (err) {
				if (err) console.log(err);
			});
		}else if(ActivityLogType == '1'){			
			db.log_detail.insert(jsonLogObj,{},
			function(err, result) {
				if (!err) console.log('logged successfully');
			});
		}
	},
	QryErrorLogFn: function(jsonLogObj,fs) {
		let curdate = new Date();
		var YearVal = curdate.getFullYear();   
		var MonthVal = ("0" + (curdate.getMonth() + 1)).slice(-2);   
		var DayVal = ("0" + curdate.getDate()).slice(-2);
		var HourVal = ("0" + curdate.getHours()).slice(-2);
		var QryLogDir = "/home/Applogs/QryErrorLog/";
		var pathLogDir = QryLogDir+DayVal+"-"+MonthVal+"-"+YearVal;
		var FilePathLog = pathLogDir+'/'+HourVal+'.txt';
		
		if (!fs.existsSync(QryLogDir)){
			fs.mkdirSync(QryLogDir);
		}
		if (!fs.existsSync(pathLogDir)){
			fs.mkdirSync(pathLogDir);
		}
		fs.appendFile(FilePathLog, JSON.stringify(jsonLogObj), function (err) {
			if (err) console.log(err);
		});
	},
	getDatabaseConn: function(mongojs,configJSON,strAuthsrcAppend,callback){ 
		//var dbCon = mongojs('"'+configJSON.mongoDB.Username+':'+configJSON.mongoDB.Password+'@'+configJSON.mongoDB.host+':'+configJSON.mongoDB.host+'/'+configJSON.AdminDatabase+'"', DbcollectionList);
		//var dbCon = mongojs('Admin:Admin123@localhost:27017/FormBuilderACP?&authSource=admin');
		var MongoConnStr = configJSON.mongoDB.Username+':'+configJSON.mongoDB.Password+'@'+configJSON.mongoDB.host+':'+configJSON.mongoDB.port+'/'+configJSON.AdminDatabase+''+strAuthsrcAppend;
		var dbCon = mongojs(MongoConnStr);
		return callback(dbCon);
	}
}