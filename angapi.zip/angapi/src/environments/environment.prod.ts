export const environment = {
  production: true,
  FileUploadMethod: 0, 
  appUrl: 'http://formbuilder-api-staging.13.234.161.40.nip.io/api/' // Formbuilder API
};
