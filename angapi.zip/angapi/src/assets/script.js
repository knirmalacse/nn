$(document).ready(function(){
	//sidebar toggler
	$('body').on('click', '.sidebar-toggler', function () { 
		$('#navbarCollapse, .logo, .body-main, .footer').toggleClass('active');
	});
	$('body').on('click', '.sidebar li a.nav-link', function () { 
        $('#navbarCollapse, .logo, .body-main').removeClass('active');
    });
	// $('body').on('mouseover', '.sidebar li a.nav-link', function () { 
	// 	$('#navbarCollapse, .logo, .body-main').toggleClass('active');
	// });
	$('body').on('click', '.logout-btn', function () { 
		$('#navbarCollapse, .logo, .body-main, .footer').removeClass('active');
	});
});