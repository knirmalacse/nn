import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { environment } from '../../environments/environment';

import { Observable } from 'rxjs/Observable';
import { HttpClient} from '@angular/common/http'; 

@Injectable()
export class ReportsService {

  constructor(private http: HttpClient) { }
  
  getAccountDetails(projectId) {
	return this.http.get(environment.appUrl + "account/accountDetails",{params:{projectId:projectId}})
	  .map(result => {		
		return result;
	});
  }
  
  getFieldWiseReports(projectId, selFldVal) {
	return this.http.get(environment.appUrl + "account/project/reports",{params:{projectId:projectId,selFldVal:selFldVal}})
	  .map(result => {		
		return result;
	});
  }
  
  downloadCSV(projectId,selectedField,type,section,fldValue) {
	return this.http.get(environment.appUrl + "account/project/reports/download",{params:{projectId:projectId,selectedField:selectedField,type:type,section:section,fldValue:fldValue}})
	  .map(result => {		
		return result;
	});
  }

}
