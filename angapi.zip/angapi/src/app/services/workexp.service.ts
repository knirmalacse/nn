import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../environments/environment';
import { HttpClient} from '@angular/common/http'; 
 

@Injectable()
export class Workexpservice {

  constructor(private http: Http, private _http: HttpClient) { }
  
	workexpConfigStore( formJSON2 : any, PID: any, AID: any, WorkExpId : any){
	    let formJSON1 = JSON.stringify(formJSON2.workexp);
	    let totexp = formJSON2.totexp;
		let PID1 = JSON.stringify(PID);
		let AID1 = JSON.stringify(AID);
		return this._http.post(environment.appUrl + "ruleengine/workexpSubmit", { formJSON: formJSON1, PID: PID1 ,AID: AID1, WorkExpId:WorkExpId,totexp:totexp})
		.map(result => {			
			return result;
		});
	}
	
	workexpConfigEdit( PID: any, AID: any){
		
		let PID1 = JSON.stringify(PID);
		let AID1 = JSON.stringify(AID);
		return this._http.get(environment.appUrl + "ruleengine/workexpDetSubmit",{params:{PID:PID1,AID: AID1}})
		.map(result=>{
				return result;
		}); 
	}
	 
 

}
