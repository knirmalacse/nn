import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AcpsharedService } from './acpshared.service';

@Injectable()
export class AcpService {

	selectedFile: File = null;
	fd = new FormData();

	constructor(private http: HttpClient, private acpsharedService: AcpsharedService) { }
	servLoginData: any;

	Login(usrName: string, usrPwd: string, projectIdentifier: string, captcha : string): Observable<any> {
		return this.http.post(environment.appUrl + "acp/login", { usrName: usrName, usrPwd: usrPwd, projectIdentifier: projectIdentifier,captcha:captcha })
			.map(result => {
				if (result.hasOwnProperty("token"))
					localStorage.setItem('acp_auth_token', result['token']);
				return this.servLoginData = result;

			});
	}

	saveAdminUser(postData, PID, uId, projectIdentifier) {
		return this.http.post(environment.appUrl + "acp/userMgmt", { data: postData, PID: PID, uId: uId, projectIdentifier: projectIdentifier })
			.map(result => {
				return result;
			});
	}
	getAdminUser(PID, projectIdentifier) {
		return this.http.get(environment.appUrl + "acp/userMgmt", { params: { PID: PID, projectIdentifier: projectIdentifier } })
			.map(result => {
				return result;
			});
	}

	getUsers(userID: any, PID, projectIdentifier) {
		return this.http.get(environment.appUrl + "acp/user", { params: { userID: userID, PID: PID, projectIdentifier: projectIdentifier } })
			.map(result => {
				return result;
			});

	}


	isLoggedIn(projectId: string): Observable<any> {
		return this.http.post(environment.appUrl + "acp/usrLogCheck", { projectId: projectId })
			.map(result => {
				console.log('check logged In here');
				this.servLoginData = result;
				if (this.servLoginData["message"] == "success" && this.servLoginData["success"]) {
					this.acpsharedService.ACPProjectIdentifier.next(projectId);
					this.acpsharedService.IsACPUserLoggedIn.next(true);
					this.acpsharedService.ACPLoggedUserName.next(this.servLoginData['data']['userName']);
				}
				return this.servLoginData;
			});
	}

	logout(projectIdentifier) {
		return this.http.get(environment.appUrl + "acp/logout", { params: { projectIdentifier: projectIdentifier } }).map(result => {
			//console.log('here');
			// localStorage.setItem('usrToken', '');
			localStorage.removeItem('acp_auth_token');
			this.acpsharedService.IsACPUserLoggedIn.next(false);
			return this.servLoginData = result['success'];
		});
	}

	saveDocMgmt(fddata) {  
		var headers = new HttpHeaders();
		headers.append('Content-Type', 'application/form-data');
			
		return this.http.post(environment.appUrl + "acp/saveDocMgmt", fddata)
			.map(result => {
				return result; 
			});
		/* return this.http.post(environment.appUrl + "acp/saveDocMgmt",{fddata,doccategory:doccategory,projectId:PID,projectIdentifier:projectIdentifier}, {headers: headers })
		.map(result => {
			 	
		});  */
	}
	saveDocMgmt_FileUpload(postData,logoPathValue, PID, projectIdentifier) {  
		console.log('----postData---');
		console.log(postData);
		return this.http.post(environment.appUrl + "acp/saveDocMgmt_FileUpload", { data: postData,logoPath:logoPathValue, PID: PID, projectIdentifier: projectIdentifier })
			.map(result => {
				return result; 
			});
	}
 
	getDocList(PID, projectIdentifier) {
		return this.http.get(environment.appUrl + "acp/docMgmt", { params: { PID: PID, projectIdentifier: projectIdentifier } })
			.map(result => {
				return result;
			});
	}

	getLatestSearch(PID, projectIdentifier, searchtype, searchval) {
		return this.http.post(environment.appUrl + "acp/lSearch", { PID: PID, projectIdentifier: projectIdentifier, searchtype, searchval })
			.map(result => {
				return result;
			});
	}
	getunblkaccessServices(PID, projectIdentifier, unblkaccesstype, unblkaccessval) {
		return this.http.post(environment.appUrl + "acp/GetunblkaccessRoute", { PID: PID, projectIdentifier: projectIdentifier, unblkaccesstype, unblkaccessval })
			.map(result => {
				return result;
			});
	}
	getLatestReports(PID, projectIdentifier) {
		return this.http.post(environment.appUrl + "acp/GetReports", { PID: PID, projectIdentifier: projectIdentifier })
			.map(result => {
				return result;
			});
	}
	getRegDetails(PID, projectIdentifier, appRegId) {
		return this.http.post(environment.appUrl + "acp/getRegDetails", { PID: PID, projectIdentifier: projectIdentifier, appRegId: appRegId })
			.map(result => {
				return result;
			});
	}

	getAppln(accID, projID) { 
		return this.http.get(environment.appUrl + "acp/getAppln", { params: { accountID: accID, projectID: projID } })
			.map(result => {
				return result;
			});
	}

	saveAppSetting(fdData) {  
		var headers = new HttpHeaders();
		headers.append('Content-Type', 'application/form-data');
		return this.http.post(environment.appUrl + "acp/projectSetting",fdData) 
			.map(result => {
				return result;
			});
	}
	saveAppSetting_FileUpload(postData, logoPathValue, PID, projectIdentifier) { 
		return this.http.post(environment.appUrl + "acp/projectSetting_FileUpload", { data: postData,logoPath:logoPathValue, PID: PID, projectIdentifier: projectIdentifier })
			.map(result => {
				return result;
			});
	}
	AcpRightsIns(PID, projectIdentifier, dataDets: any, roleIDDet: any) {
		return this.http.post(environment.appUrl + "acp/acp_rightssave", { PID: PID, projectIdentifier: projectIdentifier, dataDets: dataDets, roleIDDet: roleIDDet })
			.map(result => {
				return result;
			});
	}
	AcpGetRole(PID, projectIdentifier, roleID: any) {
		return this.http.post(environment.appUrl + "acp/acp_getRole", { PID: PID, projectIdentifier: projectIdentifier, roleID: roleID })
			.map(result => {
				return result;
			});
	}
	getRolesNew(PID, projectIdentifier) {
		var RoleIdVal = this.servLoginData.data.userType;
		return this.http.post(environment.appUrl + "acp/acp_getRoleAccess", { PID: PID, projectIdentifier: projectIdentifier, roleID: RoleIdVal })
			.map(result => {
				return result;
			}).toPromise();
	}
	// Email Setting
	getNotificationBy(reqData: any): Observable<any> {
		return this.http.post(environment.appUrl + "acp/getNotificationById", reqData);
	}
	addEditEmailTemplate(reqData: any): Observable<any> {
		return this.http.post(environment.appUrl + "acp/addEditEmail", reqData);
	}
}