import { TestBed, inject } from '@angular/core/testing';

import { RuleengineService } from './ruleengine.service';

describe('RuleengineService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [RuleengineService]
    });
  });

  it('should be created', inject([RuleengineService], (service: RuleengineService) => {
    expect(service).toBeTruthy();
  }));
});
