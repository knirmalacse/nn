import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { environment } from '../../environments/environment';
import { HttpClient, HttpHeaders} from '@angular/common/http';

import { Observable } from 'rxjs/Observable';

@Injectable()
export class RuleengineService {

  constructor(private http: HttpClient) { }
  
  ruleAppSubmit(formVal):Observable<any>{
	return this.http.post(environment.appUrl + "ruleengine/ruleengineSubmit",{formVal: formVal})
	  .map(result => {		
		return result;
	});
  }
  
  getRulesManage(accID,projID,searchInp):Observable<any>{
	  return this.http.get(environment.appUrl + "ruleengine/getruleengineSubmit",{params:{accountID:accID,projectID:projID,searchInp:searchInp}})
		.map(result=>{
				return result;
		});
  }
  
  getRulesById(ruleID):Observable<any>{
	  return this.http.get(environment.appUrl + "ruleengine/getruleengineByIdSubmit",{params:{ruleID:ruleID}})
		.map(result=>{
				return result;
		}); 
  } 
  
  deleteRule(fieldName,accID,projID,compObj,ruleID,typeStr):Observable<any>{
	   return this.http.post(environment.appUrl + "ruleengine/delruleengineSubmit",{accountID:accID,projectID:projID,fieldName:fieldName,compObj:compObj,ruleID:ruleID,typeStr})
		.map(result=>{
				return result;
		});
  }
  
  getRelaxationList(accID,projID):Observable<any> {
	return this.http.get(environment.appUrl + "ruleengine/getageRelaxationListSubmit",{params:{accountID:accID,projectID:projID}})
		.map(result=>{
				return result;
	});
  }
  
    saveAgeRulesManage(formVal,ID):Observable<any>{ 
	  return this.http.post(environment.appUrl + "ruleengine/addageruleengineSubmit",{formVal: formVal,ID: ID})
		.map(result=>{
				return result;
		});
	}
   
   uploadChildData(formData):Observable<any>{ 
		//var headers = new HttpHeaders();
		//headers.append('Content-Type', 'application/form-data');
	  return this.http.post(environment.appUrl + "dependent/saveData",formData)
		.map(result=>{
				return result;
		});
	}
	
	getListData(fldName, projectId):Observable<any>{ 
	  return this.http.post(environment.appUrl + "dependent/getListData",{fldName: fldName,projectId:projectId})
		.map(result=>{
				return result;
		});
	}
	
	dataMapping(formData, projectId):Observable<any>{ 
	  return this.http.post(environment.appUrl + "dependent/dataMapping",{formData: formData,projectId:projectId})
		.map(result=>{
				return result;
		});
	}
  
}