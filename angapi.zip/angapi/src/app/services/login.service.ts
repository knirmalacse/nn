import { Injectable } from '@angular/core';   
import {Http,Response, Headers, RequestOptions } from '@angular/http'; 
import {HttpClientModule, HttpClient,HttpHeaders} from '@angular/common/http';  
   
import { Observable } from 'rxjs/Observable';  
import 'rxjs/add/operator/map';  
import 'rxjs/add/operator/do';  
import { environment } from '../../environments/environment';


import { JwtHelperService } from '@auth0/angular-jwt';
import { SharedService } from './shared.service';
/**/

/*import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
//import { HttpClient, HttpHeaders } from '@angular/common/http';
import {HttpClientModule, HttpClient} from '@angular/common/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Observable';*/

/*  export class serLoginData {
	  message1 : any;
	} */

@Injectable()
export class LoginService {

  constructor(private http: Http, private _http: HttpClient,private sharedService: SharedService) { }
		/* servLoginData:serLoginData = {
		  message1 : '',
		}; */
  servLoginData:any;
  Login( usrName : string, usrPwd : string, captcha : string):Observable<any>{
		//console.log(formJSON);
		//return this.servLoginData; 
		//this.servLoginData.message1 ={};
		
		return this._http.post(environment.appUrl + "user/login", { usrName: usrName,usrPwd:usrPwd,captcha:captcha})
		.map(result => {
			//localStorage.setItem('currentUser', JSON.stringify(result.json().data));
			//return result;
			console.log("are");
			console.log(result);
			/* localStorage.setItem('usrToken', result.json().token);
			const helper = new JwtHelperService();
			const decodedToken = helper.decodeToken(result.json().token); */
			//const expirationDate = helper.getTokenExpirationDate(myRawToken);
			//const isExpired = helper.isTokenExpired(myRawToken);
			//console.log(decodedToken);
			if(result.hasOwnProperty("token"))
				localStorage.setItem('auth_token', result['token']);
			return this.servLoginData = result;
		});
   } 
   
   isLoggedIn():Observable<any>{
		return this._http.get(environment.appUrl + "user/usrLogCheck")
		.map(result => {
			if(result['success'] == true){ 
				this.sharedService.IsUserLoggedIn.next(true);
				this.sharedService.LoggedUserName.next(result['data']['UserName']);
			}
			
			console.log('check logged In here');
			return this.servLoginData = result;
		});
   }
   
    getLoggedInUser():Observable<any>{
		return this._http.get(environment.appUrl + "user/usrDetails")
		.map(result => {
			//console.log('here');
			return this.servLoginData = result['data'];
		});
   }
   
   logout() {
	return this._http.get(environment.appUrl + "user/logout").map(result => {
			//console.log('here');
			// localStorage.setItem('usrToken', '');
			localStorage.removeItem('auth_token');
			this.sharedService.IsUserLoggedIn.next(false);
			return this.servLoginData = result['success'];
		});
   }
   
   captchaCheck(data) {
		return this._http.post(environment.appUrl + "user/captcha", { captcha: data})
		.map(result => {
			return this.servLoginData = result;
		});
   }
   /*isLoggedIn(){
	return false;
   }*/

}
