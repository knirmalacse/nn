import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../environments/environment';
import { HttpClient} from '@angular/common/http'; 

@Injectable()
export class ProjectService {

  constructor(private http: HttpClient) { }
  
  
   projectRegistration( formJSON2 : any, AID: any, PID: any){
	    let formJSON1 = JSON.stringify(formJSON2);
		if(PID != ''){
			return this.http.post(environment.appUrl + "account/project", { formJSON: formJSON1, AID: AID, PID: PID})
			.map(result => {			
				return result;
			});
		} else {
			return this.http.post(environment.appUrl + "account/project", { formJSON: formJSON1, AID: AID, PID: PID})
			.map(result => {			
				return result;
			});		
		}
		
   } 
   
   getProjectInfo(){
		return this.http.get(environment.appUrl + "account/project")
		.map(result => {			
			return result;
		});
   
   } 
   
   getProjectDetails(AID: any, PID: any){
		return this.http.get(environment.appUrl + "account/project",{params:{AID: AID, PID: PID }})
		.map(result => {			
			return result;
		});
   
   }
   
   deleteProject(AID: any, PID: any){
		return this.http.delete(environment.appUrl + "account/project",{params:{AID: AID, PID: PID}})
		.map(result => {			
			return result;
		});
   
   }
   
   getProjIdentifier (PID: any) {
		return this.http.get(environment.appUrl + "account/project/projectDetails",{params:{PID: PID }})
		.map(result => {			
			return result;
		});
   }
   
   saveAppSetting(formData, projectId) {
		return this.http.post(environment.appUrl + "account/project/projectSetting", { formData: formData, projId: projectId})
		.map(result => {			
			return result;
		});
		//console.log(formData);
   }
   
   getProjSetting(projectId) {
		return this.http.get(environment.appUrl + "account/project/projectSetting", {params:{PID: projectId }})
		.map(result => {			
			return result;
		});
   }

}
