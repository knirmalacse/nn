import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
//import { HttpClient, HttpHeaders } from '@angular/common/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../environments/environment';
import { HttpClient} from '@angular/common/http'; 

@Injectable()
export class UsersService {

  constructor(private http: HttpClient) { }
   
   Register( formJSON2 : any, formUID: any){
	    let formJSON1 = JSON.stringify(formJSON2);
		return this.http.post(environment.appUrl + "user", { formJSON: formJSON1, formUID: formUID})
		.map(result => {
			//localStorage.setItem('currentUser', JSON.stringify(result.json().data));
			//return result;
			return result;
		});
   } 
   
   UserDetails(){
		return this.http.get(environment.appUrl + "user")
		.map(result => {			
			return result;
		});
   
   }
   
   getUsers(userID: any){
		return this.http.get(environment.appUrl + "user",{params:{userID: userID}})
		.map(result => {			
			return result;
		});
   
   }
   
   setUserStatus(userID: any, status: string){
		return this.http.put(environment.appUrl + "user",{userID: userID, status: status})
		.map(result => {			
			return result;
		});
   
   }
   
   deleteUsers(userID: any){
		return this.http.delete(environment.appUrl + "user",{params:{userID: userID}})
		.map(result => {			
			return result;
		});
   
   }
   sendMailIfValidUser(formJSON:any)
   {
	   let formJSON1 = JSON.stringify(formJSON);
	   return this.http.post(environment.appUrl + "user/forgot", { formJSON: formJSON1})
		.map(result => {
			return result;
		});
   }
   passwordReset(formJSON:any)
   {
		let formJSON1 = JSON.stringify(formJSON);
		return this.http.post(environment.appUrl + "user/forgotreset", { formJSON: formJSON1})
		.map(result => {
			return result;
		});
   }

}
