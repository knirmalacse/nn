import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/toPromise';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../environments/environment';
import { HttpClient} from '@angular/common/http'; 

import { JwtHelperService } from '@auth0/angular-jwt';

@Injectable()
export class AclService {
  
  decodedToken:any;
  constructor(private http: HttpClient) { 
	
	//this.getRoles(decodedToken.userRole);
  }
  
  getRoles(){
	  /* if(role) {
	    return this.http.put(environment.appUrl + "roles",{params:{roleID: role.id, roleName:role.name}})
		  .map(result => {			
		    return result.json();
	    });
	  } else {
		return this.http.post(environment.appUrl + "roles",{params:{roleName:role.name}})
		  .map(result => {			
		    return result.json();
	    });  
	  } */
	  //console.log('get role fn');
	  //if(role) {
		//console.log(environment.appUrl + "roles/data");
		const usrToken = localStorage.getItem('auth_token');
		if(usrToken) {
			const helper = new JwtHelperService();
			this.decodedToken = helper.decodeToken(usrToken);
		}
		return this.http.post(environment.appUrl + "user/roles/data",{roleID: this.decodedToken.UserRole})
		  .map(result => {		
			return result;
	    }).toPromise(); 
		/* , headers: req.headers
            .set('Content-Type', 'application/json')
            .set('Authorization', 'Bearer ' + token) */
	  //}
	  
  }
  
  isAccessible(compName:any, functAcc:any){
	//console.log('access check');
	//return false;
	return this.getRoles().then(userRoles => {
		//console.log(userRoles);
		for(let pages of Object.values(userRoles)) { //let pages in userRoles
			if(pages.page == compName) {
				var accFunc = pages.functionality;
				//console.log(accFunc.includes(functAcc));
				if(accFunc.includes(functAcc)){
					//this.router.navigate(['/dashboard']);
					return true;
				}else {
					//this.router.navigate(['/login']);
					return  false;
				}
			}
			return false;
		}
		/* userRoles.forEach(function(pages){
			console.log(pages.page+'--->'+compName);
			if(pages.page == compName) {
				var accFunc = pages.functionality;
				console.log(accFunc.includes(functAcc));
				if(accFunc.includes(functAcc)){
					//this.router.navigate(['/dashboard']);
					return true;
				}else {
					//this.router.navigate(['/login']);
					return  false;
				}
			}
			return false;
		}); */
		return false;
	}); 
  }

}
