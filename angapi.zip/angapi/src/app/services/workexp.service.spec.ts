import { TestBed, inject } from '@angular/core/testing';

import { Workexpservice } from '../../services/workexp.service';

describe('Workexpservice', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [Workexpservice]
    });
  });

  it('should be created', inject([workexpService], (service: workexpService) => {
    expect(service).toBeTruthy();
  }));
});
