import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../environments/environment';
@Injectable()
export class RoleService {

  constructor(private http: Http) { }
  
  createRole( role : any){
	let Role = JSON.stringify(role);
	return this.http.post(environment.appUrl + "user/role", { Role: Role})
	  .map(result => {			
		return result.json();
	  }); 
   }
   updatePermissionSet( updatePermissionSet : any, _id : any){
	let PermissionSet = JSON.stringify(updatePermissionSet);
	return this.http.put(environment.appUrl + "user/role/PermissionSet", { PermissionSet: PermissionSet, _id:_id})
	  .map(result => {			
		return result.json();
	  }); 
   }
   
   getPermissionSet(_id : any){
	return this.http.get(environment.appUrl + "user/role/PermissionSet",{params:{_id:_id}})
	  .map(result => {			
		return result.json();
	  }); 
   }
   updateRole( role : any, _id : any){
	let Role = JSON.stringify(role);
	return this.http.put(environment.appUrl + "user/role", { Role: Role, _id:_id})
	  .map(result => {			
		return result.json();
	  }); 
   }
  getRole():Observable<any> {
	return this.http.get(environment.appUrl + "user/role")
	  .map(result => {			
		return result.json();
	});  
  }

}
