import { Injectable } from '@angular/core';
import { Subject,BehaviorSubject } from 'rxjs';

@Injectable()
export class AcpsharedService {
    public IsACPUserLoggedIn: Subject<boolean> = new Subject<boolean>();
    public ACPLoggedUserName: Subject<string> = new Subject<string>();
    public ACPProjectIdentifier: Subject<string> = new Subject<string>();
    public ACPprojectName: Subject<string> = new Subject<string>();
    public ACPprojectTitle: Subject<string> = new Subject<string>();
	
	constructor() { }
}