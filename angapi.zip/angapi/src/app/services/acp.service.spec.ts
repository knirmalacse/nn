import { TestBed, inject } from '@angular/core/testing';

import { AcpService } from './acp.service';

describe('AcpService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AcpService]
    });
  });

  it('should be created', inject([AcpService], (service: AcpService) => {
    expect(service).toBeTruthy();
  }));
});
