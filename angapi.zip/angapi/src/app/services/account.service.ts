import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../environments/environment';
import { HttpClient} from '@angular/common/http'; 

@Injectable()
export class AccountService {

  constructor(private http: Http, private _http: HttpClient) { }
  
  
   accountRegistration( formJSON2 : any, AID: any){
	    let formJSON1 = JSON.stringify(formJSON2);
		return this._http.post(environment.appUrl + "account", { formJSON: formJSON1, AID: AID})
		.map(result => {			
			return result;
		});
   } 
   
   getAccountInfo(){
		return this._http.get(environment.appUrl + "account")
		.map(result => {			
			console.log(result['data']);
			//let results = { 'data':''}
			return result;
		});
   
   }
   
   getAccountInfoPageLtd(pageNo: any,AccIDVal : any =''){
		return this._http.get(environment.appUrl + "account",{params:{pageNo: pageNo,AccIDVal: AccIDVal}})
		.map(result => {			
			return result;
		});
   }
   
   getAccountDetails(AID: any){
		return this._http.get(environment.appUrl + "account",{params:{AID: AID}})
		.map(result => {			
			return result;
		});
   
   }
   
   deleteAccount(AID: any){
		return this._http.delete(environment.appUrl + "account",{params:{AID: AID}})
		.map(result => {			
			return result;
		});
   
   }
   
   accountAclIns( dataDets : any,roleIDDet: any){
		return this._http.post(environment.appUrl + "acl/acl_save", { dataDets: dataDets,roleIDDet:roleIDDet})
		.map(result => {			
			return result;
		});
   } 
   
   getaccountAcl( roleID : any){
	 return this._http.get(environment.appUrl + "acl/acl_getrole",{params:{roleID: roleID}})
	 .map(result => {			
		return result;
	 });
   } 

}
