import { TestBed, inject } from '@angular/core/testing';

import { ApplAgeService } from './appl-age.service';

describe('ApplAgeService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ApplAgeService]
    });
  });

  it('should be created', inject([ApplAgeService], (service: ApplAgeService) => {
    expect(service).toBeTruthy();
  }));
});
