import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { environment } from '../../environments/environment';

import { Observable } from 'rxjs/Observable';
import { HttpClient} from '@angular/common/http'; 

@Injectable()
export class ApplicationService {

  constructor(private http: HttpClient) {
	
  }
  
  appSubmit(formVal, formJson):Observable<any>{
		//console.log(formJson.components);
		return this.http.post(environment.appUrl + "application",{formVal: formVal,formJson:formJson.components})
		  .map(result => {		
		    return result;
	    });
  }
  
  getAppln(accID,projID):Observable<any>{
		//console.log(formJson.components);
		return this.http.get(environment.appUrl + "application",{params:{accountID:accID,projectID:projID}})
		  .map(result => {		
		    return result;
	    });
  }
  
  getAccountData():Observable<any> {
	return this.http.get(environment.appUrl + "application/accounts").map(
		result => { return result; }
	);
  }
  
  getProjects(accID):Observable<any> {
	return this.http.post(environment.appUrl + "application/projects",{accountID:accID}).map(
		result => { return result; }
	);
  }

  sendAPIData(formData : any,accID,projID): Observable<any>{
		return this.http.post(environment.appUrl+"application/submitFormioApp", {data: formData,accID,projID} )
			.map(result => {			
				return result;
			});
		//return {test: "tested"};
   }
}
