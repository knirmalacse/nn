import { Injectable } from '@angular/core';
import { Subject,BehaviorSubject } from 'rxjs';

@Injectable()
export class SharedService {
    public IsUserLoggedIn: Subject<boolean> = new Subject<boolean>();
    public LoggedUserName: Subject<string> = new Subject<string>();
	
	private accountId = new BehaviorSubject('');
	currentAccInfo = this.accountId.asObservable();
	private projectId = new BehaviorSubject('');
	currentProjInfo = this.projectId.asObservable();
	
	constructor() { 
		let storedaccId = localStorage.getItem('storedaccId');
		let storedprojectId = localStorage.getItem('storedprojectId');
        if (storedaccId) this.changeAccount(storedaccId);
        if (storedprojectId) this.changeProject(storedprojectId);
	}

	changeAccount(accId: any) {
		localStorage.setItem('storedaccId', accId);
		this.accountId.next(accId);
	}
	changeProject(projId: any) {
		localStorage.setItem('storedprojectId', projId);
		this.projectId.next(projId);
	}
}
