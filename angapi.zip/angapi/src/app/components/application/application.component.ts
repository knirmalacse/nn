import { Component, OnInit, ElementRef, ViewChild, AfterViewInit,EventEmitter } from '@angular/core';
import { Router } from "@angular/router";
import { NgForm } from '@angular/forms';
import Prism from 'prismjs';

import { LoginService } from '../../services/login.service';
import { ApplicationService } from '../../services/application.service';
import { SharedService } from '../../services/shared.service';
import { AclService } from '../../services/acl.service';
import { ProjectService } from '../../services/project.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-application',
  templateUrl: './application.component.html',
  styleUrls: ['./application.component.css']
})
export class ApplicationComponent implements AfterViewInit,OnInit {

  @ViewChild('json') jsonElement?: ElementRef;
  @ViewChild('code') codeElement?: ElementRef;
  model:any = {'accountName':'','projectName':''};
  accountData:any;
  projectData:any;
  formJson = [];
  applNew:any = 0;
  display:string = 'none';
  //form:Object = {};
  refreshForm:any;
  options: Object = {
	  submitMessage: "",
	  disableAlerts: true,
	  noAlerts: true
  }
   public editForm: Object = {
	"data": {} //{"pageNaNText": "test", "page2TextArea": "test", "_id": "5b89158836eb8036f28716d8"}
  };
  loading = false;
  AccProjectdet:any;
  constructor(private loginService: LoginService,private applicationService: ApplicationService, private aclService: AclService, private sharedService: SharedService, public router: Router,private toastr: ToastrService,private projectService:ProjectService) { 
	
	//this.getAccountData();
  }
  createappAdd: any = 0;
  createappView: any = 0;
  createappEdit: any = 0;
  createappDelete: any = 0;
  pages  = 0;
  
  ngOnInit() {
	  
	this.getUsername();
	this.refreshForm = new EventEmitter();
	this.sharedService.currentAccInfo.subscribe(data => this.model.accountName = data);
	this.sharedService.currentProjInfo.subscribe(data => this.model.projectName = data);
	this.getAppln();
	//this.getProjects();
	this.getProjectAccDet();
	
	this.getUserAccess('createapp','add');
	this.getUserAccess('createapp','view');
	this.getUserAccess('createapp','edit');
	this.getUserAccess('createapp','delete');
	
  }
  
  getUserAccess(compName:any, functAcc:any) { /* console.log('--111111111--'); console.log(compName); */
	this.aclService.getRoles().then(userRoles => { /* console.log('--2222222222--'); console.log(compName); */
		if(compName == 'createapp') { /* console.log('--333333333333--'); console.log(compName); */
			if(functAcc == 'add') this.createappAdd = 0;
			if(functAcc == 'view') this.createappView = 0;
			if(functAcc == 'edit') this.createappEdit = 0;
			if(functAcc == 'delete') this.createappDelete = 0;
		} //console.log('--4444444444444--'); console.log(compName);
		var avail = 0; 
		for(let pages of Object.values(userRoles)) {  //console.log('888888888'); console.log(pages);	console.log(compName);
			if(pages.page == compName) {
				var accFunc = pages.functionality;
				/* console.log('99999999999');	
				console.log(pages.page);	
				console.log(accFunc.includes(functAcc)); */
				if(accFunc.includes(functAcc) == true) {
				this.router.navigate(['/application']);
				} else {
					this.router.navigate(['/dashboard']);
				}
				if(accFunc.includes(functAcc)){
					avail = 1;
				}
			}
		}
		 if(compName == 'createapp') {
			if(functAcc == 'add') this.createappAdd = avail;
			if(functAcc == 'view') this.createappView = avail;
			if(functAcc == 'edit') this.createappEdit = avail;
			if(functAcc == 'delete') this.createappDelete = avail;			  
			
		} 
	}); 
  }
  
  getUsername(){
	this.loginService.getLoggedInUser().subscribe(res => {
			//this.userData = res;
			this.sharedService.LoggedUserName.next(res);
			console.log('dddd'+res);
		});
  }
  public form: Object = {
    components: [
        /*{
            "title": "Page 1",
            "label": "Page 1",
            "type": "panel",
            "key": "page1",
            "input": false,
            "components": [
                {
                    "input": true,
                    "key": "textField",
                    "label": "Text Field",
                    "type": "textfield"
                },
                {
                    "input": true,
                    "key": "textField2",
                    "label": "Text Field",
                    "type": "textfield"
                }
            ]
        },
        {
            "title": "Page 2",
            "label": "Page 2",
            "type": "panel",
            "key": "page2",
            "input": false,
            "components": [
                {
                    "input": true,
                    "key": "number",
                    "label": "Number",
                    "type": "number"
                }
            ]
        }*/],
	display: 'wizard'
  };

  onChange(event) {
	//console.log(event.form);
	//this.form.components.push(event.form.components);
    this.jsonElement['nativeElement']['innerHTML'] = '';
    this.jsonElement.nativeElement.appendChild(document.createTextNode(JSON.stringify(event.form, null, 4)));
  }
  
  onSubmit(form1:NgForm) {
	console.log(form1.value);
	//console.log(this.form.components);
	this.loading = true;
	this.applicationService.appSubmit({'accountName':this.model.accountName,'projectName':this.model.projectName},this.form).subscribe(res => {
		this.loading = false;
		if(res['success'] == true){
			this.router.navigate(['/application']);
			this.toastr.success(res.message);
		}else{
			this.toastr.error(res.message);	
		}
		//console.log(res);
	});
  }
  
  getAppln() {
			if(this.model.accountName != '' && this.model.projectName != '') {
				this.applNew = 0;
				this.applicationService.getAppln(this.model.accountName,this.model.projectName).subscribe(res => {
					//this.model = res.data['0'].formVal;
					//console.log(res.data['0']);
					if(res.data.length > 0){
						this.formJson = res.data['0'].applicationJson;
						this.form = {'components':res.data['0'].applicationJson,display: 'wizard'};
					} else {
						this.form = {'components':[],display: 'wizard'};
						//this.formJson = [{'components':[],display: 'wizard'}];
						this.applNew = 1;
					}
					/* console.log('application');
					console.log(this.form); */
				});
			}
			
		  }
  
  getAccountData() {
	this.applicationService.getAccountData().subscribe(res =>{
		this.accountData = res.data;
		//console.log(this.accountData);
	});
  }
  
  getProjects() {
	//console.log(this.model.accountName);
	this.applicationService.getProjects(this.model.accountName).subscribe(res =>{
		this.projectData = res.data;
	});
  }
  
  showPreview() {
    this.refreshForm.emit({
		property: 'form',
		value: this.form
    });
	this.display='block'; 
  }
  hidePreview() {
	this.display='none'; 
	
  }

  
	
  ngAfterViewInit() {
      let formattedCode = Prism.highlight(`import { Component, ElementRef, ViewChild } from '@angular/core';
	@Component({
	selector: 'app-application',
	templateUrl: './application.component.html',
	styleUrls: ['./application.component.css']
	})
	export class ApplicationComponent {
	 constructor() { }
	  @ViewChild('json') jsonElement?: ElementRef;
	  @ViewChild('code') codeElement?: ElementRef;
	  public form: Object ={components: [{
            "title": "Page 1",
            "label": "Page 1",
            "type": "panel",
            "key": "page1",
            "input": false,
            "components": [
                {
                    "input": true,
                    "key": "textField",
                    "label": "Text Field",
                    "type": "textfield"
                },
                {
                    "input": true,
                    "key": "textField2",
                    "label": "Text Field",
                    "type": "textfield"
                }
            ]
        }],display: 'wizard'};
		
	  onChange(event) {
		console.log(event.form);
	  }
	  //console.log('afterview' + this.formJson);
	}`, Prism.languages.javascript, 'javascript');
		//console.log(formattedCode);
		this.codeElement.nativeElement.innerHTML = formattedCode;  
	} 
	
	myBeforeHooks(){
		
	}
	
	formioPagesubmit(subDetPage: any){
		/* console.log("in submit");
		console.log(subDetPage); */
		this.applicationService.sendAPIData(subDetPage.data,this.model.accountName,this.model.projectName)
        .subscribe(res => {
			if(!this.editForm['data']['_id'])
				this.editForm['data']['_id'] = res._id;
			//console.log(res);
		});
	} 
	 
	formioNextPagesubmit(submissionDetPage: any){
		/* console.log("in.....");
		console.log(submissionDetPage); */
		this.applicationService.sendAPIData(submissionDetPage.submission['data'],this.model.accountName,this.model.projectName)
        .subscribe(res => {
			if(!this.editForm['data']['_id'])
				this.editForm['data']['_id'] = res._id;
			//console.log(res);
		});
	}
	
	backtoSection(section:any){
		if(section == 'dashboard') this.router.navigate(['/dashboard']);
		else if(section == 'rule'){
			this.sharedService.changeAccount(this.model.accountName);
			this.sharedService.changeProject(this.model.projectName); 
			this.router.navigate(['/rulengine']);
		}else if(section == 'ageconfig'){
			this.sharedService.changeAccount(this.model.accountName);
			this.sharedService.changeProject(this.model.projectName); 
			this.router.navigate(['/age']); 
		}
	}
	
	getProjectAccDet() {
		this.projectService.getProjectDetails(this.model.accountName,this.model.projectName).subscribe(res =>{
			//this.projectData = res.data;
			this.AccProjectdet = res['data'];
		});
	}
}