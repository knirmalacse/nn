import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplateAcpComponent } from './template-acp.component';

describe('TemplateAcpComponent', () => {
  let component: TemplateAcpComponent;
  let fixture: ComponentFixture<TemplateAcpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TemplateAcpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TemplateAcpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
