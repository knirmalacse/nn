import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-template-acp',
  templateUrl: './template-acp.component.html',
  styleUrls: ['./template-acp.component.css']
})
export class TemplateAcpComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
