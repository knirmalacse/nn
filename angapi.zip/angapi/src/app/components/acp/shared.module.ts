import { NgModule,ModuleWithProviders  } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule }   from '@angular/forms';

import { AdmindateComponent } from './admindate/admindate.component'; 
import { AdminnavComponent } from './adminnav/adminnav.component';
import { AcpheaderComponent } from './acpheader/acpheader.component';
import { AcpnavComponent } from './acpnav/acpnav.component';
import { AcpfooterComponent } from './acpfooter/acpfooter.component';
import { NgxLoadingModule, ngxLoadingAnimationTypes } from 'ngx-loading';


@NgModule({
  imports: [
    CommonModule,
	FormsModule,
	RouterModule,
	ReactiveFormsModule,
    NgxLoadingModule.forRoot({
	    animationType: ngxLoadingAnimationTypes.doubleBounce,
        backdropBackgroundColour: 'rgba(0,0,0,0.1)', 
        backdropBorderRadius: '15px',
        primaryColour: '#bed730', 
        secondaryColour: '#ffffff', 
        tertiaryColour: '#bed730'
    })
  ],
  declarations: [AdmindateComponent,AdminnavComponent,AcpheaderComponent,AcpnavComponent,AcpfooterComponent],
  exports: [AdmindateComponent,AdminnavComponent,AcpheaderComponent,AcpnavComponent,AcpfooterComponent,NgxLoadingModule]
})
export class SharedModule  { }