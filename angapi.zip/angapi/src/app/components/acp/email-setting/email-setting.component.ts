import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { AcpService } from '../../../services/acp.service';
import { ProjectService } from '../../../services/project.service';
import { AcpsharedService } from '../../../services/acpshared.service';
import { Router,ActivatedRoute } from "@angular/router";
declare var $:any;

@Component({
	selector: 'app-email-setting',
	templateUrl: './email-setting.component.html',
	styleUrls: ['./email-setting.component.scss']
})
export class EmailSettingComponent implements OnInit {
	myEmailForm: FormGroup;
	mobilesms: Boolean = false;
	isSubmitted: Boolean = false;
	contentTypeStatus: Boolean = false;
	contentOptionTypestatus: Boolean = false;
	isSubject: Boolean = false;
	editButton:Boolean = false;
	projectString: string;
	ACPprojectName : string = '';
	projectSetting: any;
	notificationId: any;
	
	constructor(private router: Router,private route: ActivatedRoute, private projectService: ProjectService, 
				private acpsharedService: AcpsharedService, private fb: FormBuilder, private toastr: ToastrService, 
				private _acpservice: AcpService) { }

	ngOnInit() {
		$('[data-toggle="tooltip"]').tooltip();
		this.route.params.subscribe(params => {
			this.projectString = params['projectId']; 
			this.getProjectIdentifier(this.projectString); 
		});
		this.myEmailForm = this.fb.group({
			contentType: ['', Validators.required],
			contentOptionType: ['', Validators.required],
			subject: [''],
			description: ['', Validators.required]
		});
		this.myEmailForm.patchValue({ contentType: '0', contentOptionType: '0' });
	}
	getProjectIdentifier(projId) {
		this.projectService.getProjIdentifier(projId).subscribe( res => {
			this.projectSetting = res['data'];
			let resultData = res['data'];
			console.log("this.projectSetting ",this.projectSetting)
			if(resultData.hasOwnProperty('projectName')){
				this.acpsharedService.ACPprojectName.subscribe( value => {
					this.ACPprojectName = value;
				});
				this.acpsharedService.ACPprojectName.next(this.projectSetting.projectName); 
				this.acpsharedService.ACPProjectIdentifier.next(projId); 
			}else{
				this.router.navigate(['404']);
			}
		});
	  }
	checkoptions() {
		if (this.myEmailForm.value.contentType == '0' && (this.myEmailForm.value.contentOptionType == 'initial' || this.myEmailForm.value.contentOptionType == 'paid' || this.myEmailForm.value.contentOptionType == 'nofee')) {
			this.toastr.error('Please select content type');
			this.contentTypeStatus = true;
			this.contentOptionTypestatus = false;
		} else if (this.myEmailForm.value.contentType != '0' && this.myEmailForm.value.contentOptionType == '0') {
			this.mobilesms = (this.myEmailForm.value.contentType == 'email') ? true : false;
			this.contentTypeStatus = false;
			this.toastr.warning('Please select content options');
		} else {
			this.mobilesms = (this.myEmailForm.value.contentType == 'email') ? true : false;
			this.getNotification();
		}
		console.log("ffddf ", this.myEmailForm.value)
	}
	getNotification() {
		let objd = {contentType: this.myEmailForm.value.contentType,
					contentOptionType: this.myEmailForm.value.contentOptionType,
					projId: this.projectString ,
					PID: this.projectString,
					projectIdentifier: this.projectSetting.projectIdentifier
				   };
		this._acpservice.getNotificationBy(objd).subscribe(result => {
			if(result.status == 200){
				this.notificationId = result.data._id;
				this.myEmailForm.patchValue({ contentType: result.data.notificationType? result.data.notificationType : this.myEmailForm.value.contentType, 
											  contentOptionType: result.data.NotificationOption? result.data.NotificationOption : this.myEmailForm.value.contentOptionType, 
											  subject: (result.data.notificationType == 'email')?result.data.subject: '',
											  description: result.data.content? result.data.content : '' 
											});
				this.editButton = true;
				console.log("resultttr ",result)
			} else {
				this.myEmailForm.patchValue({
											 subject: "", 
											 description: ""
											});
				console.log("resultttr no ",result)
				this.editButton = false;
			}  
		})
	}
	saveEmailSettings(data) {
		if (this.myEmailForm.invalid) {
			this.contentTypeStatus = (this.myEmailForm.value.contentType == '0') ? true : false;
			this.contentOptionTypestatus = (this.myEmailForm.value.contentOptionType == '0') ? true : false;
			this.isSubject = (this.myEmailForm.value.contentType == 'email' && this.myEmailForm.value.subject == '')? true : false;
			this.isSubmitted = true
			console.log("this.myEmailForm ", this.myEmailForm)
			this.toastr.error('Please select content type');
			return;
		} else {
			if (this.myEmailForm.value.contentType == 'email' && this.myEmailForm.value.subject == '') {
				this.isSubject = true;
				return;
			} else {
				this.contentTypeStatus = this.contentOptionTypestatus = this.isSubject = this.isSubmitted = false; 
				console.log("ffffff ",this.projectString," tytttttt ",this.projectSetting.projectIdentifier)
				data.projId = this.projectString;
				data.content = data.description;
				data.notificationId = this.notificationId;
				data.PID = this.projectString;
				data.projectIdentifier = this.projectSetting.projectIdentifier;
				this._acpservice.addEditEmailTemplate(data).subscribe(result=> {
					if(result.status == 200){
						this.toastr.success("Email template added successfully")
						console.log("success ",result)
					} else {
						this.toastr.error("failed to added email template")
					}
				})
				console.log("saveEmailSettings ", data)
			}
		} 
	}
	toltipfun(txt){
		console.log("ffff ")
		// $('[data-toggle="tooltip"]').tooltip();
		// $('[data-toggle="tooltip"]').tooltip({title: 'Goodbye'})
		  


		$('[data-toggle="tooltip"]').attr('data-original-title', 'Copied!')
			.tooltip('show');
		setTimeout( function() {
			$('[data-toggle="tooltip"]').attr('data-original-title', 'click to copy')
			.tooltip('hide');
		  }, 1000);
	}

}
