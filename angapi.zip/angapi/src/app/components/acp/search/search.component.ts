import { CommonModule } from '@angular/common';
import { FormsModule }   from '@angular/forms';
import { NgModule,Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from "@angular/router"; 
import { AcpService } from '../../../services/acp.service';
import { ProjectService } from '../../../services/project.service';
import { AcpsharedService } from '../../../services/acpshared.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent implements OnInit {
	
  rtnData:any; 
  projectString:string;
  projectSetting: any;
  ACPprojectName: string;
  searchList:any;
  searchtype : string="";
  searchval:string="";
  constructor(private router: Router,private acpService: AcpService, private route: ActivatedRoute, private projectService: ProjectService,private acpsharedService: AcpsharedService) {
	  this.route.params.subscribe(params => {
			this.projectString = params['projectId'];
			this.getProjectIdentifier(this.projectString);
	  });
  }
  searchView: any = 0;  
  pages  = 0;
  ACPProjectIdentifier : String;
  ngOnInit() {  
  }
	
  getProjectIdentifier(projId) {
	this.projectService.getProjIdentifier(projId).subscribe( res => {
		this.projectSetting = res['data'];
		let resultData = res['data'];
		if(resultData.hasOwnProperty('projectName')){
			this.acpsharedService.ACPprojectName.subscribe( value => {
				this.ACPprojectName = value;
			});
			this.acpsharedService.ACPProjectIdentifier.subscribe( value => {
				this.ACPProjectIdentifier = value; 
			});
			this.acpsharedService.ACPprojectName.next(this.projectSetting.projectName); 
			this.acpsharedService.ACPProjectIdentifier.next(projId); 
			
			this.getsearchList(''); 
			this.getUserAccess('searchsection','view');
		}else{
			this.router.navigate(['404']);
		}
		
	});
  }
  getUserAccess(compName:any, functAcc:any) {
	  this.acpService.getRolesNew(this.projectString,this.projectSetting.projectIdentifier).then(userRoles => {
		if(compName == 'searchsection') {	 
			if(functAcc == 'view') this.searchView = 0;
		}   
		var avail = 0; 
		for(let pages of Object.values(userRoles)) {	
			if(pages.page == compName) {
				var accFunc = pages.functionality;
				if(accFunc.includes(functAcc) == true) { 
				this.router.navigate(['/acp/'+this.ACPProjectIdentifier+'/latestsearch']);
				} else {
				this.router.navigate(['/acp/'+this.ACPProjectIdentifier+'/settings']);	
				}
				if(accFunc.includes(functAcc)){
					avail = 1;
				}
			}
		}
		if(compName == 'searchsection') {
			if(functAcc == 'view') this.searchView = avail;		  	
		} 
	});   
  }
  getsearchList(searchformData){
    var searchtypeVal;var searchvalVal = "";
	if(searchformData!=''){
		searchtypeVal = searchformData.value['searchtype'];
		searchvalVal = searchformData.value['searchval'];
	}
	this.acpService.getLatestSearch(this.projectString,this.projectSetting.projectIdentifier,searchtypeVal,searchvalVal).subscribe( result => {
	  this.searchList = result['data'];
    });
  }
 
}