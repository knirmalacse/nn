import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DocumentmgmtComponent } from './documentmgmt.component';

const routes: Routes = [
{ path: '', component: DocumentmgmtComponent }
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DocumentmgmtRoutingModule { }