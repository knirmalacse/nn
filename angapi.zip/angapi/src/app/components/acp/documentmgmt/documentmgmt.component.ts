import { CommonModule } from '@angular/common';
import { FormsModule }   from '@angular/forms';
import { NgModule,Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from "@angular/router"; 
import { Docmgmt } from '../../../classes/docmgmt';
import { AdminnavComponent } from '../adminnav/adminnav.component';
import { AdmindateComponent } from '../admindate/admindate.component';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable'; 
import { AcpService } from '../../../services/acp.service';
import { ProjectService } from '../../../services/project.service';
import { AcpsharedService } from '../../../services/acpshared.service';
import { environment } from '../../../../environments/environment';
import * as AWS from 'aws-sdk/global';
import * as S3 from 'aws-sdk/clients/s3'; 
@Component({
  selector: 'app-documentmgmt',
  templateUrl: './documentmgmt.component.html',
  styleUrls: ['./documentmgmt.component.css']
})
export class DocumentmgmtComponent implements OnInit {
	
  appDocMgmt = new Docmgmt('', '',''); 
  selectedFile: File = null;
  FOLDER = 'staticdoc/';
  BUCKET = 'uploaddt';
  REGION = 'ap-south-1';
  logoPath:string = "";
  LogoMethod: any = environment.FileUploadMethod;
  docTypes = [
    {'key':'Doc1','value':'Doc1'},
    {'key':'Doc2','value':'Doc2'},
    {'key':'Doc3','value':'Doc3'},
    {'key':'Doc4','value':'Doc4'},
    {'key':'Doc5','value':'Doc5'},
    {'key':'Doc6','value':'Doc6'},
    {'key':'Doc7','value':'Doc7'},
    {'key':'Doc8','value':'Doc8'},
    {'key':'Doc9','value':'Doc9'},
    {'key':'Doc10','value':'Doc10'},
    {'key':'Doc11','value':'Doc11'},
    {'key':'Doc12','value':'Doc12'},
    {'key':'Doc13','value':'Doc13'},
    {'key':'Doc14','value':'Doc14'},
    {'key':'Doc15','value':'Doc15'},
    {'key':'Doc16','value':'Doc16'},
    {'key':'Doc17','value':'Doc17'},
    {'key':'Doc18','value':'Doc18'},
    {'key':'Doc19','value':'Doc19'},
    {'key':'Doc20','value':'Doc20'}
  ];
  projectString:string;
  projectSetting: any;
  ACPprojectName: string;
  docList: any; 
  
  constructor(private router: Router,private acpService: AcpService, private route: ActivatedRoute, private projectService: ProjectService,private acpsharedService: AcpsharedService) {
	  this.route.params.subscribe(params => {
			this.projectString = params['projectId'];
			this.getProjectIdentifier(this.projectString);
	  });
  }
  docView: any = 0;  
  pages  = 0;
  ACPProjectIdentifier : String;
  ngOnInit() {  
  }
	
  getProjectIdentifier(projId) {
	this.projectService.getProjIdentifier(projId).subscribe( res => {
		this.projectSetting = res['data'];
		let resultData = res['data'];
		
		if(resultData.hasOwnProperty('projectName')){
			this.acpsharedService.ACPprojectName.subscribe( value => {
				this.ACPprojectName = value;
			});
			this.acpsharedService.ACPProjectIdentifier.subscribe( value => {
				this.ACPProjectIdentifier = value; 
			});
			this.acpsharedService.ACPprojectName.next(this.projectSetting.projectName); 
			this.acpsharedService.ACPProjectIdentifier.next(projId); 
			
			this.getDocListdata();
			this.getUserAccess('doc','view');
		}else{
			this.router.navigate(['404']);
		}
	});
  }
  getUserAccess(compName:any, functAcc:any) {
	  this.acpService.getRolesNew(this.projectString,this.projectSetting.projectIdentifier).then(userRoles => {
		if(compName == 'doc') {	 
			if(functAcc == 'view') this.docView = 0;
		}   
		var avail = 0; 
		for(let pages of Object.values(userRoles)) {	
			if(pages.page == compName) {
				var accFunc = pages.functionality;
				if(accFunc.includes(functAcc) == true) { 
				this.router.navigate(['/acp/'+this.ACPProjectIdentifier+'/documentManagement']);
				} else {
				this.router.navigate(['/acp/'+this.ACPProjectIdentifier+'/settings']);	
				}
				if(accFunc.includes(functAcc)){
					avail = 1;
				}
			}
		}
		if(compName == 'doc') {
			if(functAcc == 'view') this.docView = avail;		  	
		} 
	});   
  }
   
  uploadfile(file) {
			const bucket = new S3(
			  {
				accessKeyId: 'AKIATUXKDK3XI6MTIGGS',
				secretAccessKey: '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',
				region: 'ap-south-1'
			  }
			);

			const params = {
			  Bucket: 'uploaddt',
			  Key: this.projectSetting.projectIdentifier +'/'+ this.FOLDER + file.name,
			  ACL: 'public-read',
			  Body: file
			};
			 
			bucket.upload(params, function (err, data) {
			  if (err) {  
				console.log('There was an error uploading your file: ', err);
				return false;
			  } 
			  return true; 
			  
			});
  } 
  onSubmit(event,formData) {
	if(environment.FileUploadMethod==1)
	 {
		let orginalData = formData.value;
		this.selectedFile = <File>event.target.files[0];
		var fd = new FormData(); 
		 fd.append('doccategory', orginalData.doccategory);
		 fd.append('docname', orginalData.docname);
		 fd.append('projectString', this.projectString);
		 fd.append('projectIdentifier', this.projectSetting.projectIdentifier);
		 
		fd.append('filed', this.selectedFile, this.selectedFile.name);
		this.acpService.saveDocMgmt(fd).subscribe( res => { 
			if(res['success'] == true){
				this.appDocMgmt = new Docmgmt('','','');   
				formData.reset(); 
				this.getDocListdata();
			}
			//this.resData = res;
			//this.starttimeVar=true;this.endtimeVar=true;this.reprinttimeVar=true;
		});
	 } else {
			let orginalData = formData.value;
			this.selectedFile = <File>event.target.files[0];
			if(this.selectedFile)
			this.uploadfile(this.selectedFile);		
			var logoPathValue='https://'+this.BUCKET+'.s3.'+this.REGION+'.amazonaws.com/'+this.projectSetting.projectIdentifier+'/' +this.FOLDER+this.selectedFile.name;
 			 
			this.acpService.saveDocMgmt_FileUpload(orginalData,logoPathValue,this.projectString,this.projectSetting.projectIdentifier).subscribe( res => {
				  if(res['success'] == true){
					this.appDocMgmt = new Docmgmt('','','');   
					formData.reset(); 
					this.getDocListdata();
			 	  }
			});  
		 
	 }
	
	
  }  
   getDocListdata(){
	this.acpService.getDocList(this.projectString,this.projectSetting.projectIdentifier).subscribe( result => {
	  this.docList = result['data'];
    });
  }
  DocumentsDownload(id,filepath){	
		  window.open(filepath, '_blank');		  
	}
}