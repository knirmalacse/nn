import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormsModule, ReactiveFormsModule }   from '@angular/forms';
import { RouterModule} from '@angular/router';
import { SharedModule } from '../shared.module';

import { DocumentmgmtRoutingModule } from './documentmgmt-routing.module';
import { DocumentmgmtComponent } from './documentmgmt.component';

@NgModule({
  imports: [
    CommonModule,
    DocumentmgmtRoutingModule,
	FormsModule,
	RouterModule,
	SharedModule,
	ReactiveFormsModule
  ],
  declarations: [DocumentmgmtComponent]
})
export class DocumentmgmtModule { }