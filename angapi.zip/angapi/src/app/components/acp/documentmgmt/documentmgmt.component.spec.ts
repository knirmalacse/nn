import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentmgmtComponent } from './documentmgmt.component';

describe('DocumentmgmtComponent', () => {
  let component: DocumentmgmtComponent;
  let fixture: ComponentFixture<DocumentmgmtComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocumentmgmtComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentmgmtComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
