export class FileUpload {
    name: string;
    url: string;


    constructor(name: string, url: string) {
        this.name = name;
        this.url = url;
		console.log('url');console.log(url);
		console.log('name');console.log(name);
    }
}
