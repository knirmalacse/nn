import { CommonModule } from '@angular/common';
import { FormsModule }   from '@angular/forms';
import { NgModule,Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from "@angular/router";

import { AcpService } from '../../../services/acp.service';
import { ProjectService } from '../../../services/project.service';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {
  
  projectString : string;
  projectSetting : any;
  
  constructor(private router: Router,private acpService: AcpService, private route: ActivatedRoute,private projectService: ProjectService) {
      this.route.params.subscribe(params => {
			this.projectString = params['projectId']; 
			this.getProjectIdentifier(this.projectString);
	  });
  }

  ngOnInit() { }
  
  getProjectIdentifier(projId) {
	this.projectService.getProjIdentifier(projId).subscribe( res => {
		this.projectSetting = res['data'];
		this.acpUserLogout();
	});
  }
   
  acpUserLogout() {
	return this.acpService.logout(this.projectSetting.projectIdentifier).subscribe(res => { 
		if(res == true) {
			this.router.navigate(['/acp/'+this.projectString]);
		} else {
			this.router.navigate(['/acp/'+this.projectString]); 
		} 	
	});
  }

}