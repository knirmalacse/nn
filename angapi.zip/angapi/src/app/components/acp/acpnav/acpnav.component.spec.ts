import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AcpnavComponent } from './acpnav.component';

describe('AcpnavComponent', () => {
  let component: AcpnavComponent;
  let fixture: ComponentFixture<AcpnavComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AcpnavComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AcpnavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
