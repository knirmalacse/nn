import { CommonModule } from '@angular/common';
import { FormsModule }   from '@angular/forms';
import { NgModule,Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from "@angular/router";
import { AcpsharedService } from '../../../services/acpshared.service';

@Component({
  selector: 'app-acpnav',
  templateUrl: './acpnav.component.html',
  styleUrls: ['./acpnav.component.css']
})
export class AcpnavComponent implements OnInit {
	
  projectString: string;
  IsACPUserLoggedIn : boolean;
  ACPLoggedUserName : String;
  
  constructor(private router: Router,private route: ActivatedRoute,private acpsharedService: AcpsharedService) {
	  this.acpsharedService.IsACPUserLoggedIn.subscribe( value => {
        this.IsACPUserLoggedIn = value;
      });
	
	  this.acpsharedService.ACPLoggedUserName.subscribe( value => {
        this.ACPLoggedUserName = value;
      });
	
	  this.acpsharedService.ACPProjectIdentifier.subscribe( value => {
        this.projectString = value;
	  });
  }
  
  ngOnInit() {
  } 

}