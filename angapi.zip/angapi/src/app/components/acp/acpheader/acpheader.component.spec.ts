import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AcpheaderComponent } from './acpheader.component';

describe('AcpheaderComponent', () => {
  let component: AcpheaderComponent;
  let fixture: ComponentFixture<AcpheaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AcpheaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AcpheaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
