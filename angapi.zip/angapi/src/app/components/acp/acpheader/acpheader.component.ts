import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from "@angular/router";
import { LoginService } from '../../../services/login.service';
import { AcpService } from '../../../services/acp.service';
import { AcpsharedService } from '../../../services/acpshared.service';
import { environment } from '../../../../environments/environment';
import { ProjectService } from '../../../services/project.service';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
@Component({
  selector: 'app-acpheader',
  templateUrl: './acpheader.component.html',
  styleUrls: ['./acpheader.component.css']
})
export class AcpheaderComponent implements OnInit {
	
  IsACPUserLoggedIn : boolean;
  ACPLoggedUserName : String;
  ACPProjectIdentifier : String;
  ACPprojectName : String;
  urlRouterStr : any = '';
  ulrAcp : any = 0; 
  projectString : String = '';
  routerPathloc : String = '';
  logoUrl:String = "";
  logoPath:string = "";
  LogoMethod: any = environment.FileUploadMethod;
  constructor(private router: Router,private route: ActivatedRoute,private projectService: ProjectService,private loginService: LoginService,private acpsharedService: AcpsharedService,private acpService: AcpService) { 
  
	this.acpsharedService.IsACPUserLoggedIn.subscribe( value => {
        this.IsACPUserLoggedIn = value;
    });
	this.acpsharedService.ACPLoggedUserName.subscribe( value => {
        this.ACPLoggedUserName = value;
    });
	this.acpsharedService.ACPProjectIdentifier.subscribe( value => {
        this.ACPProjectIdentifier = value;
		
	   let urlString = location.pathname;
	   if(urlString.indexOf('/acp/') >=0 ){
			 this.ulrAcp = '1';
			 let StrtoSplit = '/acp/'+this.ACPProjectIdentifier;
			 this.urlRouterStr = urlString.split(StrtoSplit);
		     this.routerPathloc = "";
			 if(this.urlRouterStr[1]) this.routerPathloc = this.urlRouterStr[1];
			 
			this.logoUrl = environment.appUrl + "acp/readviewImage?projectIdentifier="+value;
			 
			this.projectService.getProjSetting(value).subscribe( res => {
				if(Object.keys(res['data']).length === 0) {	 
				} else {
					let formData = res['data'];
					this.logoPath = formData.logo_path; 
				} 
			});
	   }
    });
	this.acpsharedService.ACPprojectName.subscribe( value => {
        this.ACPprojectName = value;
    });
	
	
  }

  ngOnInit() {
  }
  
  acpUserLogout() {
	  this.router.navigate(['/acp/'+this.ACPProjectIdentifier+'/logout']);
	/* return this.acpService.logout().subscribe(res => { 
			if(res == true) {
				this.isUserLoggedIn = false;
				this.router.navigate(['/acp/'+this.ACPProjectIdentifier+'/logout']);
			} else {
				this.isUserLoggedIn = false;
				this.router.navigate(['/acp/'+this.ACPProjectIdentifier+'/logout']);
			} 	
		}); */
  }

}