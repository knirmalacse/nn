import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from "@angular/router";

@Component({
  selector: 'app-adminnav',
  templateUrl: './adminnav.component.html',
  styleUrls: ['./adminnav.component.css']
})
export class AdminnavComponent implements OnInit {

  projectString:String;
  constructor(private route: ActivatedRoute) { }

  ngOnInit() {
    this.projectString = this.route.snapshot.paramMap.get("projectId");
    //console.log(this.projectString)
  }

}
