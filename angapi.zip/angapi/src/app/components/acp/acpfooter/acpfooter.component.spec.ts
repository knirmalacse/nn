import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AcpfooterComponent } from './acpfooter.component';

describe('AcpfooterComponent', () => {
  let component: AcpfooterComponent;
  let fixture: ComponentFixture<AcpfooterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AcpfooterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AcpfooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
