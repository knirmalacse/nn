import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-acpfooter',
  templateUrl: './acpfooter.component.html',
  styleUrls: ['./acpfooter.component.css']
})
export class AcpfooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
