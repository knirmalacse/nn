import { CommonModule } from '@angular/common';
import { FormsModule }   from '@angular/forms';
import { NgModule,Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from "@angular/router";

//import { Reportsmgmt } from '../../../classes/usermgmt';
import { AcpService } from '../../../services/acp.service';
import { ProjectService } from '../../../services/project.service';
import { AcpsharedService } from '../../../services/acpshared.service';

@Component({
  selector: 'app-invaliduser',
  templateUrl: './invaliduser.component.html',
  styleUrls: ['./invaliduser.component.css']
})
export class InvaliduserComponent implements OnInit {

    
  
  rtnData:any;
  reportsList:any;
  projectString:string;
  projectSetting: any;
  ACPprojectName: string;
  reportstype : string="";
  
  constructor(private router: Router,private acpService: AcpService, private route: ActivatedRoute, private projectService: ProjectService,private acpsharedService: AcpsharedService) { 
	  this.route.params.subscribe(params => {
			this.projectString = params['projectId']; 
			this.getProjectIdentifier(this.projectString);
	  });
  }

  ngOnInit() {
	//this.projectString = this.route.snapshot.paramMap.get("projectId");
	//this.getProjectIdentifier(this.projectString);
	//this.getreportsList(this.projectString);
  }
  
   getProjectIdentifier(projId) {
	this.projectService.getProjIdentifier(projId).subscribe( res => {
		this.projectSetting = res['data'];
		let resultData = res['data'];
		
		if(resultData.hasOwnProperty('projectName')){
		    this.acpsharedService.ACPprojectName.subscribe( value => {
				this.ACPprojectName = value;
		    });
			this.acpsharedService.ACPprojectName.next(this.projectSetting.projectName); 
			this.acpsharedService.ACPProjectIdentifier.next(projId); 
			
			this.getreportsList('');
		}else{
			this.router.navigate(['404']);
		}
	});
  }
 
  
  getreportsList(reportsformData){	 
	this.acpService.getLatestReports(this.projectString,this.projectSetting.projectIdentifier).subscribe( result => {
	  this.reportsList = result['data'];
    });
  }
  acpUserLogout() {
	  this.router.navigate(['/acp/'+this.projectString+'/logout']);	 
  }

}