import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule }   from '@angular/forms';
import { SharedModule } from '../shared.module';

import { InvaliduserRoutingModule } from './invaliduser-routing.module';
import { InvaliduserComponent } from './invaliduser.component';

import { AcpService } from '../../../services/acp.service';

@NgModule({
  imports: [
    CommonModule,
    InvaliduserRoutingModule,
    FormsModule,
	SharedModule
  ],
  declarations: [InvaliduserComponent],
  providers: [AcpService],
  exports: [SharedModule]
})
export class InvaliduserModule { }
