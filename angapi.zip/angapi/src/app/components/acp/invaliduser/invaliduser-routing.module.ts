import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { InvaliduserComponent } from './invaliduser.component'

const routes: Routes = [
  {path: '', component: InvaliduserComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class InvaliduserRoutingModule { }
