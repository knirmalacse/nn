import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule }   from '@angular/forms';
import { SharedModule } from '../shared.module';

import { RightsaccessRoutingModule } from './rightsaccess-routing.module';
import { RightsaccessComponent } from './rightsaccess.component';


@NgModule({
  imports: [
    CommonModule,
    RightsaccessRoutingModule,
    FormsModule,
	SharedModule
  ],
  declarations: [RightsaccessComponent]

})
export class RightsaccessModule { }
