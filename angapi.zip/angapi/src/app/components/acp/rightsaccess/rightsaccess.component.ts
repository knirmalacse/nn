import { CommonModule } from '@angular/common';
import { FormsModule }   from '@angular/forms';
import { NgModule,Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from "@angular/router";
import { NgForm } from '@angular/forms';
//import { Reportsmgmt } from '../../../classes/usermgmt';
import { AcpService } from '../../../services/acp.service';
import { ProjectService } from '../../../services/project.service';
import { AcpsharedService } from '../../../services/acpshared.service';

@Component({
  selector: 'app-rightsaccess',
  templateUrl: './rightsaccess.component.html',
  styleUrls: ['./rightsaccess.component.css']
})
export class RightsaccessComponent implements OnInit {

  userTypes = [{id:'1','userType':'Super Admin'},{id:'2','userType':'Sify Admin'},{id:'3','userType':'Client Admin'},{id:'4','userType':'Report Admin'},{id:'5','userType':'Download Admin'},{id:'6','userType':'Finance Admin'}];
  rtnData:any;
  projectString:string;
  projectSetting: any;
  ACPprojectName: string;
  dataDet:any;
  UserRole:any;
  UserRoleDt:any;
  funArr:any;
  funArrfuns: any;
  rtnDataRes:any;
  view_reports_control:any = false;
  view_settings_control:any = false;
  view_user_control:any = false;
  view_doc_control:any = false;
  view_search_control:any = false;
  view_uba_control:any = false;
  view_rightsaccess_control:any = false;
  
  constructor(private router: Router,private acpService: AcpService, private route: ActivatedRoute, private projectService: ProjectService,private acpsharedService: AcpsharedService) { 
	  this.route.params.subscribe(params => {
			this.projectString = params['projectId']; 
			this.getProjectIdentifier(this.projectString);
	  });
  }
  rightsaccessView: any = 0;  
  pages  = 0;
  ACPProjectIdentifier : String;
  ngOnInit() {
	 
  }
  
   getProjectIdentifier(projId) {
	this.projectService.getProjIdentifier(projId).subscribe( res => {
		this.projectSetting = res['data'];
		let resultData = res['data'];
		if(resultData.hasOwnProperty('projectName')){
		    this.acpsharedService.ACPprojectName.subscribe( value => {
				this.ACPprojectName = value;
		    });
			this.acpsharedService.ACPProjectIdentifier.subscribe( value => {
				this.ACPProjectIdentifier = value; 
			});
			this.acpsharedService.ACPprojectName.next(this.projectSetting.projectName); 
			this.acpsharedService.ACPProjectIdentifier.next(projId); 
			this.getUserAccess('rightsaccess','view');
		}else{
			this.router.navigate(['404']);
		}
	});
  }
   getUserAccess(compName:any, functAcc:any) {
	  this.acpService.getRolesNew(this.projectString,this.projectSetting.projectIdentifier).then(userRoles => {
		if(compName == 'rightsaccess') {	 
			if(functAcc == 'view') this.rightsaccessView = 0;
		}   
		var avail = 0; 
		for(let pages of Object.values(userRoles)) {	
			if(pages.page == compName) {
				var accFunc = pages.functionality;
				if(accFunc.includes(functAcc) == true) { 
				this.router.navigate(['/acp/'+this.ACPProjectIdentifier+'/rightsaccess']);
				} else {
				this.router.navigate(['/acp/'+this.ACPProjectIdentifier+'/settings']);	
				}
				if(accFunc.includes(functAcc)){
					avail = 1;
				}
			}
		}
		if(compName == 'rightsaccess') {
			if(functAcc == 'view') this.rightsaccessView = avail;		  	
		} 
	});   
  }
  // access get details
   onSubmit(aclEngForm: NgForm){
		  let reportsObj = [];
		  let userObj = [];
		  let docObj = [];
		  let searchObj = [];
		  let ubaObj = [];
		  let rightsaccessObj = [];
		
		  if(this.view_reports_control)
		  reportsObj.push('view');
		  if(this.view_rightsaccess_control)
			 rightsaccessObj.push('view');
		   
		  if(this.view_user_control)
			 userObj.push('view');
		  if(this.view_doc_control)
			 docObj.push('view');
		  if(this.view_search_control)
			 searchObj.push('view');
		  if(this.view_uba_control)
			 ubaObj.push('view');
		 
		this.funArr = [{page:'reportssection',functionality:reportsObj},{page:'user',functionality:userObj},{page:'doc',functionality:docObj},{page:'searchsection',functionality:searchObj},{page:'uba',functionality:ubaObj},{page:'rightsaccess',functionality:rightsaccessObj}];
			this.dataDet = {
				roleID: this.UserRole,
				access: this.funArr
			};   
		this.acpService.AcpRightsIns(this.projectString,this.projectSetting.projectIdentifier,this.dataDet,this.UserRoleDt)
        .subscribe(res => {
			this.rtnData = res;
		});
	}
    getAccessDetails(roleID:any){  
		this.view_reports_control = false;
		this.view_user_control = false;
		this.view_doc_control = false;
		this.view_search_control = false;
		this.view_uba_control = false;
		this.view_rightsaccess_control = false;
			
		this.UserRoleDt = '';
	  if(roleID!=""){ 
		     this.acpService.AcpGetRole(this.projectString,this.projectSetting.projectIdentifier,roleID)
			.subscribe(res => {  
									console.log('-------rightaccess res--------');
									console.log(res);
				this.rtnDataRes = res;
				  if(res['success'] == true ){ 
					let accessData = res['data']['access'];
					this.UserRoleDt = res['data']['_id'];
					for (let key in accessData) { 
						var value = accessData[key];
						for (let keyV in value) {
							if(keyV == 'functionality'){
								var valueV = value[keyV];
								for (let keyVal in valueV) {
									var valueVD = valueV[keyVal];
									var pageVal = value['page'];
									if(pageVal == 'reportssection'){
										if(valueVD == 'view') this.view_reports_control = true; 
									}  
									if(pageVal == 'user'){
										if(valueVD == 'view') this.view_user_control = true; 
									}
									if(pageVal == 'doc'){
										if(valueVD == 'view') this.view_doc_control = true; 
									}
									if(pageVal == 'searchsection'){
										if(valueVD == 'view') this.view_search_control = true; 
									}
									if(pageVal == 'uba'){
										if(valueVD == 'view') this.view_uba_control = true; 
									}
									if(pageVal == 'rightsaccess'){
										if(valueVD == 'view') this.view_rightsaccess_control = true; 
									} 
								}
							}
						}
					}
				}   
			});  
	  }
  }
    
  acpUserLogout() {
	  this.router.navigate(['/acp/'+this.projectString+'/logout']);	 
  }

}