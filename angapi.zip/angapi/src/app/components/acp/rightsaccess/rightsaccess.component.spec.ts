import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RightsaccessComponent } from './rightsaccess.component';

describe('RightsaccessComponent', () => {
  let component: RightsaccessComponent;
  let fixture: ComponentFixture<RightsaccessComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RightsaccessComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RightsaccessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
