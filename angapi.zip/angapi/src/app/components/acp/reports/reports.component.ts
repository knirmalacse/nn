import { Component, OnInit,NgModule } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router,ActivatedRoute } from "@angular/router";
import { ReportsService } from '../../../services/reports.service';
import { ApplicationService } from '../../../services/application.service';
import { QueryBuilderConfig } from "angular2-query-builder";

import { ProjectService } from '../../../services/project.service';
import { AcpsharedService } from '../../../services/acpshared.service';
import { AcpService } from '../../../services/acp.service';
@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})
export class ReportsComponent implements OnInit {
  
  reportType:string = ''
  reportFldName:string = ''
  projectString:string = ''
  accountString:string = ''
  QueryBuilderConfigOrigArr:any;
  configPushArrayOrigStr: string = '';
  fieldListArr:any;
  reportDatas = {};
  config: QueryBuilderConfig = {
  fields: { }
};
  selectFieldIpArr1 = []; 
  inputFiledSel:any;
   i : number = 1; 
  constructor(private route: ActivatedRoute, private reportsService : ReportsService, private applicationService : ApplicationService,private acpService: AcpService,private projectService: ProjectService,private acpsharedService: AcpsharedService,public router: Router) { 
	this.route.params.subscribe(params => {
		this.projectString = params['projectId'];
		this.getProjectIdentifier(this.projectString);
	});
  }
  reportsView: any = 0;  
  pages  = 0;
  ACPprojectName: String;
  projectSetting: any;
  ACPProjectIdentifier : String;
  ngOnInit() {
	this.reportDatas['success'] = false;
	this.getAccDetails(this.projectString); 
  }
  
  getAccDetails(projectId) {
	this.reportsService.getAccountDetails(projectId).toPromise().then((result) => {
		this.accountString = result['data']['_id'];
		this.applicationService.getAppln(this.accountString,this.projectString).subscribe(res => {
			if(res.data.length > 0){
				this.QueryBuilderConfigOrigArr = res.data['0'].applicationJson;
				let AccountNameDet = res.data['0'].accountName;
				let ProjectNameDet = res.data['0'].projectName;
				this.getFormIOFields();
			}
		});
	});
  }
  getProjectIdentifier(projId) {
	this.projectService.getProjIdentifier(projId).subscribe( res => {
		this.projectSetting = res['data'];
		let resultData = res['data'];
		if(resultData.hasOwnProperty('projectName')){
			this.acpsharedService.ACPprojectName.subscribe( value => {
				this.ACPprojectName = value;
			});
			this.acpsharedService.ACPProjectIdentifier.subscribe( value => {
				this.ACPProjectIdentifier = value; 
			});
			this.acpsharedService.ACPprojectName.next(this.projectSetting.projectName); 
			this.acpsharedService.ACPProjectIdentifier.next(projId); 
			this.getUserAccess('reportssection','view');
		}else{
			this.router.navigate(['404']);
		}
	});
  }
  getUserAccess(compName:any, functAcc:any) {
	  this.acpService.getRolesNew(this.projectString,this.projectSetting.projectIdentifier).then(userRoles => {
		if(compName == 'reportssection') {	 
			if(functAcc == 'view') this.reportsView = 0;
		}   
		var avail = 0; 
		for(let pages of Object.values(userRoles)) {	
			if(pages.page == compName) {
				var accFunc = pages.functionality;
				if(accFunc.includes(functAcc) == true) { 
				this.router.navigate(['/acp/'+this.ACPProjectIdentifier+'/reports']);
				} else {
				this.router.navigate(['/acp/'+this.ACPProjectIdentifier+'/settings']);	
				}
				if(accFunc.includes(functAcc)){
					avail = 1;
				}
			}
		}
		if(compName == 'reportssection') {
			if(functAcc == 'view') this.reportsView = avail;		  	
		} 
	});   
  }
  
  getFormIOFields() {
	var JsonConfigOrig = this.QueryBuilderConfigOrigArr; 
	var jsonConvertedConfigValue = new Array();
	var configPushArrayOrig = new Array(); 
	
	for (let key in JsonConfigOrig) {
		var value = JsonConfigOrig[key];
		var pageCompVal = value["key"];
		for (let keyC in value['components']) {
			var valueC = value['components'][keyC];
			if(valueC['columns']){//COLUMN LAYOUT
				for (let keyCC in valueC['columns']) {
					var valueCC = valueC['columns'][keyCC];
					var valueCCC = valueCC['components'];
					for (let keyCVV in valueCCC) {
						var valueCVV = valueCCC[keyCVV];
						this.genArrJsonCompField(valueCC,key,keyCVV,pageCompVal); 
					}
					
				}
			}else if(valueC['rows']){ //TABLE LAYOUT
				for (let keyCR in valueC['rows']) {
					var valueCRC = valueC['rows'][keyCR];
					
					for (let keyCRCC in valueCRC) {
						console.log("inner");
						console.log(valueCRC[keyCRCC]['components']);
						var valueCRCR = valueCRC[keyCRCC]['components'];
						for (let keyCV in valueCRCR) {
							var valueCV = valueCRCR[keyCV];
							this.genArrJsonCompField(valueCRC[keyCRCC],key,keyCV,pageCompVal); 
						}
					}
						
				}
			}else if(valueC['components']){ //PANEL LAYOUT & FIELDSET LAYOUT
				//console.log("in");
				//console.log(this.configPushArrayOrigStr);
				//console.log(valueC.label);
				//console.log(valueC);
				if(valueC.type == 'tabs') {						
					var valueCT = valueC['components'];
					console.log(valueCT);
					for (let keyCT in valueCT) {
						var valueCTT = valueCT[keyCT]['components'];
						for (let keyCTT in valueCTT) {
							var valueCTTT = valueCTT[keyCTT];
							this.genArrJsonCompField(valueCT[keyCT],key,keyCTT,pageCompVal); 
						}
						
					}
				}else{
				
					var valueCO = valueC['components'];
					for (let keyCO in valueCO) {
						var valueCOO = valueCO[keyCO];
						this.genArrJsonCompField(valueC,key,keyCO,pageCompVal); 
					}
				}
				//this.genArrJsonCompField(valueC,key,key);
			}else{
				//console.log("in else");
				//console.log(this.configPushArrayOrigStr);
				this.genArrJsonCompField(value,key,keyC,pageCompVal); 
			}
		}  
	} 
	//console.log(this.configPushArrayOrigStr);
	if(this.configPushArrayOrigStr!='') {
		this.configPushArrayOrigStr = this.configPushArrayOrigStr.replace(/,\s*$/, "")+'}';
	}
	//console.log(JSON.parse(this.configPushArrayOrigStr));
	this.fieldListArr = JSON.parse(this.configPushArrayOrigStr);
	//console.log(this.fieldListArr);
	this.config = {fields: JSON.parse(this.configPushArrayOrigStr)}; 
	this.selectFieldIpArr1 = this.selectFieldIpArr1.filter(function(e){return e}); 
	this.inputFiledSel = this.selectFieldIpArr1;
  }
  
  genArrJsonCompField(value,key,keyC,pageCompVal){
		//for (let keyC in value['components']) {
			//console.log(value);
			var valueC = value['components'][keyC];
			
			//var pageCompVal = value["key"];
			var allowFiled = 0;
			
			if(valueC.type == "textfield" 
				|| valueC.type == "textarea" 
				|| valueC.type == "number" 
				|| valueC.type == "select" 
				|| valueC.type =="radio"
				|| valueC.type == "selectboxes" 
				|| valueC.type == "checkbox"
				|| valueC.type == "email" 
			    || valueC.type == "phoneNumber"
				|| valueC.type == "datetime" 
				|| valueC.type == "day"
				|| valueC.type == "password" 
				|| valueC.type == "hidden"){
					
				if(this.i == 1) {this.configPushArrayOrigStr += '{';}
				
				allowFiled = 1;
			} 
			
			if(allowFiled == 1){
				if(valueC.key!=''){
					this.selectFieldIpArr1[this.i] = {'pageCompVal':pageCompVal, 'keyVal': valueC.key, 'keyIndex': keyC, 'componentIndex': key, 'DisplayVal': valueC.label,'typeVal':valueC.type};
				}
				 //console.log(valueC.type);
				var KeyAssign = valueC.key;
				if(valueC.type == 'textfield' || valueC.type == 'textarea' || valueC.type == 'email' || valueC.type == 'phoneNumber' || valueC.type == 'password'){ //Text BoX
					this.configPushArrayOrigStr += '\"'+[KeyAssign]+'\": {"name":\"'+valueC.label+'\", "type": "string"},';
				}else if(valueC.type == 'number'){ //Number
					this.configPushArrayOrigStr += '\"'+[KeyAssign]+'\": {"name":\"'+valueC.label+'\", "type": "number"},';
				}else if(valueC.type == 'datetime' || valueC.type == 'day'){//datetime && day 
					this.configPushArrayOrigStr += '\"'+[KeyAssign]+'\": {"name":\"'+valueC.label+'\", "type": "date"},';
				}else if(valueC.type == 'select' || valueC.type == 'radio' || valueC.type == 'selectboxes'){ //Select & radio 
					var optionStrVal = "";
					if(valueC.type == 'select') var optionStrArray = valueC['data']['values'];
					else if(valueC.type == 'radio' || valueC.type == 'selectboxes') var optionStrArray = valueC['values'];
					for (let keyCV in optionStrArray) {
						var valueCV = optionStrArray[keyCV];
						optionStrVal += '{"name":\"'+valueCV.label+'\", "value": \"'+valueCV.value+'\"},';
					} 
					if(optionStrVal!='') {
						optionStrVal = optionStrVal.replace(/,\s*$/, "");
					}
					this.configPushArrayOrigStr += '\"'+[KeyAssign]+'\": {"name":\"'+valueC.label+'\", "type": "category","options": ['+optionStrVal+']},';
				}else if(valueC.type == 'checkbox'){ //checkbox
					this.configPushArrayOrigStr += '\"'+[KeyAssign]+'\": {"name":\"'+valueC.label+'\", "type": "boolean"},';
				}
				//this.configPushArrayOrigStr = JSON.parse(this.configPushArrayOrigStr);
				//console.log(this.configPushArrayOrigStr);
				this.i++;
			}
			
			/* if(valueC.type == 'htmlelement'){
				if(valueC.key!=''){
					this.selectFieldIpArr1[this.i] = {'pageCompVal':pageCompVal, 'keyVal': valueC.key, 'keyIndex': keyC, 'componentIndex': key, 'DisplayVal': valueC.label};
				} 
			} */
		//}
	}
  
  reportGen(form: NgForm) {
  }
  
  getFieldWiseReports() {
	let selectedField = this.reportType;
	let selectedFieldArr = selectedField.split('-');
	this.reportFldName = selectedFieldArr[1];
	let reports = [];
	let reportsnew1 = [];
	let reportsTot = { 'total' : {}};
	this.reportsService.getFieldWiseReports(this.projectString,selectedFieldArr[1]).subscribe((result)=>{
		let reportFldAvailCategory = Object.keys(result['data']['others']);
		for(var i in reportFldAvailCategory) {
			let totCount = result['data']['notselected'][reportFldAvailCategory[i]];
			for (let value of result['data']['others'][reportFldAvailCategory[i]]) {
				let keysArr = Object.keys(value);
				totCount = totCount + value[keysArr['0']];
				if(!reports.includes(keysArr['0']))
					reports.push(keysArr['0']);
			}
			reportsTot['total'][reportFldAvailCategory[i]] = totCount;
		}
		for(let report of reports) {
			//let temparr1 = [];
			let reportsnew = {};
			reportsnew = {'cat': report};
			for(var i in reportFldAvailCategory) {
				for (let value of result['data']['others'][reportFldAvailCategory[i]]) {
					let keysArr = Object.keys(value);
					if(report === keysArr['0']){
						let temparr = {};
						//temparr[reportFldAvailCategory[i]]  = value[keysArr['0']];
						reportsnew[reportFldAvailCategory[i]] = value[keysArr['0']];
						//temparr1[report] = [temparr];
					}
				}
			}
			reportsnew1.push(reportsnew);
		}
		/* var res = [];
		Object.keys(reportsnew).map((key)=> {
			let group = {'cat': key, cities: []};
			Object.keys(reportsnew[key]).map((key2)=> {
				group.cities.push(reportsnew[key][key2];
			});
			res.push(group);   
		});
		
		
		console.log(res); */
		/*  */
		
		result['reportsnew'] = reportsnew1;
		result['reportsTot'] = reportsTot;
		this.reportDatas = result;
	});
  }
  
  dataDownload(type:string, section:string, fldValue:any=''){
	let selectedField = this.reportType;
	this.reportsService.downloadCSV(this.projectString,selectedField,type,section,fldValue).subscribe(result => {
		let data = result['data']['list'];
		//  console.log('user date' + JSON.stringify(data));
		let csvHeader = result['data']['csvHeader'];
		let csvData = this.ConvertToCSV(data, csvHeader);
		const blob = new Blob([csvData], { type: 'text/csv' });
		//const url= window.URL.createObjectURL(blob);
		//window.open(url);
		
		let dwldLink = document.createElement("a");
        let url= window.URL.createObjectURL(blob);
		let isSafariBrowser = navigator.userAgent.indexOf('Safari') != -1 && navigator.userAgent.indexOf('Chrome') == -1;
		if (isSafariBrowser) { //if Safari open in new window to save file with random filename.
			dwldLink.setAttribute("target", "_blank");
		}
		dwldLink.setAttribute("href", url);
		dwldLink.setAttribute("download", "Enterprise.csv");
		dwldLink.style.visibility = "hidden";
		document.body.appendChild(dwldLink);
		dwldLink.click();
		document.body.removeChild(dwldLink);
	});
  }
  
  ConvertToCSV(objArray, headerList) {
		//console.log('convert to array called');
		var array = typeof objArray != 'object' ? JSON.parse(objArray) : objArray;
		var str = '';
		var row = 'S.No,';

		for (var index in headerList) { //objArray[0]
		   //Now convert each value to string and comma-separated
		   row += headerList[index] + ',';
		}
		row = row.slice(0, -1);
		//append Label row with line break
		str += row + '\r\n';
		for (var i = 0; i < array.length; i++) {
		   var line = (i+1)+'';
		   for (var index in headerList) {//array[i]
			  let head = headerList[index];

			   //if (line != '') line += ','
			   line += ',' + array[i][head];
		   }
		   str += line + '\r\n';
		}
		return str;
	}


}
