import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormsModule, ReactiveFormsModule }   from '@angular/forms';
import { RouterModule} from '@angular/router';
import { SharedModule } from '../shared.module';

import { ReportsRoutingModule } from './reports-routing.module';
import { ReportsComponent } from './reports.component';

@NgModule({
  imports: [
    CommonModule,
    ReportsRoutingModule,
	FormsModule,
	RouterModule,
	SharedModule,
  ],
  declarations: [ReportsComponent]
})
export class ReportsModule { }
