import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdmindateComponent } from './admindate.component';

describe('AdmindateComponent', () => {
  let component: AdmindateComponent;
  let fixture: ComponentFixture<AdmindateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdmindateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdmindateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
