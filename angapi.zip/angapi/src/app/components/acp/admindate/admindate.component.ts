import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-admindate',
  templateUrl: './admindate.component.html',
  styleUrls: ['./admindate.component.scss']
})
export class AdmindateComponent implements OnInit {
	
   @Input() childStatus: boolean;
   @Input() selFldHour: String;
   @Input() selFldMin: String;
   @Input() selFldSec: String;
   
   @Input() hourVal: String;
   @Input() minVal: String;
   @Input() secVal: String;

  dayHour = ['00','01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21','22','23'];
  dayMin = ['00','01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59'];
  daySec = ['00','01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59'];
  
  @Output() startDateEvent = new EventEmitter<string>();
  @Output() endDateEvent = new EventEmitter<string>();
  @Output() reprintDateEvent = new EventEmitter<string>();
   
  constructor() { }

  ngOnInit() {
  }
  
  selVal(fldName, selectedHVal, selectedMVal, selectedSVal) {
	//console.log(fldName);
	if(fldName == 'appStartTimeHour' || fldName == 'appStartTimeMin' || fldName == 'appStartTimeSec')
		this.startDateEvent.emit(selectedHVal+'_'+selectedMVal+'_'+selectedSVal);
	else if(fldName == 'appEndTimeHour' || fldName == 'appEndTimeMin' || fldName == 'appEndTimeSec')
		this.endDateEvent.emit(selectedHVal+'_'+selectedMVal+'_'+selectedSVal);
	else if(fldName == 'appPrintCloseTimeHour' || fldName == 'appPrintCloseTimeMin' || fldName == 'appPrintCloseTimeSec')
		this.reprintDateEvent.emit(selectedHVal+'_'+selectedMVal+'_'+selectedSVal);
  }

}
