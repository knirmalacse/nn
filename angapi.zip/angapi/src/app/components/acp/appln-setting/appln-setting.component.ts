import { CommonModule } from '@angular/common';
import { FormsModule }   from '@angular/forms';
import { NgModule,Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from "@angular/router";

import { ProjectService } from '../../../services/project.service';

import { AcpsharedService } from '../../../services/acpshared.service';

import { AcpService } from '../../../services/acp.service';
import { ToastrService } from 'ngx-toastr';

import { Settings } from '../../../classes/settings';
 import {IMyDpOptions} from '../../../../../node_modules/angular4-datepicker/src/my-date-picker/interfaces';
//import {IMyDpOptions} from 'angular4-datepicker';

import { AdminnavComponent } from '../adminnav/adminnav.component';
import { AdmindateComponent } from '../admindate/admindate.component';
import { environment } from '../../../../environments/environment';


import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable'; 
import * as AWS from 'aws-sdk/global';
import * as S3 from 'aws-sdk/clients/s3'; 
@Component({
  selector: 'app-appln-setting',
  templateUrl: './appln-setting.component.html',
  styleUrls: ['./appln-setting.component.scss']
})
export class ApplnSettingComponent implements OnInit {
  ACPprojectName : string = '';
  appSetting = new Settings(0, '', '', '', '', '', '', '', '', '', '', '', '', '00', '00', '00', '23', '59', '59', '23', '59', '59', '', '', '');
  starttimeVar = true;
  endtimeVar = true;
  reprinttimeVar = true;
  appStatus = true;
  appStartTimeHour = 'appStartTimeHour';
  appStartTimeMin = 'appStartTimeMin';
  appStartTimeSec = 'appStartTimeSec';
  appEndTimeHour = 'appEndTimeHour';
  appEndTimeMin = 'appEndTimeMin';
  appEndTimeSec = 'appEndTimeSec';
  appPrintCloseTimeHour = 'appPrintCloseTimeHour';
  appPrintCloseTimeMin = 'appPrintCloseTimeMin';
  appPrintCloseTimeSec = 'appPrintCloseTimeSec'; 
  public myDatePickerOptions: IMyDpOptions = {
        // other options...
        dateFormat: 'dd/mm/yyyy',
    };
  projectString: string;
  projectId: string;
  projectSetting: any;
  appTime = {
		'appStartTimeHour' : '00',
		'appStartTimeMin' : '00',
		'appStartTimeSec' : '00',
		'appEndTimeHour' : '23',
		'appEndTimeMin' : '59',
		'appEndTimeSec' : '59',
		'appPrintCloseTimeHour' : '23',
		'appPrintCloseTimeMin' : '59',
		'appPrintCloseTimeSec' : '59',
	}
	resData:any;
	selectedFile: File = null;
	  FOLDER = "logo"; 
	  BUCKET = 'uploaddt';
	  REGION = 'ap-south-1';
  loading = false;
  logoUrl:string = "";
  logoPath:string = "";
  logoPathValue:string = "";
  LogoMethod: any = environment.FileUploadMethod;
  changeLogo:boolean = false;
  constructor(private router: Router,private route: ActivatedRoute, private projectService: ProjectService,private acpsharedService: AcpsharedService,private acpService: AcpService,private toastr: ToastrService) { 
		this.route.params.subscribe(params => {
			this.projectString = params['projectId']; 
			this.getProjectIdentifier(this.projectString);
			this.getProjectSettings(this.projectString);
		});
  }

  ngOnInit() { 
/* 	this.projectString = this.route.snapshot.paramMap.get("projectId");
	this.getProjectIdentifier(this.projectString);
	this.getProjectSettings(this.projectString); */ 
  }
  
  getProjectIdentifier(projId) {
	this.projectService.getProjIdentifier(projId).subscribe( res => {
		this.projectSetting = res['data'];
		let resultData = res['data'];
		
		if(resultData.hasOwnProperty('projectName')){
			this.acpsharedService.ACPprojectName.subscribe( value => {
				this.ACPprojectName = value;
			});
			this.acpsharedService.ACPprojectName.next(this.projectSetting.projectName); 
			this.acpsharedService.ACPProjectIdentifier.next(projId); 
		}else{
			this.router.navigate(['404']);
		}
	});
  }
  
  getProjectSettings(projId) {
	this.projectService.getProjSetting(projId).subscribe( res => {
		if(Object.keys(res['data']).length === 0) {
			this.appSetting = new Settings(0, '', '', '', '', '', '', '', '', '', '', '', '', '00', '00', '00', '23', '59', '59', '23', '59', '59', '', '', '');
		} else {
			let formData = res['data'];
			this.appSetting = new Settings(formData._id,formData.appStartDate,formData.appEndDate,formData.appPrintCloseDate,formData.appStatus,formData.appFromEmail,formData.appBounceEmail,formData.appSMSService,formData.appEmailService,formData.appSMSSenderId,formData.appCapthchaService,formData.appMobNo,formData.appEmailId, formData.appStartTimeHour, formData.appStartTimeMin, formData.appStartTimeSec, formData.appEndTimeHour, formData.appEndTimeMin, formData.appEndTimeSec, formData.appPrintCloseTimeHour, formData.appPrintCloseTimeMin, formData.appPrintCloseTimeSec,formData.privateIp,formData.appReplyEmail,formData.appIndexNote);
			
			this.appTime.appStartTimeHour = formData.appStartTimeHour;
			this.appTime.appStartTimeMin = formData.appStartTimeMin;
			this.appTime.appStartTimeSec = formData.appStartTimeSec;
			
			this.appTime.appEndTimeHour = formData.appEndTimeHour;
			this.appTime.appEndTimeMin = formData.appEndTimeMin;
			this.appTime.appEndTimeSec = formData.appEndTimeSec;
	
			this.appTime.appPrintCloseTimeHour = formData.appPrintCloseTimeHour;
			this.appTime.appPrintCloseTimeMin = formData.appPrintCloseTimeMin;
			this.appTime.appPrintCloseTimeSec = formData.appPrintCloseTimeSec;
			
			this.logoUrl = environment.appUrl + "acp/readviewImage?projectIdentifier="+projId;
			this.logoPath = formData.logo_path;
			 
		} 
		
	});
  }
  
  fldToggle(fldval, fld) {
	if(fld == 'starttimeVar')
		this.starttimeVar = !fldval;
	else if(fld == 'endtimeVar')
		this.endtimeVar = !fldval;
	else if(fld == 'reprinttimeVar')
		this.reprinttimeVar = !fldval;
	else if(fld == 'appStatus')
		this.appStatus = !fldval;
  }
  UserFileUpload(files: FileList) { 
	this.selectedFile = files.item(0); 
	 
  }
  uploadfile(file) {
			 
			const bucket = new S3(
			  {
				accessKeyId: 'AKIATUXKDK3XI6MTIGGS',
				secretAccessKey: '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',
				region: 'ap-south-1'
			  }
			);
			 
			 const params = { Bucket: 'uploaddt', Key: this.projectSetting.projectIdentifier+"/"+this.FOLDER+"/"+file.name, ACL: 'public-read', Body: file
			};  
			     
			   bucket.putObject(params, function (err, data) {
			  if (err) {  
				console.log('There was an error uploading your file: ', err);
				return false;
			  }   
			  return true; 
			  
			});    
  } 
	   
  onSubmit(formData) { 
			 
	 if(environment.FileUploadMethod==1)
	 {	 		
				this.loading = true;
				 
				let orginalData = formData.value; 
				let submitData = Object.assign(orginalData,this.appTime);
				console.log('-this.appTimethis--');
				console.log(this.appTime);
				let formDataFile = new FormData();
				if(this.selectedFile)
					formDataFile.append('filed', this.selectedFile, this.selectedFile.name); 
				formDataFile.append('formData', JSON.stringify(submitData)); 
				formDataFile.append('projId', this.projectString);
				formDataFile.append('projectIdentifier', this.projectSetting.projectIdentifier);
				let logoUp = 'N';
				if(this.logoUrl=="" || this.changeLogo) logoUp = 'Y';
				formDataFile.append('logoUp', logoUp);
				
				this.acpService.saveAppSetting(formDataFile).subscribe( res => {
					this.resData = res; 
					 
					this.loading = false;
					if(res['success'] == true){  window.location.reload();
						this.router.navigate(['/acp/'+this.projectString+'/settings']);   
						this.toastr.success(res['message']);
					}else{
						let messageStr: string = res['message'];
						if(typeof(messageStr) != 'object')
							this.toastr.error(res['message']);
					} 
				});
	 } else {
	
			let orginalData = formData.value;
			let submitData = Object.assign(orginalData,this.appTime);
				this.projectService.getProjSetting(this.projectString).subscribe( res1 => {
					if(Object.keys(res1['data']).length === 0) {
							if(this.selectedFile) {  	
								var logoPathValue=this.selectedFile.name;
							} else { 
								var logoPathValue="";		
							}
							
					} else {
							let resResult = res1['data'];
							if(this.selectedFile) { 	
								var logoPathValue=this.selectedFile.name;
							} /* else { 
								var logoPathValue=resResult.logo_path;		
							} */						 
					}
					console.log('---logoPathValue---');
					console.log(logoPathValue);
					this.acpService.saveAppSetting_FileUpload(submitData,logoPathValue,this.projectString,this.projectSetting.projectIdentifier).subscribe( res => {
							  this.resData = res;
							  if(res['success'] == true){  window.location.reload();
								this.router.navigate(['/acp/'+this.projectString+'/settings']);   
								 this.toastr.success(res['message']);
							  }else{
								let messageStr: string = res['message'];
								if(typeof(messageStr) != 'object')
								this.toastr.error(res['message']);
							 }
					}); 
			
				});
			 
			}
}
  
  startDateTime(event) {
	let timeVal = event.split('_');
	this.appTime.appStartTimeHour = timeVal['0'];
	this.appTime.appStartTimeMin = timeVal['1'];
	this.appTime.appStartTimeSec = timeVal['2'];
	//console.log(this.appTime);
  }
  
  endDateTime(event) {
	let timeVal = event.split('_');
	this.appTime.appEndTimeHour = timeVal['0'];
	this.appTime.appEndTimeMin = timeVal['1'];
	this.appTime.appEndTimeSec = timeVal['2'];
	//console.log(this.appTime);
  }
  
  reprintDateTime(event) {
	let timeVal = event.split('_');
	this.appTime.appPrintCloseTimeHour = timeVal['0'];
	this.appTime.appPrintCloseTimeMin = timeVal['1'];
	this.appTime.appPrintCloseTimeSec = timeVal['2'];
	//console.log(this.appTime);
  }

  changeLogoFn(){
	  this.changeLogo = true;
  }
   
  
}
