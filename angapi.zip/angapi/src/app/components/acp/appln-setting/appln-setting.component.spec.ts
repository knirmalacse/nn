import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplnSettingComponent } from './appln-setting.component';

describe('ApplnSettingComponent', () => {
  let component: ApplnSettingComponent;
  let fixture: ComponentFixture<ApplnSettingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApplnSettingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplnSettingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
