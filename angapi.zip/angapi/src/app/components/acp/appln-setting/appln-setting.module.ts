import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormsModule, ReactiveFormsModule }   from '@angular/forms';
import { RouterModule} from '@angular/router';
import { SharedModule } from '../shared.module';
import { MyDatePickerModule } from '../../../../../node_modules/angular4-datepicker/src/my-date-picker';

import { ApplnSettingRoutingModule } from './appln-setting-routing.module';
import { ApplnSettingComponent } from './appln-setting.component';



//import { AcpsharedService } from '../../../services/acpshared.service'; 

@NgModule({
  imports: [
    CommonModule,
    ApplnSettingRoutingModule,
	FormsModule,
	MyDatePickerModule,
	RouterModule,
	SharedModule,
	ReactiveFormsModule
  ],
  declarations: [
  ApplnSettingComponent
  ],
  //providers:[AcpsharedService],
  exports: [SharedModule,RouterModule]
})
export class ApplnSettingModule { }
