import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AcpComponent } from './acp.component';
import { HeaderComponent } from '../header/header.component';
import { EmailSettingComponent } from './email-setting/email-setting.component'; 

import { ReportsModule } from './reports/reports.module';
import { UnblkaccessModule } from './unblkaccess/unblkaccess.module';
import { InvaliduserModule } from './invaliduser/invaliduser.module';
import { RightsaccessModule } from './rightsaccess/rightsaccess.module';
import { ApplnSettingModule } from './appln-setting/appln-setting.module';
import { UsermgmtModule } from './usermgmt/usermgmt.module';
import { SearchModule } from './search/search.module';
import { DocumentmgmtModule } from './documentmgmt/documentmgmt.module';
import { ApplicationprintModule } from './applicationprint/applicationprint.module';
import { LogoutModule } from './logout/logout.module';

import { OnlyLoggedInUsersGuard } from '../../helpers/acploggedinusers.guard';

const routes: Routes = [
 { path: '', component: AcpComponent, canActivate: [OnlyLoggedInUsersGuard] },
 { path: 'reports', canActivate: [OnlyLoggedInUsersGuard], loadChildren: './reports/reports.module#ReportsModule'}, 
 { path: 'settings', canActivate: [OnlyLoggedInUsersGuard], loadChildren: './appln-setting/appln-setting.module#ApplnSettingModule'}, 
 { path: 'logout', canActivate: [OnlyLoggedInUsersGuard], loadChildren: './logout/logout.module#LogoutModule'}, 
 { path: 'userManagement', canActivate: [OnlyLoggedInUsersGuard], loadChildren: './usermgmt/usermgmt.module#UsermgmtModule'},
 { path: 'documentManagement', canActivate: [OnlyLoggedInUsersGuard], loadChildren: './documentmgmt/documentmgmt.module#DocumentmgmtModule'},
 { path: 'latestsearch', canActivate: [OnlyLoggedInUsersGuard],loadChildren: './search/search.module#SearchModule'},
 { path: 'printapplication/:appRegId', canActivate: [OnlyLoggedInUsersGuard],loadChildren: './applicationprint/applicationprint.module#ApplicationprintModule'},
 { path: 'unblkaccess', canActivate: [OnlyLoggedInUsersGuard], loadChildren: './unblkaccess/unblkaccess.module#UnblkaccessModule'},
 { path: 'rightsaccess', canActivate: [OnlyLoggedInUsersGuard], loadChildren: './rightsaccess/rightsaccess.module#RightsaccessModule'},
 { path: 'invaliduser', loadChildren: './invaliduser/invaliduser.module#InvaliduserModule'},
 {path: 'emailsettings', component: EmailSettingComponent, canActivate: [OnlyLoggedInUsersGuard]},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [OnlyLoggedInUsersGuard] 
})
export class AcpRoutingModule { }
