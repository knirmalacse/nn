import { Component, OnInit,NgModule } from '@angular/core';
import { Router,ActivatedRoute } from "@angular/router";
import { NgForm } from '@angular/forms';
import { ProjectService } from '../../services/project.service';
import { AcpService } from '../../services/acp.service';
import { AcpsharedService } from '../../services/acpshared.service';
import {Observable} from 'rxjs/Rx';

@Component({
  selector: 'app-acp',
  templateUrl: './acp.component.html',
  styleUrls: ['./acp.component.css']
})
export class AcpComponent implements OnInit {


  constructor(private router: Router,private route: ActivatedRoute,private projectService: ProjectService,private acpService: AcpService,private acpsharedService: AcpsharedService) { }

  ACPprojectString: string;
  projectId: string;
  rtnData:any;
  invalidloginMsg: string = '';
  projectInfo: any;
  usrName: string = '';
  usrPwd: string = ''; 
  
  ngOnInit() {
	this.ACPprojectString = this.route.snapshot.paramMap.get("projectId");
	this.getProjectIdentifier(this.ACPprojectString);
	this.isLoggedInChk();
  }
  
  getProjectIdentifier(projId) {
	this.projectService.getProjIdentifier(projId).subscribe( res => {		
		this.projectInfo = res['data'];
	    this.acpsharedService.ACPprojectName.next(this.projectInfo.projectName); 
		this.acpsharedService.ACPProjectIdentifier.next(projId);
	});
  }
  
   acpadminLogin(form: NgForm) {
	this.acpService.Login(form.value.usrName,form.value.usrPwd,this.projectInfo.projectIdentifier,form.value.captcha).subscribe(res => {	 	 
				if(res.count==0)			 
				{ 
					this.router.navigate(['acp/'+this.ACPprojectString+'/invaliduser']);
				} else {   
						 
						if(res.success == true) {	 	 
								this.router.navigate(['acp/'+this.ACPprojectString+'/settings']);
								this.acpsharedService.ACPProjectIdentifier.next(this.ACPprojectString);
								this.acpsharedService.IsACPUserLoggedIn.next(true);
								this.acpsharedService.ACPLoggedUserName.next(res.uData['userName']);
							 
						} else {	 		 			
								this.rtnData = res;
								var MsgStr = res.messageCommon;
								this.invalidloginMsg = "";
								if (typeof MsgStr === 'string') {
									this.invalidloginMsg = MsgStr;
								}
							 
						}
				}
	}); 
  }
  
  isLoggedInChk(){
	this.acpService.isLoggedIn(this.projectInfo.projectIdentifier).subscribe(e => {
		console.log(e);
		if (e.success == true) {
			//sessionStorage.removeItem('loggedUserStorage'+this.projectId);
				this.router.navigate(['acp/'+this.ACPprojectString+'/settings']);
		}else{
			//this.router.navigate(['login/'+this.projectId]);
			// return true;
		} 
		/* this.sharedService.IsUserLoggedIn.next(true);
		this.sharedService.LoggedUserName.next('10004'); 
		this.sharedService.LoggedUserName.subscribe( value => {
			this.LoggedUserNameVAl = value;
			console.log(this.LoggedUserNameVAl);
		});*/
		//return true;
	});
  }


}
