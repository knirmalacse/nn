import { CommonModule } from '@angular/common';
import { FormsModule }   from '@angular/forms';
import { NgModule,Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from "@angular/router"; 
import { AdminnavComponent } from '../adminnav/adminnav.component';
import { AdmindateComponent } from '../admindate/admindate.component';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable'; 
import { AcpService } from '../../../services/acp.service';
import { ProjectService } from '../../../services/project.service';
import { AcpsharedService } from '../../../services/acpshared.service';

@Component({
  selector: 'app-testing',
  templateUrl: './testing.component.html',
  styleUrls: ['./testing.component.css']
})
export class TestingComponent implements OnInit {
	
 
  selectedFile: File = null;
  
  projectString:string;
  projectSetting: any;
  ACPprojectName: string;
 
  
  constructor(private router: Router,private acpService: AcpService, private route: ActivatedRoute, private projectService: ProjectService,private acpsharedService: AcpsharedService) {
	  this.route.params.subscribe(params => {
			this.projectString = params['projectId'];
			this.getProjectIdentifier(this.projectString);
	  });
  }
  docView: any = 0;  
  pages  = 0;
  ACPProjectIdentifier : String;
  ngOnInit() {  
  }
	
  getProjectIdentifier(projId) {
	this.projectService.getProjIdentifier(projId).subscribe( res => {
		this.projectSetting = res['data'];
		let resultData = res['data'];
		
		if(resultData.hasOwnProperty('projectName')){
			this.acpsharedService.ACPprojectName.subscribe( value => {
				this.ACPprojectName = value;
			});
			this.acpsharedService.ACPProjectIdentifier.subscribe( value => {
				this.ACPProjectIdentifier = value; 
			});
			this.acpsharedService.ACPprojectName.next(this.projectSetting.projectName); 
			this.acpsharedService.ACPProjectIdentifier.next(projId); 
			
			 
			 
		}else{
			this.router.navigate(['404']);
		}
		
	});
  }
  
 /*  onSubmit(event,formData) {
	let orginalData = formData.value;
	this.selectedFile = <File>event.target.files[0];
	var fd = new FormData(); 
    fd.append('filed', this.selectedFile, this.selectedFile.name);
	this.acpService.saveTesting(fd).subscribe( res => { 
		if(res['success'] == true){
			//this.appTesting = new Docmgmt('','','');   
			formData.reset(); 
			 
		}
		//this.resData = res;
		//this.starttimeVar=true;this.endtimeVar=true;this.reprinttimeVar=true;
	});
  }  */ 
   
}