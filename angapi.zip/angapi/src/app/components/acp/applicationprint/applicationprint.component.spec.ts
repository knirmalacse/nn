import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplicationprintComponent } from './applicationprint.component';

describe('ApplicationprintComponent', () => {
  let component: ApplicationprintComponent;
  let fixture: ComponentFixture<ApplicationprintComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApplicationprintComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplicationprintComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
