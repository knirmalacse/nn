import { CommonModule } from '@angular/common';
import { FormsModule }   from '@angular/forms';
import { NgModule,Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from "@angular/router"; 
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable'; 


import { AcpService } from '../../../services/acp.service';
import { ProjectService } from '../../../services/project.service';
import { AcpsharedService } from '../../../services/acpshared.service';


@Component({
  selector: 'app-applicationprint',
  templateUrl: './applicationprint.component.html',
  styleUrls: ['./applicationprint.component.css']
})
export class ApplicationprintComponent implements OnInit {

  constructor(private router: Router,private acpService: AcpService, private route: ActivatedRoute, private projectService: ProjectService,private acpsharedService: AcpsharedService) { }

  projectString : string;
  appRegId : string;
  ACPprojectName : string;
  projectSetting : any;
  resultRegData : any = '';
  formData: Object;
  formObjFormio: Object;
  
  ngOnInit() {
	  this.route.params.subscribe(params => {
			this.projectString = params['projectId'];
			this.appRegId = params['appRegId'];
			this.getProjectIdentifier(this.projectString);
	  });
  }

  getProjectIdentifier(projId) {
	this.projectService.getProjIdentifier(projId).subscribe( res => {
		this.projectSetting = res['data'];
		let resultData = res['data'];
		
		if(resultData.hasOwnProperty('projectName')){
			this.acpsharedService.ACPprojectName.subscribe( value => {
				this.ACPprojectName = value;
			});
			this.acpsharedService.ACPprojectName.next(this.projectSetting.projectName); 
			this.acpsharedService.ACPProjectIdentifier.next(projId); 
			console.log(this.projectSetting); 
			this.getProjectDetails();
			
		}else{
			this.router.navigate(['404']);
		}
		
	});
  }
  
  getProjectDetails(){
	  this.acpService.getAppln(this.projectSetting['_id'],this.projectSetting['projectid']).subscribe(res => {
			//if(res.data.length > 0){
				this.formObjFormio = {'components':res['data'][0]['applicationJson']/* ,display: 'wizard' */};
			    this.getRegDetails(res['data'][0]['ProjectIdentifier']);
			//} 
	  });
  } 
  
  getRegDetails(ProjectIdentifier){
	  this.acpService.getRegDetails(this.projectString,ProjectIdentifier,this.appRegId).subscribe( res => {
		  if(res['success'] == true){
			 this.formData = {
				 'data':res['data']
			 }
		  }
	  });   
  } 
  
  printApp(){
    //$(".printClass").hide();
	window.print();
	//$(".printClass").show();
  }
}