import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormsModule, ReactiveFormsModule }   from '@angular/forms';
import { RouterModule} from '@angular/router';
import { SharedModule } from '../shared.module';

import { ApplicationprintComponent } from './applicationprint.component';
import { ApplnPrintRoutingModule } from './applicationprint-routing.module';

import { FormioModule/* ,FormioAppConfig */ } from 'angular-formio';

@NgModule({
  imports: [
    CommonModule,
	FormsModule,
	RouterModule,
	SharedModule,
	ReactiveFormsModule,
	ApplnPrintRoutingModule,
	FormioModule
  ],
  declarations: [ApplicationprintComponent]
})
export class ApplicationprintModule { }