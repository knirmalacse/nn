import { CommonModule } from '@angular/common';
import { FormsModule }   from '@angular/forms';
import { NgModule,Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from "@angular/router";
import { AcpService } from '../../../services/acp.service';
import { ProjectService } from '../../../services/project.service';
import { AcpsharedService } from '../../../services/acpshared.service';

@Component({
  selector: 'app-unblkaccess',
  templateUrl: './unblkaccess.component.html',
  styleUrls: ['./unblkaccess.component.scss']
})
export class UnblkaccessComponent implements OnInit {

  rtnData:any;
  unblkaccessList:any;
  projectString:string;
  projectSetting: any;
  ACPprojectName: string;
  unblkaccesstype : string="";
  unblkaccessval : string= "";
  constructor(private router: Router,private acpService: AcpService, private route: ActivatedRoute, private projectService: ProjectService,private acpsharedService: AcpsharedService) { 
	  this.route.params.subscribe(params => {
			this.projectString = params['projectId']; 
			this.getProjectIdentifier(this.projectString);
	  });
  }
  ubaView: any = 0;  
  pages  = 0;
  ACPProjectIdentifier : String;
  ngOnInit() {  
	//this.projectString = this.route.snapshot.paramMap.get("projectId");
	//this.getProjectIdentifier(this.projectString);
  }
  
   getProjectIdentifier(projId) {
	this.projectService.getProjIdentifier(projId).subscribe( res => {
		this.projectSetting = res['data'];
		let resultData = res['data'];
		
		if(resultData.hasOwnProperty('projectName')){
		    this.acpsharedService.ACPprojectName.subscribe( value => {
				this.ACPprojectName = value;
		    });
			this.acpsharedService.ACPProjectIdentifier.subscribe( value => {
				this.ACPProjectIdentifier = value; 
			});
			this.acpsharedService.ACPprojectName.next(this.projectSetting.projectName); 
			this.acpsharedService.ACPProjectIdentifier.next(projId); 
			
			this.getunblkaccessList('');
			this.getUserAccess('uba','view');
		}else{
			this.router.navigate(['404']);
		}
	});
  }
 getUserAccess(compName:any, functAcc:any) {
	  this.acpService.getRolesNew(this.projectString,this.projectSetting.projectIdentifier).then(userRoles => {
		if(compName == 'uba') {	 
			if(functAcc == 'view') this.ubaView = 0;
		}   
		var avail = 0; 
		for(let pages of Object.values(userRoles)) {	
			if(pages.page == compName) {
				var accFunc = pages.functionality;
				if(accFunc.includes(functAcc) == true) { 
				this.router.navigate(['/acp/'+this.ACPProjectIdentifier+'/unblkaccess']);
				} else {
				this.router.navigate(['/acp/'+this.ACPProjectIdentifier+'/settings']);	
				}
				if(accFunc.includes(functAcc)){
					avail = 1;
				}
			}
		}
		if(compName == 'uba') {
			if(functAcc == 'view') this.ubaView = avail;		  	
		} 
	});   
  } 
  getunblkaccessList(unblkaccessformData){
    var unblkaccesstypeVal;var unblkaccessvalVal = "";
	if(unblkaccessformData!=''){
		unblkaccesstypeVal = unblkaccessformData.value['unblkaccesstype'];
		unblkaccessvalVal = unblkaccessformData.value['unblkaccessval'];
	}
	this.acpService.getunblkaccessServices(this.projectString,this.projectSetting.projectIdentifier,unblkaccesstypeVal,unblkaccessvalVal).subscribe( result => {
		 
	  this.unblkaccessList = result;	   
    });
  }
}