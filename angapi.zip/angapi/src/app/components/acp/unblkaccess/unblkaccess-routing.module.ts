import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { UnblkaccessComponent } from './unblkaccess.component'

const routes: Routes = [
  {path: '', component: UnblkaccessComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UnblkaccessRoutingModule { }
