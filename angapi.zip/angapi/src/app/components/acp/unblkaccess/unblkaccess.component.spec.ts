import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UnblkaccessComponent } from './unblkaccess.component';

describe('UnblkaccessComponent', () => {
  let component: UnblkaccessComponent;
  let fixture: ComponentFixture<UnblkaccessComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UnblkaccessComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UnblkaccessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
