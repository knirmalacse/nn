import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AcpRoutingModule } from './acp-routing.module';
import { AcpComponent } from './acp.component';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import {EditorModule} from 'primeng/editor';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
//import { SharedModule } from './shared.module';
/* import { AdmindateComponent } from './admindate/admindate.component';
import { AdminnavComponent } from './adminnav/adminnav.component'; */
import { EmailSettingComponent } from './email-setting/email-setting.component'; 

import { AcpService } from '../../services/acp.service';
import { ReportsService } from '../../services/reports.service';
import { ApplicationService } from '../../services/application.service';
//import { AcpsharedService } from '../../services/acpshared.service';

import { AcpApplnInterceptor } from '../../helpers/acp_appln-interceptor';
import { LogoutModule } from './logout/logout.module';
import { RouterModule} from '@angular/router';
import { SharedModule } from './shared.module';
import { NgxLoadingModule, ngxLoadingAnimationTypes } from 'ngx-loading';

import { RecaptchaModule, RECAPTCHA_SETTINGS, RecaptchaSettings } from 'ng-recaptcha';
import { RecaptchaFormsModule } from 'ng-recaptcha/forms';

@NgModule({
  imports: [
    CommonModule,
    AcpRoutingModule, 
  FormsModule,
  ReactiveFormsModule,
  EditorModule,
	HttpClientModule,
	LogoutModule,
	SharedModule,
	RecaptchaModule,
    RecaptchaFormsModule,
  ],
  declarations: [AcpComponent, EmailSettingComponent],
  exports: [SharedModule,RouterModule],
  providers: [AcpService,ReportsService,ApplicationService,/* AcpsharedService ,*/{
      provide: HTTP_INTERCEPTORS,
      useClass: AcpApplnInterceptor,
      multi: true
	}] 
})
export class AcpModule { }
