import { CommonModule } from '@angular/common';
import { FormsModule }   from '@angular/forms';
import { NgModule,Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from "@angular/router";
import { Usermgmt } from '../../../classes/usermgmt';
import { AcpService } from '../../../services/acp.service';
import { ProjectService } from '../../../services/project.service';
import { AcpsharedService } from '../../../services/acpshared.service';

@Component({
  selector: 'app-usermgmt',
  templateUrl: './usermgmt.component.html',
  styleUrls: ['./usermgmt.component.scss'] 
})
export class UsermgmtComponent implements OnInit {

  appUserMgmt = new Usermgmt(0, '', '', '', '', 'N', '', '');
  adminTypes = [
    {'userId':1,'userName':'Super Admin'},
    {'userId':2,'userName':'Sify Admin'},
    {'userId':3,'userName':'Client Admin'},
    {'userId':4,'userName':'Report Admin'},
    {'userId':5,'userName':'Download Admin'},
    {'userId':6,'userName':'Finance Admin'}
  ];
  adminStatus = [
    {'key':'Y','value':'Active'},
    {'key':'N','value':'Inactive'},
  ];
  users = [];
  rtnData:any;
  userList:any;
  projectString:string;
  projectSetting: any;
  ACPprojectName: string;

  constructor(private router: Router,private acpService: AcpService, private route: ActivatedRoute, private projectService: ProjectService,private acpsharedService: AcpsharedService) { 
	  this.route.params.subscribe(params => {
			this.projectString = params['projectId'];		
			this.getProjectIdentifier(this.projectString); 
	  });
  }
  userView: any = 0;
  pages  = 0;
  ACPProjectIdentifier : String;
  ngOnInit() { 
	//this.projectString = this.route.snapshot.paramMap.get("projectId");
	//this.getProjectIdentifier(this.projectString);
	//this.getUserList(this.projectString);
	
  }  
   getProjectIdentifier(projId) {
	this.projectService.getProjIdentifier(projId).subscribe( res => {
		this.projectSetting = res['data'];
		let resultData = res['data'];		
		if(resultData.hasOwnProperty('projectName')){
		    this.acpsharedService.ACPprojectName.subscribe( value => {
				this.ACPprojectName = value;
		    });
			this.acpsharedService.ACPProjectIdentifier.subscribe( value => {
				this.ACPProjectIdentifier = value; 
			});
			this.acpsharedService.ACPprojectName.next(this.projectSetting.projectName); 
			this.acpsharedService.ACPProjectIdentifier.next(projId); 
			this.getUserList(this.projectString);
			this.getUserAccess('user','view');			
		}else{
			this.router.navigate(['404']);
		}
	});
  }
  getUserAccess(compName:any, functAcc:any) {		
	    this.acpService.getRolesNew(this.projectString,this.projectSetting.projectIdentifier).then(userRoles => {		
		  if(compName == 'user') {		
			if(functAcc == 'view') this.userView = 0;		
		}   		
		var avail = 0; 		
		for(let pages of Object.values(userRoles)) {			
			if(pages.page == compName) {		
				var accFunc = pages.functionality;		
				if(accFunc.includes(functAcc) == true) { 		
				this.router.navigate(['/acp/'+this.ACPProjectIdentifier+'/userManagement']);		
				} else {		
				this.router.navigate(['/acp/'+this.ACPProjectIdentifier+'/settings']);			
				}		
				if(accFunc.includes(functAcc)){		
					avail = 1;		
				}		
			}		
		}		
		if(compName == 'user') {		
			if(functAcc == 'view') this.userView = avail;		  			
		} 	  
	});     		
  }
  onSubmit(formData,uId) {
    let users = formData.value;
    this.acpService.saveAdminUser(users,this.projectString,uId,this.projectSetting.projectIdentifier).subscribe( result => {
      //this.projectSetting = res.data;
	  this.rtnData = result;
	  if(result['success'] == true){
		this.appUserMgmt = new Usermgmt(0, '', '', '', '', 'N', '', '');
		this.getUserList(result['data']["PID"]); 
	  }
    });

  }
  
  getUserList(projId){
	this.acpService.getAdminUser(this.projectString,this.projectSetting.projectIdentifier).subscribe( result => {
	  this.userList = result['data'];
    });
  }
  
  userEdit(uid:any){
	  this.acpService.getUsers(uid,this.projectString,this.projectSetting.projectIdentifier)
		.subscribe(res => {			
			if(res && res['success'] == true){
				let resultData = '';
				if(res['data']) resultData = res['data'][0];
				this.appUserMgmt = new Usermgmt(resultData['_id'], resultData['userName'], resultData['emailID'], resultData['mobileNo'], resultData['userType'], resultData['userStatus'], '', '');
				 console.log('--resultData---');
				 console.log(resultData['userType']);
			}else{
				this.appUserMgmt = new Usermgmt(0, '', '', '', '', 'N', '', '');
			}
		}); 
  } 

}
