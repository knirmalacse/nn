import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule }   from '@angular/forms';
import { SharedModule } from '../shared.module';

import { UsermgmtRoutingModule } from './usermgmt-routing.module';
import { UsermgmtComponent } from './usermgmt.component';



@NgModule({
  imports: [
    CommonModule,
    UsermgmtRoutingModule,
    FormsModule,
	SharedModule
  ],
  declarations: [UsermgmtComponent]

})
export class UsermgmtModule { }


