import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute } from "@angular/router";
import { LoginService } from '../../services/login.service';
import { AcpService } from '../../services/acp.service';
import { SharedService } from '../../services/shared.service';
import { AcpsharedService } from '../../services/acpshared.service';

import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  
  isUserLoggedIn: boolean;
  LoggedUserName: String;
  
  IsACPUserLoggedIn : boolean;
  ACPLoggedUserName : String;
  ACPProjectIdentifier : String;
  ACPprojectName : String;
  urlRouterStr : any = '';
  ulrAcp : any = 0; 
  projectString : String = '';
  routerPathloc : String = '';
  
  constructor( private router: Router,private route: ActivatedRoute,private loginService: LoginService,private sharedService: SharedService,private acpsharedService: AcpsharedService,private acpService: AcpService) {
	this.sharedService.IsUserLoggedIn.subscribe( value => {
		
		//console.log('here');
        this.isUserLoggedIn = value;
    });
	this.sharedService.LoggedUserName.subscribe( value => {
		console.log(value);
		//console.log('here');
        this.LoggedUserName = value;
    });
	
	/* this.acpsharedService.IsACPUserLoggedIn.subscribe( value => {
        this.IsACPUserLoggedIn = value;
    });
	this.acpsharedService.ACPLoggedUserName.subscribe( value => {
        this.ACPLoggedUserName = value;
    });
	this.acpsharedService.ACPProjectIdentifier.subscribe( value => {
        this.ACPProjectIdentifier = value;
		
	   let urlString = location.pathname;
	   if(urlString.indexOf('/acp/') >=0 ){
			 this.ulrAcp = '1';
			 let StrtoSplit = '/acp/'+this.ACPProjectIdentifier;
			 this.urlRouterStr = urlString.split(StrtoSplit);
		     this.routerPathloc = "";
			 if(this.urlRouterStr[1]) this.routerPathloc = this.urlRouterStr[1];
	   }
    });
	this.acpsharedService.ACPprojectName.subscribe( value => {
        this.ACPprojectName = value;
    }); */
  }
  userData:any;
  rtnData:any;
  projectSetting: any;
  ngOnInit() {
	  //console.log(this.ulrAcp);
	//this.getUsername();//userData.usrName
  }
		  
  getUsername(){
	return this.loginService.getLoggedInUser().subscribe(res => {
			this.userData = res;	
			console.log('dddd'+res);
		});
  }
  
  userLogout() {
	//console.log('clicked logout');
	return this.loginService.logout().subscribe(res => {
			if(res == true) {
				this.isUserLoggedIn = false;
				this.router.navigate(['/login']);
			} else {
				this.isUserLoggedIn = false;
				this.router.navigate(['/login']);
			} 	
			//console.log(res);
		});
  }
  
  acpUserLogout() {
	  this.router.navigate(['/acp/'+this.ACPProjectIdentifier+'/logout']);
	/* return this.acpService.logout().subscribe(res => { 
			if(res == true) {
				this.isUserLoggedIn = false;
				this.router.navigate(['/acp/'+this.ACPProjectIdentifier+'/logout']);
			} else {
				this.isUserLoggedIn = false;
				this.router.navigate(['/acp/'+this.ACPProjectIdentifier+'/logout']);
			} 	
		}); */
  }

}
