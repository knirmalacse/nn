import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { LoginService } from '../../services/login.service';
import {Observable} from 'rxjs/Rx';
import { Router } from '@angular/router';
import { SharedService } from '../../services/shared.service';
import { CaptchaComponent } from 'angular-captcha';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  @ViewChild(CaptchaComponent) captchaComponent: CaptchaComponent; 
  constructor( private router: Router,private loginService: LoginService,private sharedService: SharedService) { }
  rtnData:any;
  invalidloginMsg: string = '';
  userEmail: string = '';
  userPwd: string = '';
  captcha:any;
  myRecaptcha: boolean
  
  ngOnInit() {
	/*onSubmit(loginForm): void {
	  this.loginService.login(loginForm.value.userEmail)
        .subscribe(res => {
			this.rtnData = res;
		});    
	}*/
	/* this.captchaComponent.captchaEndpoint = 'http://demo.sifyitest.com/uthayaseelan/sample/botdetect-captcha-lib/simple-botdetect.php';*/
  } 
  
	resolved(captchaResponse: string) {
		/* this.loginService.captchaCheck(captchaResponse).subscribe(res => {
			console.log(res);
		}); */
        //console.log(`Resolved captcha with response: ${captchaResponse}`);
    }
  
  adminLogin(form: NgForm) {
	  //this.rtnData = this.loginService.Login(form.value.userEmail,form.value.userPwd);
	  //console.log(this.rtnData); 
		/* let userEnteredCaptchaCode = this.captchaComponent.userEnteredCaptchaCode; 
		let captchaId = this.captchaComponent.captchaId; 
		const captchaData = {     
		  userEnteredCaptchaCode: userEnteredCaptchaCode,     
		  captchaId: captchaId 
		};
		 */
		console.log(form.value);
        this.loginService.Login(form.value.userEmail,form.value.userPwd,form.value.captcha).subscribe(res => {
			console.log(res);
						
			if(res.success == true) {
				//console.log('hhhh');
				this.router.navigate(['dashboard']);
				this.sharedService.IsUserLoggedIn.next(true);
			} else {
				//console.log('ffff');
				this.rtnData = res;
				this.captchaComponent.reloadImage(); 
				var MsgStr = res.message;
				this.invalidloginMsg = "";
				if (typeof MsgStr === 'string') {
					this.invalidloginMsg = MsgStr;
				}
			}
		});
		//console.log(form.value);  // { first: '', last: '' }
		//console.log(form.valid);  // false
		//,form.value.userPwd
  }
	goForgot() {
		this.router.navigate(['forgot']);
	}
}
