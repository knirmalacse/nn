import { Component, OnInit } from '@angular/core'; 
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router'; 
import { Userform }    from '../../classes/userform';
import { UsersService } from '../../services/users.service';
import { LoginService } from '../../services/login.service';
import { SharedService } from '../../services/shared.service';
import { AclService } from '../../services/acl.service';

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent implements OnInit {

  constructor( private router: Router,private _data:UsersService,private loginService: LoginService,private sharedService: SharedService) { }
	rtnData:any;
   //invalidloginMsg: string = '';
   otpStatus:any = {
	   passwordshowSubmit:false,
	   passwordshowOtp:true,
	   passwordshowform:true,
   };
  ngOnInit() {
		this.model = new Userform('', '','','','','','','');
		this.otpStatus.passwordshowSubmit = false;
		this.otpStatus.passwordshowOtp = true;
	 
  }
   model = new Userform('', '','','','','','','');
	ForgotForm(form: NgForm){
		this._data.passwordReset(form.value)
			.subscribe(res => {
			this.rtnData = res;
			let typecheck = (typeof this.rtnData.message === 'object')?1:0;
			this.otpStatus.message = typecheck;
			/* this.otpStatus.passwordshowSubmit = false;
			this.otpStatus.passwordshowOtp = true; */
			if(this.rtnData.success==true)
			{
				this.otpStatus.passwordshowSubmit = false;
				this.otpStatus.passwordshowOtp = false;
				this.otpStatus.passwordshowform = false;
				this.model = new Userform('', '','','','','','','');
			}		
		}); 
	}
	sentOtpCode(form: NgForm){
		this._data.sendMailIfValidUser(form.value)
			.subscribe(res => {
				this.rtnData = res;
				let typecheck = (typeof this.rtnData.message === 'object')?1:0;
				this.otpStatus.message = typecheck;
				if(this.rtnData.success==true)
				{
					this.otpStatus.passwordshowSubmit = true;
					this.otpStatus.passwordshowOtp = false;
				}
				else
				{
					this.otpStatus.passwordshowSubmit = false;
					this.otpStatus.passwordshowOtp = true;
				}				
		}); 
	}
	redirectLogin() {
		this.router.navigate(['login']);
	}
	
}
