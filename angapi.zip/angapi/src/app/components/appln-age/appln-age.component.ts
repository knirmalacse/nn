import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { NgForm } from '@angular/forms';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';

import { SharedService } from '../../services/shared.service';
import { ApplAgeService } from '../../services/appl-age.service';
import { ProjectService } from '../../services/project.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-appln-age',
  templateUrl: './appln-age.component.html',
  styleUrls: ['./appln-age.component.css'] 
})
export class ApplnAgeComponent implements OnInit {

  
  public loading = false;
  model:any = {'AID':'','PID':'','_id':''};
  public myForm: FormGroup;
  AccProjectdet:any;
  
  constructor(private sharedService: SharedService,private _fb: FormBuilder,private applAgeService: ApplAgeService,private toastr: ToastrService,public router: Router,private projectService:ProjectService) { }
	 
   ngOnInit() {
		this.sharedService.currentAccInfo.subscribe(data => this.model.AID = data);
		this.sharedService.currentProjInfo.subscribe(data => this.model.PID = data);
		this.myForm = this._fb.group({
						age: this._fb.array([
							//this.initAge(),
						])
					});
		this.applAgeService.getAgeCofigDetails(this.model.PID,this.model.AID).subscribe(res => {
		  if(res['success'] == true)
			{ 
				this.model = res['data'];
				for (let i = 0; i <res['data'].ageArrayCount; i++) {
					this.generate(res['data'].formJSON[i]);
				} 
			}   
			else
			{
				this.generate('');
			}
		});
		this.getProjectAccDet();
	}

	initAge(getStoreData) { 
		return this._fb.group({
			ageAsonDate: [getStoreData.ageAsonDate],
			ageMinDate: [getStoreData.ageMinDate],
			ageMaxDate: [getStoreData.ageMaxDate],
			ageMin: [getStoreData.ageMin],
			ageMax: [getStoreData.ageMax],
			ageRel: [getStoreData.ageRel],
		});
	}
	
	generate(getStoreData) {
		const control = <FormArray>this.myForm.controls['age'];
		control.push(this.initAge(getStoreData));
	}

	removeSection(i: number) {
		const control = <FormArray>this.myForm.controls['age'];
		control.removeAt(i);
	}
	
	onSubmit(modelid) {
		//console.log(modelid);
		this.loading = true;
		this.applAgeService.ageConfigStore(this.myForm.value.age,this.model.PID,this.model.AID,modelid)
			.subscribe(res => {
				this.loading = false;
				if(res['success'] == true){
					this.toastr.success(res['message']); 
				}else{
					this.toastr.error("Error in Creation...");
				}
				//this.rtnData = res;
				/* if(res['success'] == true ){
					this.options.onClose();
					this.options.closeDialogSubject.next();
				}  */
		});
	}
	
	backtoSection(section:any){
		if(section == 'dashboard') this.router.navigate(['/dashboard']);
		else if(section == 'rule'){
			this.sharedService.changeAccount(this.model.AID);
			this.sharedService.changeProject(this.model.PID); 
			this.router.navigate(['/rulengine']);
		}else if(section == 'ageconfig'){
			this.sharedService.changeAccount(this.model.AID);
			this.sharedService.changeProject(this.model.PID); 
			this.router.navigate(['/age']); 
		}else if(section == 'application'){
			this.sharedService.changeAccount(this.model.AID);
			this.sharedService.changeProject(this.model.PID); 
			this.router.navigate(['/application']); 
		}
	}
	
	getProjectAccDet() {
		this.projectService.getProjectDetails(this.model.AID,this.model.PID).subscribe(res =>{
			//this.projectData = res.data;
			this.AccProjectdet = res['data'];
		});
	}
}