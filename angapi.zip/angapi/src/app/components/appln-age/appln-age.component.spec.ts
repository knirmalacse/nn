import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApplnAgeComponent } from './appln-age.component';

describe('ApplnAgeComponent', () => {
  let component: ApplnAgeComponent;
  let fixture: ComponentFixture<ApplnAgeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApplnAgeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplnAgeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
