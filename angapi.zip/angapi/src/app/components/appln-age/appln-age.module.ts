import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ApplnAgeRoutingModule } from './appln-age-routing.module';
import { ApplnAgeComponent } from './appln-age.component';
import { MyDatePickerModule } from '../../../../node_modules/angular4-datepicker/src/my-date-picker';
import { NgxLoadingModule, ngxLoadingAnimationTypes } from 'ngx-loading';

@NgModule({
  imports: [
    CommonModule,
    ApplnAgeRoutingModule,
	MyDatePickerModule,
	ReactiveFormsModule,
    NgxLoadingModule.forRoot({
	    animationType: ngxLoadingAnimationTypes.doubleBounce,
        backdropBackgroundColour: 'rgba(0,0,0,0.1)', 
        backdropBorderRadius: '15px',
        primaryColour: '#bed730', 
        secondaryColour: '#ffffff', 
        tertiaryColour: '#bed730'
    })
  ],
  declarations: [ApplnAgeComponent]
})
export class ApplnAgeModule { }
