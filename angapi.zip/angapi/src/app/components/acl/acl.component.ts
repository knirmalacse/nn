import { Component, OnInit, ComponentFactoryResolver, ViewContainerRef } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ModalDialogService,IModalDialog,IModalDialogOptions,ModalDialogOnAction } from "ngx-modal-dialog";
import { Aclform }    from '../../classes/aclform';
import { RoleComponent } from '../role/role.component';
import { RoleService } from '../../services/role.service';
import { Subject } from 'rxjs/Subject';

export class Role {
  id:any;
  role:string;
}

@Component({
  selector: 'app-acl',
  templateUrl: './acl.component.html',
  styleUrls: ['./acl.component.css']
})

export class AclComponent implements OnInit { 

  constructor(private modalService: ModalDialogService, private viewRef: ViewContainerRef, private _role:RoleService) { }
  ngOnInit() {
    this.getRoles();
  }
  roles: Role[];
  selectedRole: any;
  ACLControls:any = [];
  Response:any = '';
  ACLDBSET:any = [];
  ACLBASESET:any = [{
		"Menu":["dashboard"],
    	"Module": "Accounts",
    	"Functioncalls": [{
    			"resource": "account",
    			"methods": [{
					"name":"ListAccounts",
    				"label": "List Accounts",
					"value":false,
    				"method": "GET"
    			}, {
					"name":"CreateAccounts",
    				"label": "Create Accounts",
					"value":false,
    				"method": "POST"
    			}, {
					"name":"DeleteAccounts",
    				"label": "Delete Accounts",
					"value":false,
    				"method": "DELETE"
    			}, {
					"name":"UpdateAccounts",
    				"label": "Update Accounts",
					"value":false,
    				"method": "PUT"
    			}]
    		},
    		{
    			"resource": "account/project",
    			"methods": [{
					"name":"ListProjects",
    				"label": "List Projects",
					"value":false,
    				"method": "GET"
    			}, {
					"name":"CreateProjects",
    				"label": "Create Projects",
					"value":false,
    				"method": "POST"
    			}, {
					"name":"DeleteProjects",
    				"label": "Delete Projects",
					"value":false,
    				"method": "DELETE"
    			}, {
					"name":"UpdateProjects",
    				"label": "Update Projects",
					"value":false,
    				"method": "PUT"
    			}]
    		}
    	]
    }, {
		"Menu":["dashboard" , "users"],
    	"Module": "Users",
    	"Functioncalls": [{
    			"resource": "user",
    			"methods": [{
					"name":"ListUsers",
    				"label": "List Users",
					"value":false,
    				"method": "GET"
    			}, {
					"name":"CreateUsers",
    				"label": "Create Users",
					"value":false,
    				"method": "POST"
    			}, {
					"name":"DeleteUsers",
    				"label": "Delete Users",
					"value":false,
    				"method": "DELETE"
    			}, {
					"name":"UpdateUsers",
    				"label": "Update Users",
					"value":false,
    				"method": "PUT"
    			}]
    		}
    	]
    }];
  model = new Aclform('', {ListAccounts:'',CreateAccounts:'',DeleteAccounts:'',UpdateAccounts:''});

  getRoles() {
	this._role.getRole().subscribe(res => {
		this.roles = res.data;
	});
	return true; 
  }
  updateSet(i,j,k, val) {
	  this.ACLControls[i].Functioncalls[j].methods[k].value = val;
  }
  onChange(event){
	this.selectedRole = event;
	this.model.id = this.selectedRole._id;
	this._role.getPermissionSet(this.model.id).subscribe(res => {
		this.ACLDBSET = res.data.ACLSet;
		// console.log(this.ACLDBSET);
		// this.ACLDBSET = JSON.parse(this.ACLDBSET);
		// console.log(this.ACLDBSET);
		this.ACLControls= Object.assign([], this.ACLBASESET, this.ACLDBSET);
		// this.ACLControls = JSON.parse(this.ACLControls);
		// console.log(this.ACLControls);
	});
  }
  updateRole(selectedRole) {
	this.ACLControls=[];
	if(selectedRole._id!='') {
	  this.modalService.openDialog(this.viewRef, {
		title: 'Role Management',
		childComponent: RoleComponent,
		data: selectedRole,
		onClose: () => this.getRoles()
	  });	
	} else {
	  this.modalService.openDialog(this.viewRef, {
		title: 'Role Management',
		childComponent: RoleComponent,
		onClose: () => this.getRoles()
	  });      
	}
  }
  
  onSubmit(aclForm:NgForm) {
	this._role.updatePermissionSet(this.ACLControls, this.model.id).subscribe(res => {
		if(res.success==false) {
          // this.Response = res.message.role;
		  return false;
		} else if(res.success==true) {
		  this.Response = res.message;
		  setTimeout (() => {
		    this.Response='';
          }, 5000)
		}
	});
  }
}
