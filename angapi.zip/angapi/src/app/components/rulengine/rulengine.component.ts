import { Component, OnInit, ElementRef } from '@angular/core';
import { Router } from "@angular/router";
import { NgForm , FormGroup, FormControl, FormArray, FormBuilder, Validators, FormsModule  } from '@angular/forms';
import { QueryBuilderConfig } from "angular2-query-builder";
import { ApplicationService } from '../../services/application.service';
import { RuleengineService } from '../../services/ruleengine.service';
import { SharedService } from '../../services/shared.service';
import { Workexpservice } from '../../services/workexp.service';
import { SearchfilterPipe } from '../../pipe/searchfilter.pipe';
import { AclService } from '../../services/acl.service';
import { ToastrService } from 'ngx-toastr';
import { ProjectService } from '../../services/project.service';
//import {LOCAL_STORAGE} from 'angular-webstorage-service'


import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'app-rulengine',
  templateUrl: './rulengine.component.html',
  styleUrls: ['./rulengine.component.css']
})
export class RulengineComponent implements OnInit {
 // objectKeys = Object.keys;
  showCRRule:boolean = false;
  showWorkexpRuleManagement:boolean = true;
  showWorkexpRule:boolean = false;
  showAge:boolean = false;
  showEditRule:boolean = false;
  showRuleng:boolean = true;
  showDependent:boolean = false;		
  showUploadSec:boolean = false;		
  showMappingSec:boolean = false;
  model:any = {'accountName':'','projectName':''};
  accountData:any;
  projectData:any;
  ruleEngineData = [];
  worExpData = [];
  formJson = [];
  applNew:any = 0;
  formJsonEdit_id ='';
  alertmsgstr: string = '';
  inputSelectInsert: string = '';
  ruleFor: string = '';
  feeCond1: string = '';
  feeCond2: string = '';
  feeVal1: string = '';
  feeVal2: string = '';
  feeCond: any = [];
  inputSearch: string = '';
  jsonConvertedString = '';
  jsonConvertedStrWorkExp = '';
  jsonConvertedStringAge = '';
  jsonConvertedStringAgeClc = '';
  QueryBuilderConfigOrigArr = { };
  displayPrevJson:boolean = false;
  displayPrevJsonVal = '';
  RelaxFieldThird:any = [];
  RelaxFieldThirdAvail:any = [];
  parentData:any;
  listData:any;
  mappingModel:any;
  AccProjectdet:any;
  
  selectedFile: File = null;
  
  ruleForVal = [{'ruleValue':'Validation','ruleDisplay':'Validation'},{'ruleValue':'Fee','ruleDisplay':'Fee'},{'ruleValue':'Conditional','ruleDisplay':'Conditional'},{'ruleValue':'Concatination','ruleDisplay':'Concatination'}];
  
  //ruleForVal = ['Eligibility','Fee'];
  configPushArrayOrigStr: string = '';
  fieldListArr: any;
  ageRelaxationList: any;
  selectFieldIpArr1 = []; 
  relaxFieldVal = [];
  relaxationlistcount = [];
  relaxFieldCount = [];
  ageDependFieldVal = [];
  i : number = 1; 
  LoadDis = 1;
  loading = false;
  queryInitVal = {
    condition: 'or', 
    rules: [
      /* {field: "age", operator: "<="},
      {field: "birthday", operator: ">="},
      {
        condition: 'or',
        rules: [
          {field: "gender", operator: "="},
          {field: "occupation", operator: "in"},
          {field: "school", operator: "is null"}
        ]
      } */
    ]
  }; 
  
  query = {
    condition: 'or', 
    rules: [
      /* {field: "age", operator: "<="},
      {field: "birthday", operator: ">="},
      {
        condition: 'or',
        rules: [
          {field: "gender", operator: "="},
          {field: "occupation", operator: "in"},
          {field: "school", operator: "is null"}
        ]
      } */
    ]
  }; 
  
  
  convertedStr = this.query;
  
  btnSubmission = true;
  
  config: QueryBuilderConfig = {
  fields: { }
};
  
  inputFiledSel: String[];
  public myForm: FormGroup;
  public myFormworkexp: FormGroup;
  constructor(private router: Router,private sharedService: SharedService, private Workexpservice: Workexpservice, private applicationService: ApplicationService,private ruleengineService: RuleengineService,private aclService: AclService,private elementRef: ElementRef ,private _fb: FormBuilder,private toastr: ToastrService,private projectService:ProjectService) {}
	//ruleEngForm: Object; 
	
	  createruleAdd: any = 0;
	  createruleView: any = 0;
	  createruleEdit: any = 0;
	  createruleDelete: any = 0;
	  pages  = 0;
  
	  ngOnInit() {
		this.loading = true;
		this.sharedService.currentAccInfo.subscribe(data => this.model.accountName = data);
		this.sharedService.currentProjInfo.subscribe(data => this.model.projectName = data);
		this.getAppln();
		this.getProjectAccDet();
		//this.getProjects();
		this.getRuleDet();
		
		this.getUserAccess('createrule','add');
		this.getUserAccess('createrule','view');
		this.getUserAccess('createrule','edit');
		this.getUserAccess('createrule','delete');
	
		//console.log(this.model.accountName);
					
		this.myFormworkexp = this._fb.group({
			totexp:[''],
			workexp: this._fb.array([
				//this.initwork(),
			])
		});
	  }
	  getUserAccess(compName:any, functAcc:any) {
		this.aclService.getRoles().then(userRoles => {
			if(compName == 'createrule') {
				if(functAcc == 'add') this.createruleAdd = 0;
				if(functAcc == 'view') this.createruleView = 0;
				if(functAcc == 'edit') this.createruleEdit = 0;
				if(functAcc == 'delete') this.createruleDelete = 0;
			}
			var avail = 0; 
			for(let pages of Object.values(userRoles)) {  
				if(pages.page == compName) {
					var accFunc = pages.functionality;
					//console.log(accFunc.includes(functAcc));
					if(accFunc.includes(functAcc) == true) {
					this.router.navigate(['/rulengine']);
					} else {
						this.router.navigate(['/dashboard']);
					}
					if(accFunc.includes(functAcc)){
						avail = 1;
					}
				}
			}
			 if(compName == 'createrule') {
				if(functAcc == 'add') this.createruleAdd = avail;
				if(functAcc == 'view') this.createruleView = avail;
				if(functAcc == 'edit') this.createruleEdit = avail;
				if(functAcc == 'delete') this.createruleDelete = avail; 
				
				 
			}  
		}); 
	  }
	  getAppln() {
		//console.log(this.model.accountName);
		if(this.model.accountName != '' && this.model.projectName != '') {
			this.applNew = 0;
			this.applicationService.getAppln(this.model.accountName,this.model.projectName).subscribe(res => {
				if(res.data.length > 0){
					this.QueryBuilderConfigOrigArr = res.data['0'].applicationJson;
					//console.log(this.AccountNameDet);
					//this.QueryBuilderConfigOrigArr = {'components':res.data['0'].applicationJson,display: 'wizard'};
				
					this.convertConfigJsonQuery();
				} else {
					//this.form = {'components':[],display: 'wizard'};
					//this.formJson = [{'components':[],display: 'wizard'}];
					this.applNew = 1;
				}
			});
		}	
	  }
	  
	  getRuleDet(){
		  if(this.model.accountName != '' && this.model.projectName != '') {
				this.ruleengineService.getRulesManage(this.model.accountName,this.model.projectName,'').subscribe(res => {
					this.ruleEngineData = res.data;
					
					//this.ruleEngineData = res.data['0'].applicationJson;
					this.loading = false;
				});
				
		  }
	  }
	convertConfigJsonQuery(){
		var JsonConfigOrig = this.QueryBuilderConfigOrigArr; 
		var jsonConvertedConfigValue = new Array();
		var configPushArrayOrig = new Array(); 
		//var selectFieldIpArr1 = []; 
		//var configPushArrayOrigStr = ''; 
		
		for (let key in JsonConfigOrig) {
			var value = JsonConfigOrig[key];
			var pageCompVal = value["key"];
			//console.log(value);
			
			for (let keyC in value['components']) {
				var valueC = value['components'][keyC];
				if(valueC['columns']){//COLUMN LAYOUT
					//console.log("in column")
					for (let keyCC in valueC['columns']) {
						var valueCC = valueC['columns'][keyCC];
						var valueCCC = valueCC['components'];
						
						//console.log(valueCCC);
						for (let keyCVV in valueCCC) {
							var valueCVV = valueCCC[keyCVV];
							this.genArrJsonCompField(valueCC,key,keyCVV,pageCompVal); 
						}
						
					}
				}else if(valueC['rows']){ //TABLE LAYOUT
					for (let keyCR in valueC['rows']) {
						var valueCRC = valueC['rows'][keyCR];
						
						for (let keyCRCC in valueCRC) {
							/*console.log("inner");
							console.log(valueCRC[keyCRCC]['components']);*/
							var valueCRCR = valueCRC[keyCRCC]['components'];
							for (let keyCV in valueCRCR) {
								var valueCV = valueCRCR[keyCV];
								this.genArrJsonCompField(valueCRC[keyCRCC],key,keyCV,pageCompVal); 
							}
						}
							
					}
				}else if(valueC['components']){ //PANEL LAYOUT & FIELDSET LAYOUT
					//console.log("in");
					//console.log(this.configPushArrayOrigStr);
					//console.log(valueC.label);
					//console.log(valueC);
					if(valueC.type == 'tabs') {						
						var valueCT = valueC['components'];
						//console.log(valueCT);
						for (let keyCT in valueCT) {
							var valueCTT = valueCT[keyCT]['components'];
							for (let keyCTT in valueCTT) {
								var valueCTTT = valueCTT[keyCTT];
								this.genArrJsonCompField(valueCT[keyCT],key,keyCTT,pageCompVal); 
							}
							
						}
					}else{
					
						var valueCO = valueC['components'];
						for (let keyCO in valueCO) {
							var valueCOO = valueCO[keyCO];
							this.genArrJsonCompField(valueC,key,keyCO,pageCompVal); 
						}
					}
					//this.genArrJsonCompField(valueC,key,key);
				}else{
					//console.log("in else");
					//console.log(this.configPushArrayOrigStr);
					this.genArrJsonCompField(value,key,keyC,pageCompVal); 
				}
			}  
		} 
		//console.log(this.configPushArrayOrigStr);
		if(this.configPushArrayOrigStr!='') {
			this.configPushArrayOrigStr = this.configPushArrayOrigStr.replace(/,\s*$/, "")+'}';
		}
		//console.log(JSON.parse(this.configPushArrayOrigStr));
		this.fieldListArr = JSON.parse(this.configPushArrayOrigStr);
		//console.log(this.fieldListArr);
		this.config = {fields: JSON.parse(this.configPushArrayOrigStr)}; 
		this.selectFieldIpArr1 = this.selectFieldIpArr1.filter(function(e){return e}); 
		this.inputFiledSel = this.selectFieldIpArr1;
		//console.log(this.inputFiledSel);
	}

	genArrJsonCompField(value,key,keyC,pageCompVal){
		//for (let keyC in value['components']) {
			//console.log(value);
			var valueC = value['components'][keyC];
			
			//var pageCompVal = value["key"];
			var allowFiled = 0;
			
			if(valueC.type == "textfield" 
				|| valueC.type == "textarea" 
				|| valueC.type == "number" 
				|| valueC.type == "select" 
				|| valueC.type =="radio"
				|| valueC.type == "selectboxes" 
				|| valueC.type == "checkbox"
				|| valueC.type == "email" 
			    || valueC.type == "phoneNumber"
				|| valueC.type == "datetime" 
				|| valueC.type == "day"
				|| valueC.type == "password" 
				|| valueC.type == "hidden"){
					
				if(this.i == 1) {this.configPushArrayOrigStr += '{';}
				
				allowFiled = 1;
			} 
			
			if(allowFiled == 1){
				if(valueC.key!=''){
					this.selectFieldIpArr1[this.i] = {'pageCompVal':pageCompVal, 'keyVal': valueC.key, 'keyIndex': keyC, 'componentIndex': key, 'DisplayVal': valueC.label,'typeVal':valueC.type};
					if(valueC.type == 'select' && valueC.data.values.length > 0)		
						this.selectFieldIpArr1[this.i]['selectOption'] = valueC.data.values;
				}
				 //console.log(valueC.type);
				var KeyAssign = valueC.key;
				if(valueC.type == 'textfield' || valueC.type == 'textarea' || valueC.type == 'email' || valueC.type == 'phoneNumber' || valueC.type == 'password'){ //Text BoX
					this.configPushArrayOrigStr += '\"'+[KeyAssign]+'\": {"name":\"'+valueC.label+'\", "type": "string"},';
				}else if(valueC.type == 'number'){ //Number
					this.configPushArrayOrigStr += '\"'+[KeyAssign]+'\": {"name":\"'+valueC.label+'\", "type": "number"},';
				}else if(valueC.type == 'datetime' || valueC.type == 'day'){//datetime && day 
					this.configPushArrayOrigStr += '\"'+[KeyAssign]+'\": {"name":\"'+valueC.label+'\", "type": "date"},';
				}else if(valueC.type == 'select' || valueC.type == 'radio' || valueC.type == 'selectboxes'){ //Select & radio 
					var optionStrVal = "";
					if(valueC.type == 'select') var optionStrArray = valueC['data']['values'];
					else if(valueC.type == 'radio' || valueC.type == 'selectboxes') var optionStrArray = valueC['values'];
					for (let keyCV in optionStrArray) {
						var valueCV = optionStrArray[keyCV];
						optionStrVal += '{"name":\"'+valueCV.label+'\", "value": \"'+valueCV.value+'\"},';
					} 
					if(optionStrVal!='') {
						optionStrVal = optionStrVal.replace(/,\s*$/, "");
					}
					this.configPushArrayOrigStr += '\"'+[KeyAssign]+'\": {"name":\"'+valueC.label+'\", "type": "category","options": ['+optionStrVal+']},';
				}else if(valueC.type == 'checkbox'){ //checkbox
					this.configPushArrayOrigStr += '\"'+[KeyAssign]+'\": {"name":\"'+valueC.label+'\", "type": "boolean"},';
				}
				//this.configPushArrayOrigStr = JSON.parse(this.configPushArrayOrigStr);
				//console.log(this.configPushArrayOrigStr);
				this.i++;
			}
			
			/* if(valueC.type == 'htmlelement'){
				if(valueC.key!=''){
					this.selectFieldIpArr1[this.i] = {'pageCompVal':pageCompVal, 'keyVal': valueC.key, 'keyIndex': keyC, 'componentIndex': key, 'DisplayVal': valueC.label};
				} 
			} */
		//}
	}
	
	convertJsonQuery(ruleEngForm: NgForm){
		if(ruleEngForm.valid){
			this.loading = true;
			this.btnSubmission = false;
			var JsonRuleVal = this.query; 
			var jsonConvertedValue = new Array();
			var alertmsgstrDisp = this.alertmsgstr; 
			var inputSelectInsertVal = this.inputSelectInsert;
			var inputFiledSelArr = this.inputFiledSel;
			var configArrJson = JSON.parse(this.configPushArrayOrigStr);
			//console.log(this.configPushArrayOrigStr); 
			//console.log("%%%%");
			//console.log(inputFiledSelArr);
			
			ruleEngForm.value.ruleFor = this.ruleFor;
			ruleEngForm.value.inputSelectInsert = this.inputSelectInsert; 
			//if(ruleEngForm.value.ruleFor == 'Fee') {
				/* console.log("start");
				console.log(JsonRuleVal); 
				console.log("end"); */
			//}else if(ruleEngForm.value.ruleFor == 'Eligibility') {
				for (let key in JsonRuleVal) {
					var RulePushArrayOrig = [];
					var value = JsonRuleVal[key];
					if(key=='rules'){ 
						if (value.length > 0) {
							let i = 0;
							for (let keyR in value) {
								i++;
								var valueR = value[keyR];
								
								var condValChk = valueR['condition'];
								if (typeof condValChk != 'undefined'){
									for (let keyR1 in valueR) {
										var valueR1 = valueR[keyR1];
										var RulePushArray = new Array();
										var insertArry = new Array();
										if(keyR1 == 'rules'){ // Rules base
											for (let keyR2 in valueR1) {
												var valueR2 = valueR1[keyR2];
												if(valueR2.operator!=''){
													var OperatorAdd = valueR2.operator;
													if(OperatorAdd == '=') OperatorAdd = '==';
													/* if(OperatorAdd == 'equal')
														insertArry[keyR2] = {["=="]: [{"var": "data."+valueR2.field},{"var":"data."+valueR2.value}]}; */
													if(OperatorAdd == 'sameLetterFields'){
														var cmpVal = valueR2.value;
														var cmpValField = valueR2.sameValue;
														if(cmpVal == '=') cmpVal = '==';
														insertArry[keyR2] = {[cmpVal]: [{"var": "data."+valueR2.field},{"var":"data."+valueR2.sameValue}]}; 
													}else if(OperatorAdd == 'compareFields'){
														
														var cmpVal = valueR2.value;
														var cmpValField = valueR2.compareValue;
														if(cmpVal == '=') cmpVal = '==';
														//For Date Fields
														if(configArrJson[valueR2.field]['type'] == 'date' && configArrJson[valueR2.compareValue]['type'] == 'date'){
															insertArry[keyR2] = {['DateComparisonFnOperator']: [{"var": "data."+valueR2.field},{"var":"data."+valueR2.compareValue},cmpVal]};
														}else{
															insertArry[keyR2] = {[cmpVal]: [{"var": "data."+valueR2.field},{"var":"data."+valueR2.compareValue}]};
														}
													}else if(OperatorAdd == 'startsWith'){
														var cmpVal = valueR2.value;
														var cmpValField = valueR2.desiredValue;
														var cmpValFieldArr = cmpValField.split(",");
														//if(cmpVal == '=') cmpVal = '==';
														
														insertArry[keyR2] = {['in']: [{['substr']:[{"var": "data."+valueR2.field},parseInt(valueR2.value),parseInt(valueR2.lengthValue)]},cmpValFieldArr]}; 
														//insertArry[keyR2] = {['substr']: [{"var": "data."+valueR2.field},{"var":"data."+valueR2.desiredValue}]};
													}else if(OperatorAdd == 'validationRule'){
														var REValidt = valueR2.value;
														var patternStr = "";
														for (let keyVRule in REValidt) {
															var ValueREValidt = REValidt[keyVRule];
															
															if(ValueREValidt == "Alpha") patternStr += "A-Za-z";//"^[A-Za-z]+$";
															else if(ValueREValidt == "Numeric") patternStr += "0-9";//"^[A-Za-z]+$";
															else if(ValueREValidt == "Special character"){
																var specValidt = valueR2.specialValue;
																for (let keySpecRule in specValidt) {
																	var ValueSpecValidt = specValidt[keySpecRule];
																	var patternStrAdd = ValueSpecValidt;
																	if(ValueSpecValidt == 's') patternStrAdd = "\\s";
																	patternStr += patternStrAdd; 
																}
															}
														}
														
														if(patternStr!=""){
															var patternFinalStr = "^["+patternStr+"]+$";
															insertArry[keyR2] = {["regexp_matches"]: [patternFinalStr,{"var": "data."+valueR2.field}]};
														}
													}else if(OperatorAdd == 'concat'){
														var REValidt = valueR2.concatValue;
														var arrLength = REValidt.length;
														var concatArr = [];
														var spaceAdd = " ";
														
														for (var keyVRule in REValidt) {
															/* if (keyVRule != arrLength) {
																spaceAdd = " ";
															}
															if (keyVRule != arrLength-1) {
																//spaceAdd = " ";
																var concatVal = {"var": "data."+REValidt[keyVRule]+" "};
															} else {
																var concatVal = {"var": "data."+REValidt[keyVRule]};
															} */
															var concatVal = {"var": "data."+REValidt[keyVRule]};
															/* if (keyVRule != arrLength-1) {
																concatVal += " ";
															} */
															
															concatArr.push(concatVal);
															concatArr.push(spaceAdd);
														}
														//console.log('start');
														//console.log(concatArr);
														insertArry[keyR2] = {["cat"]: concatArr};
														
													}else{
														if(valueR2.value == null) valueR2.value="";
														if(configArrJson[valueR2.field]['type'] == 'date' && valueR2.value!=""){
															insertArry[keyR2] = {['DateComparisonFnOperator']: [{"var": "data."+valueR2.field},valueR2.value,OperatorAdd]};
														}else{
															insertArry[keyR2] = {[OperatorAdd]: [{"var": "data."+valueR2.field},valueR2.value]};
														}
													}
												}
											}
											var conditionalChild = valueR['condition'];
											//RulePushArray[0] = {[conditionalChild] : insertArry}; 
											if(ruleEngForm.value.ruleFor == 'Fee') {
												let feeCondKey = 'feeVal' + i;
												let feeAmt = (ruleEngForm.value[feeCondKey] == '0')?'NIL':ruleEngForm.value[feeCondKey];
												RulePushArrayOrig.push({[conditionalChild] : insertArry},feeAmt); 
											}else if(ruleEngForm.value.ruleFor == 'Eligibility') {
												RulePushArrayOrig.push({[conditionalChild] : insertArry});
											}else if(ruleEngForm.value.ruleFor == 'Conditional') {
												RulePushArrayOrig.push({[conditionalChild] : insertArry});
											}else if(ruleEngForm.value.ruleFor == 'Concatination') {
												RulePushArrayOrig.push({[conditionalChild] : insertArry});
											}
										}
									}
								}else {
									var insertArryc = new Array();
									var OperatorAdd = valueR.operator;
									if(OperatorAdd == '=') OperatorAdd = '==';
									//console.log(OperatorAdd);
									//insertArryc = {[OperatorAdd]: [{"var": "data."+valueR.field},valueR.value]};
									/* if(OperatorAdd == 'equal') 
										RulePushArrayOrig.push({["=="]: [{"var": "data."+valueR.field},{"var":"data."+valueR.value}]}); */
									if(OperatorAdd == 'sameLetterFields'){
										var cmpVal = valueR.value;
										var cmpValField = valueR.sameValue;
										if(cmpVal == '=') cmpVal = '==';
										RulePushArrayOrig.push({[cmpVal]: [{"var": "data."+valueR.field},{"var":"data."+valueR.sameValue}]}); 
									}else if(OperatorAdd == 'compareFields'){
										var cmpVal = valueR.value;
										var cmpValField = valueR.compareValue;
										if(cmpVal == '=') cmpVal = '==';

										//For Date Fields
										if(configArrJson[valueR.field]['type'] == 'date' && configArrJson[valueR.compareValue]['type'] == 'date'){
											RulePushArrayOrig.push({['DateComparisonFnOperator']: [{"var": "data."+valueR.field},{"var":"data."+valueR.compareValue},cmpVal]}); 
										}else{
											RulePushArrayOrig.push({[cmpVal]: [{"var": "data."+valueR.field},{"var":"data."+valueR.compareValue}]}); 
										}
									}else if(OperatorAdd == 'startsWith'){
										/* var cmpVal = valueR2.value; */
										var cmpValField = valueR.desiredValue;
										var cmpValFieldArr = cmpValField.split(","); 
										//if(cmpVal == '=') cmpVal = '==';
										
										//RulePushArrayOrig.push({['in']: [{['substr']:[{"var": "data."+valueR2.field},valueR2.value]},cmpValFieldArr]});
										RulePushArrayOrig.push({['in']: [{['substr']:[{"var": "data."+valueR.field},parseInt(valueR.value),parseInt(valueR.lengthValue)]},cmpValFieldArr]});
										//insertArry[keyR2] = {['substr']: [{"var": "data."+valueR2.field},{"var":"data."+valueR2.desiredValue}]};
									}else if(OperatorAdd == 'validationRule'){
										var REValidt = valueR.value;
										var patternStr = "";
										for (let keyVRule in REValidt) {
											var ValueREValidt = REValidt[keyVRule];
											if(ValueREValidt == "Alpha") patternStr += "A-Za-z";//"^[A-Za-z]+$";
											else if(ValueREValidt == "Numeric") patternStr += "0-9";//"^[A-Za-z]+$";
											else if(ValueREValidt == "Special character"){
												var specValidt = valueR.specialValue;
												//console.log(specValidt);
												for (let keySpecRule in specValidt) {
													var ValueSpecValidt = specValidt[keySpecRule];
													var patternStrAdd = ValueSpecValidt;
													if(ValueSpecValidt == 's') patternStrAdd = "\\s";
													patternStr += patternStrAdd; 
												}
											}
										}
										
										//console.log(patternStr);
										if(patternStr!=""){
											var patternFinalStr = "^["+patternStr+"]+$";
											RulePushArrayOrig.push({["regexp_matches"]: [patternFinalStr,{"var": "data."+valueR.field}]});
										}
									}else if(OperatorAdd == 'concat'){
										var REValidt = valueR.concatValue;
										var arrLength = REValidt.length;
										var concatArr = [];
										var spaceAdd = " ";
										//console.log("innnnnnnnnnnnnnn");
										//console.log(REValidt);
										for (var keyVRule in REValidt) {
											/* if (keyVRule != arrLength) {
												spaceAdd = " ";
											}
											if (keyVRule != arrLength-1) {
												//spaceAdd = " ";
												var concatVal = {"var": "data."+REValidt[keyVRule]+" "};
											} else {
												var concatVal = {"var": "data."+REValidt[keyVRule]};
											} */
											
											var concatVal = {"var": "data."+REValidt[keyVRule]};
											
											concatArr.push(concatVal);
											concatArr.push(spaceAdd);
											
										}
										//console.log('start');
										//console.log(concatArr);
										//insertArry[keyR2] = {["cat"]: concatArr};
										RulePushArrayOrig.push({["cat"]: concatArr});
										
									}else{
										if(valueR.value == null) valueR.value="";
										if(configArrJson[valueR.field]['type'] == 'date' && valueR.value!=""){
											RulePushArrayOrig.push({['DateComparisonFnOperator']: [{"var": "data."+valueR.field},valueR.value],OperatorAdd});
										}else{
											RulePushArrayOrig.push({[OperatorAdd]: [{"var": "data."+valueR.field},valueR.value]});
										} 
									}
								}
							}
							if(ruleEngForm.value.ruleFor == 'Fee') { RulePushArrayOrig.push('NIL'); }
						} 
						var RulePushArrayOrigV1 = new Array();
						var conditionalChildV1 = JsonRuleVal['condition'];
						if(ruleEngForm.value.ruleFor == 'Fee') {
							jsonConvertedValue.push({"if":RulePushArrayOrig});
						}else if(ruleEngForm.value.ruleFor == 'Conditional' || ruleEngForm.value.ruleFor == 'Concatination') {
							jsonConvertedValue = RulePushArrayOrig;
						}  else {
							jsonConvertedValue.push({"if":[{[conditionalChildV1] : RulePushArrayOrig},true,alertmsgstrDisp]});
						}
						
					}
				}
			
			//}
			/*console.log("in creationnnn")
			console.log(RulePushArrayOrig);
			console.log(jsonConvertedValue);*/
			jsonConvertedValue = jsonConvertedValue.map(function(e){
				return JSON.stringify(e);
			});

			var dataString = jsonConvertedValue.join(","); 
			//this.jsonConvertedString = (JSON.stringify(jsonConvertedValue));
			this.jsonConvertedString = dataString;
			//console.log("inneee");
			/*  var JsonValidateArray = new Array();
			JsonValidateArray.push({'validate':{'json':''}});
			console.log(JsonValidateArray);
			this.QueryBuilderConfigOrigArr['components'][0]={'validate':{'json':''}};  */
		  
			  var obj = JSON.parse(JSON.stringify(this.QueryBuilderConfigOrigArr));
			 // console.log(inputSelectInsertVal);
			  var inputSelectInsertArr = inputSelectInsertVal.split('-');
			  var indexPageVal = inputSelectInsertArr[0]; // page1
			  var compIndexPageVal = inputSelectInsertArr[1]; //firtsName
		  
			/* var pageIndex  = '';
			var compIndex  = ''; */
			//console.log(obj);
			//console.log(indexPageVal);
			//console.log(compIndexPageVal);
			if(ruleEngForm.value.ruleFor == 'Fee' || ruleEngForm.value.ruleFor == 'Concatination') {
				obj = this.jsonAppendComponent_Fee(obj,indexPageVal,compIndexPageVal,'update');
			} else if(ruleEngForm.value.ruleFor == 'Conditional') {
				obj = this.jsonAppendComponent_cnd(obj,indexPageVal,compIndexPageVal,'update');
			} else {
				obj = this.jsonAppendComponent(obj,indexPageVal,compIndexPageVal,'update');
			}
			
			
			this.QueryBuilderConfigOrigArr = (obj);
			 var Jsonapplncomp: Object = {
					components: this.QueryBuilderConfigOrigArr,
					display: 'wizard'
			 }
			  
			 ruleEngForm.value.accountName = this.model.accountName;
			 ruleEngForm.value.projectName = this.model.projectName;
			 
			 ruleEngForm.value.appendField = inputSelectInsertVal;
			 ruleEngForm.value.appendFieldLabel = compIndexPageVal;
			 ruleEngForm.value.querybuiderconfig = this.config;
			 ruleEngForm.value.query = this.query;
			 
			 ruleEngForm.value.rulesJsonLogic = JSON.parse((this.jsonConvertedString));
			 this.applicationService.appSubmit(ruleEngForm.value,Jsonapplncomp).subscribe(res => {
				if(res.success == true){
					this.ruleengineService.ruleAppSubmit(ruleEngForm.value).subscribe(ruleres => {
						if(ruleres.success == true){
							this.getRuleDet();
							 
							ruleEngForm.reset();
							this.query = Object.assign({}, this.queryInitVal);
						    this.btnSubmission = true;
						    this.showCRRule = false;
							
							this.toastr.success(ruleres.message);
						}else{
							this.toastr.error("Error in Creation...");
						}
					});
				}else{
					this.toastr.error("Error in Creation...");
				}
			 });
			 
		}
  }
  
  convertJsonQuery1() { 
  /* console.log('this.myForm modelid');
  console.log(this.myForm.value); */
	this.loading = true;
	this.myForm.value.PID =this.model.projectName;
	this.myForm.value.AID =this.model.accountName;  
	
	this.ruleengineService.saveAgeRulesManage(this.myForm.value,this.formJsonEdit_id)
        .subscribe(res => {
			
			if(res.success == true){
				//console.log(res);
				//console.log(this.fieldListArr);
				//if(res.data.formVal.ageDep == 'Y') {
					let ageDependentFieldName = res.data.formVal.formFields; //"Dependent On" field value (postAppliedFor)
					let ageRelaxtionFieldName = res.data.formVal.relaxFields; //"Relaxation On" field value (category)
					let ageDependentFieldValue = [];
					let ageRelaxtionFieldValue = [];
					let minDate = [];
					let maxDate = [];
					let minAge = [];
					let maxAge = [];
					let maxAgeRelLimit = [];
					let ageRelaxation = [];
					let asOnAge = [];
					
					if(res.data.formVal.ageDep == 'Y') {
						// "Dependent On" field value (postAppliedFor) loop
						for (let optionObj of this.fieldListArr[ageDependentFieldName]['options']) { 
							ageDependentFieldValue.push(optionObj.value);
						}
					}
					
					// "Relaxation On" field value (category) loop
					for (let optionObj of this.fieldListArr[ageRelaxtionFieldName]['options']) { 
						ageRelaxtionFieldValue.push(optionObj.value);
					}
					/* console.log(Object.keys(res.genFormJSON).length);
					console.log(ageDependentFieldValue);
					console.log(ageRelaxtionFieldValue); */
					
					//age config loop count
					let configCount = Object.keys(res.genFormJSON).length;
					let fieldLevelRelaxation = [];
					for(var c=1; c<=configCount; c++) {
						let ageConfigMap = res.data.genRelaxAgeJSON[c].ageConfig;
						let ageConfigVal = res.genFormJSON[ageConfigMap];
						
						let fieldName = 'ageDependentFields'+ (c - 1);
						let relFieldName = 'rel'+ c ;
						
						if(res.data.formVal.hasOwnProperty(fieldName) && res.data.formVal.hasOwnProperty(relFieldName)) {
							let ageConfigfieldVal = res.data.formVal[fieldName]; //ageDependentFields0
						
							if(res.data.formVal.ageDep == 'Y'){
								minDate.push({"==":[{"var":"data."+ageDependentFieldName},ageConfigfieldVal]});
								minDate.push(ageConfigVal['ageMinDate']);
							
							
								maxDate.push({"==":[{"var":"data."+ageDependentFieldName},ageConfigfieldVal]});
								maxDate.push(ageConfigVal['ageMaxDate']);
							
						
								minAge.push({"==":[{"var":"data."+ageDependentFieldName},ageConfigfieldVal]});
								minAge.push(ageConfigVal['ageMin']);
							
					
								maxAge.push({"==":[{"var":"data."+ageDependentFieldName},ageConfigfieldVal]});
								maxAge.push(ageConfigVal['ageMax']);
							
						
								maxAgeRelLimit.push({"==":[{"var":"data."+ageDependentFieldName},ageConfigfieldVal]});
								maxAgeRelLimit.push(parseInt(ageConfigVal['ageRel'])*12);
							
							
								asOnAge.push({"==":[{"var":"data."+ageDependentFieldName},ageConfigfieldVal]});
								asOnAge.push(ageConfigVal['ageAsonDate']);
							}else{
								var minDateVal = ageConfigVal['ageMinDate'];
								var maxDateVal = ageConfigVal['ageMaxDate'];
								var minAgeVal = ageConfigVal['ageMin'];
								var maxAgeVal = ageConfigVal['ageMax'];
								var maxAgeRelLimitVal = parseInt(ageConfigVal['ageRel'])*12;
								var asOnAgeVal = ageConfigVal['ageAsonDate'];
							}
							
							let relFieldsCount =res.data.formVal[relFieldName].length;
							for(let relObj of res.data.formVal[relFieldName]) {
								let basicRelaxation = [];
								
								for(let relVal of ageRelaxtionFieldValue) {
									let basicCond = [];
									let cValue: number = 0;
									if(res.data.formVal.ageDep == 'Y')
										basicCond.push({"==":[{"var":"data."+ageDependentFieldName},ageConfigfieldVal]});
									basicCond.push({"==":[{"var":"data."+ageRelaxtionFieldName},relVal]}); 
									cValue = parseInt(relObj[relVal])*12;
									let relaxationField = relObj['relaxFormField'];
									var addService = 0;
									if((relObj['relaxFormField'] != ageRelaxtionFieldName) && relObj['relaxFormField']!='') {
										basicCond.push({"==":[{"var":"data."+relaxationField},"yes"]});
									}
									if(relObj['relaxFormField_sec']!='' && relObj['relaxFormField_third']!='') {
										basicCond.push({"==":[{"var":"data."+relObj['relaxFormField_sec']},relObj['relaxFormField_third']]}); 
									}/* else if(relObj['relaxFormField_sec']!=''){
										addService = 1;
									}  */
									
									if(relObj['relaxFormFieldAvail']!='') {
									    addService = 1; //basicCond.push({"==":[{"var":"data."+relObj['relaxFormFieldAvail']},relObj['relaxFormFieldAvail_sec']]}); 
									}
									
									basicRelaxation.push({"and" :basicCond});
									if(addService == 0)	basicRelaxation.push(cValue);
									if(addService == 1){ //For Period of service
										basicRelaxation.push(
											{"+":[{"var":"data."+relObj['relaxFormFieldAvail']},cValue]}
										);
                                    }
								}
								basicRelaxation.push("0");
								fieldLevelRelaxation.push({"if" :basicRelaxation});
							}
						}
					}
					let ageLimitFn = [];
					let ageLimit = [];
					let ageLimitCondition = '';
					let ageLimitConditionOR = '';
					let ageLimitConditionIF = [];
					
					if(res.data.formVal.ageDep == 'Y'){
						ageLimitFn.push({"if" :minDate});
						ageLimitFn.push({"if" :maxDate});
						ageLimitFn.push({"if" :minAge});
						ageLimitFn.push({"if" :maxAge});
						ageLimitFn.push({"if" :maxAgeRelLimit}); 
					}else{
						ageLimitFn.push(minDateVal);
						ageLimitFn.push(maxDateVal);
						ageLimitFn.push(minAgeVal);
						ageLimitFn.push(maxAgeVal);
						ageLimitFn.push(maxAgeRelLimitVal);
					}
					
					ageLimitFn.push({"max":fieldLevelRelaxation});
					ageLimitFn.push({"var": "data.dob"});
					let orArray = [];
					orArray.push({"ageLimit":ageLimitFn});
					let ifArray = [];
					let jsonConvertedValueAge = [];
					let jsonConvertedValueAgeCalc = [];
					ifArray.push({"or":orArray});
					ifArray.push(true);
					ifArray.push('invalid age');
					ageLimitConditionIF.push({"if":ifArray});
					
					jsonConvertedValueAge = ageLimitConditionIF.map(function(e){
						return JSON.stringify(e);
					}); 
					var dataString = jsonConvertedValueAge.join(","); 
					this.jsonConvertedStringAge = dataString;
					
					var obj = JSON.parse(JSON.stringify(this.QueryBuilderConfigOrigArr)); 
				
					var inputSelectInsertArr = res.data.formVal.dobVal.split('-');
					var indexPageVal = inputSelectInsertArr[0]; // page1
					var compIndexPageVal = inputSelectInsertArr[1]; //firtsName
					//console.log(this.jsonConvertedStringAge);
					obj = this.jsonAppendComponent(obj,indexPageVal,compIndexPageVal,'ageFn');
					
					let ageCalFn = [];
					if(res.data.formVal.ageDep == 'Y')
						ageCalFn.push({"if" :asOnAge});
					else 
						ageCalFn.push(asOnAgeVal);
					ageCalFn.push({"var": "data.dob"});
					let ageCal = [];
					ageCal.push({"ageCalculation": ageCalFn});
					jsonConvertedValueAgeCalc = ageCal.map(function(e){
						return JSON.stringify(e);
					}); 
					var dataString1 = jsonConvertedValueAgeCalc.join(","); 
					this.jsonConvertedStringAgeClc = dataString1;
										
					var inputSelectInsertArr1 = res.data.formVal.ageVal.split('-');
					var indexPageVal1 = inputSelectInsertArr1[0]; // page1
					var compIndexPageVal1 = inputSelectInsertArr1[1]; //firtsName
					obj = this.jsonAppendComponent_Fee(obj,indexPageVal1,compIndexPageVal1,'ageFn');
					
					this.QueryBuilderConfigOrigArr = (obj);
					var Jsonapplncomp: Object = {
						components: this.QueryBuilderConfigOrigArr,
						display: 'wizard'
					};
					var ruleEngWork;
					 
					ruleEngWork = {'accountName':this.model.accountName,'projectName':this.model.projectName};
					 
					this.applicationService.appSubmit(ruleEngWork,Jsonapplncomp).subscribe(res => {
						this.loading = false;
						if(res.success == true){
							//this.resetAgeEng();
							//alert(aletMsg);
							this.toastr.success("Age config created Successfully...");
						}else{
							this.toastr.error("Error in Creation...");
						}
					});
				//}
				
				this.formJsonEdit_id=res.data._id;
				this.getRuleDet();
			}
	});
	
  }
  
  DelRuleField(fieldName:String,ruleID:String,typeStr:String){
	  if(confirm("Are you sure want to delete this rule?")){
		    var obj = JSON.parse(JSON.stringify(this.QueryBuilderConfigOrigArr));
			var inputSelectInsertArr = fieldName.split('-');
		    var indexPageVal = inputSelectInsertArr[0]; // page1
		    var compIndexPageVal = inputSelectInsertArr[1]; //firtsName
			//console.log(typeStr);
			if(typeStr == 'Eligibility')
				var obj = this.jsonAppendComponent(obj,indexPageVal,compIndexPageVal,'delete');
			else if(typeStr == 'Fee')
				var obj = this.jsonAppendComponent_Fee(obj,indexPageVal,compIndexPageVal,'delete');
			else if(typeStr == 'Conditional')
				var obj = this.jsonAppendComponent_cnd(obj,indexPageVal,compIndexPageVal,'delete');
			//console.log(obj);
			//console.log("ommm");
			this.ruleengineService.deleteRule(fieldName,this.model.accountName,this.model.projectName,obj,ruleID,typeStr).subscribe(res => {
				if(res.success == true){
					this.getRuleDet();
					this.showCRRule=false;
				}
			});
	  }
  }
  
  EditRuleField(ruleID:String){
	  
	  this.ruleengineService.getRulesById(ruleID).subscribe(res => {
			if(res.success == true){
				this.query = res['data'][0]['query'];
				this.inputSelectInsert = res['data'][0]['appendField'];
				this.alertmsgstr = res['data'][0]['alertmsgstr'];
				this.showCRRule = true;
				this.showEditRule = true;
				this.ruleFor = res['data'][0]['ruleFor'];
				let rulecount = res['data'][0]['query']['rules'].length;
				
				/* this.feeCond1 = res['data'][0]['feeCond1'];
				this.feeVal1 = res['data'][0]['feeVal1'];
				this.feeCond2 = res['data'][0]['feeCond2'];
				this.feeVal2 = res['data'][0]['feeVal2']; */
				 for(var i = 1; i <= rulecount; i++){
					this.feeCond["feeCond"+ i] = res['data'][0]['feeCond'+i];
					this.feeCond["feeVal"+ i] = res['data'][0]['feeVal'+i];
					// eval("feeCond" + i + " =res['data'][0]['query']['feeCond"+i+"']");
					// eval("feeVal" + i + " =res['data'][0]['query']['feeVal"+i+"']");
					/* window["feeCond"+i] = res['data'][0]['query']['feeCond'+i];
					window["feeVal"+i] = res['data'][0]['query']['feeVal'+i];
					console.log(window.feeCond1); */
				}
				//console.log(this.feeCond);
			}
		});
	  /*For Edit Rule Engine*/
		/* this.query = {
		  "condition": "or",
		  "rules": [
			{
			  "field": "firstName",
			  "operator": "=",
			  "value": "asas"
			}
		  ]
		}; */
		
  }
  
  jsonAppendComponent(obj,indexPageVal:String,compIndexPageVal:String,updateStr:String){
	  var pageIndex  = '';
		var compIndex  = "";
		var dataString = this.jsonConvertedString;
		var columnIndex = '';
		var columnSIndex = '';
		var rowsIndex = '';
		var rowsSIndex = '';
		var rowsSSIndex = '';
		var tabIndex = '';
		var tabSIndex = '';
		var tabSSIndex = '';
		var panelIndex = '';
		var panelSIndex = '';
		var rowsSRRIndex = '';
		var columnSRIndex = '';
		
		if(updateStr == 'delete') dataString = "";
		else if(updateStr == 'ageFn') dataString = this.jsonConvertedStringAge;
		//console.log(indexPageVal);
		//console.log(obj);
		 obj.filter(function (element, index) {
		  if(element.key === indexPageVal) pageIndex = index;
		 // return res = (element.key === "page1");
		});
		//console.log(compIndexPageVal);
		obj[pageIndex]['components'].filter(function (element, index) {
		  if(element.key === compIndexPageVal) compIndex = index;
		  //return res= (element.key === "firstName");
		});
		
		if(compIndex=='' && parseInt(compIndex)!=0){ //COLUMN Layout 
			obj[pageIndex]['components'].filter(function (element, index) {
				if(element.type == 'columns'){
					if(index!='' || parseInt(index)>=0){
						if(obj[pageIndex]['components'][index]['columns']){
							obj[pageIndex]['components'][index]['columns'].filter(function (element, indexC) {
								element['components'].filter(function (element, indexRRR) {
									if(element['key'] == compIndexPageVal){
										columnIndex = index;
										columnSIndex = indexC;
										columnSRIndex = indexRRR;
									}
								});
							});
						}
					}
				}else if(element.type == 'table'){ //TABLE LAYOUT
					
					if(index!='' || parseInt(index)>=0){
						if(obj[pageIndex]['components'][index]['rows']){
							obj[pageIndex]['components'][index]['rows'].filter(function (element, indexR) {
								if(obj[pageIndex]['components'][index]['rows'][indexR]){
									obj[pageIndex]['components'][index]['rows'][indexR].filter(function (element, indexRR) {
										element['components'].filter(function (element, indexRRR) {
											//console.log(element);
											if(element['key'] == compIndexPageVal){
												rowsSIndex = indexRRR;
												rowsIndex = index;
												rowsSSIndex = indexR;
												rowsSRRIndex = indexRR;
											}
										});
									});
								}
							});
						}
					}
				}else if(element.type == 'tabs'){ //tab LAYOUT
					if(index!='' || parseInt(index)>=0){
						//console.log(obj[pageIndex]['components'][index]['components']);
						if(obj[pageIndex]['components'][index]['components']){
							obj[pageIndex]['components'][index]['components'].filter(function (element, indexT) {
								if(element['components']){
									element['components'].filter(function (element, indexTT) {
										//console.log(element['key']);
										if(element['key'] == compIndexPageVal){
											tabSSIndex = indexTT;
											tabSIndex = indexT;
											tabIndex = index;
										}
									});
								}
							});
						}
					}
				}else if(element.type == 'panel' || element.type == 'fieldset'){ //Panel Layout & Fieldset Layout
					if(index!='' || parseInt(index)>=0){
						if(obj[pageIndex]['components'][index]['components']){
							obj[pageIndex]['components'][index]['components'].filter(function (element, indexT) {
								//console.log(element['key']);
								if(element['key'] == compIndexPageVal){
									panelSIndex = indexT;
									panelIndex = index;
								}
							});
						}
					}
				}
				//if(element.key === compIndexPageVal) compIndex = index;
				//return res= (element.key === "firstName");
			});
		}
		
		var dataStringJson = dataString;
	    if(dataString!='') dataStringJson = JSON.parse(dataString);
				 
		  if(columnSRIndex!='' || parseInt(columnSRIndex)>=0){//COLUMN Layout
			  if(obj[pageIndex]['components'][columnIndex]['columns'][columnSIndex]['components'][columnSRIndex]['validate']){
				  var ValidateArr = new Array();
				  ValidateArr = obj[pageIndex]['components'][columnIndex]['columns'][columnSIndex]['components'][columnSRIndex]['validate'];
				  if(dataString!='') ValidateArr['json'] = JSON.parse(dataString);
				  else ValidateArr['json'] = dataString;
				  obj[pageIndex]['components'][columnIndex]['columns'][columnSIndex]['components'][columnSRIndex]['validate'] =  ValidateArr;
			  }else{
				 obj[pageIndex]['components'][columnIndex]['columns'][columnSIndex]['components'][columnSRIndex]['validate'] =  {'json':dataStringJson};
			  } 
		  }else if(rowsSIndex!='' || parseInt(rowsSIndex)>=0){//TABLE Layout;  
			  if(obj[pageIndex]['components'][rowsIndex]['rows'][rowsSSIndex][rowsSRRIndex]['components'][rowsSIndex]['validate']){
				  var ValidateArr = new Array();
				  ValidateArr = obj[pageIndex]['components'][rowsIndex]['rows'][rowsSSIndex][rowsSRRIndex]['components'][rowsSIndex]['validate'];
				  if(dataString!='') ValidateArr['json'] = JSON.parse(dataString);
				  else ValidateArr['json'] = dataString;
				  
				  obj[pageIndex]['components'][rowsIndex]['rows'][rowsSSIndex][rowsSRRIndex]['components'][rowsSIndex]['validate'] =  ValidateArr;
			  }else{
				obj[pageIndex]['components'][rowsIndex]['rows'][rowsSSIndex][rowsSRRIndex]['components'][rowsSIndex]['validate'] =  {'json':dataStringJson};
			  } 
		  }else if(tabSIndex!='' || parseInt(tabSIndex)>=0){ //TAB LAYOUT
			   //console.log(obj[pageIndex]['components'][tabIndex]['components'][tabSIndex]['components'][tabSSIndex]);
			   if(obj[pageIndex]['components'][tabIndex]['components'][tabSIndex]['components'][tabSSIndex]['validate']){
				  var ValidateArr = new Array();
				  ValidateArr = obj[pageIndex]['components'][tabIndex]['components'][tabSIndex]['components'][tabSSIndex]['validate'];
				  if(dataString!='') ValidateArr['json'] = JSON.parse(dataString);
				  else ValidateArr['json'] = dataString;
				  obj[pageIndex]['components'][tabIndex]['components'][tabSIndex]['components'][tabSSIndex]['validate'] =  ValidateArr;
			  }else{
				obj[pageIndex]['components'][tabIndex]['components'][tabSIndex]['components'][tabSSIndex]['validate'] =  {'json':dataStringJson};
			  } 
		  }else if(panelSIndex!='' || parseInt(panelSIndex)>=0){ //Panel Layout & Fieldset Layout
			  if(obj[pageIndex]['components'][panelIndex]['components'][panelSIndex]['validate']){
				  var ValidateArr = new Array();
				  ValidateArr = obj[pageIndex]['components'][panelIndex]['components'][panelSIndex]['validate'];
				  if(dataString!='') ValidateArr['json'] = JSON.parse(dataString);
				  else ValidateArr['json'] = dataString;
				  obj[pageIndex]['components'][panelIndex]['components'][panelSIndex]['validate'] =  ValidateArr;
			  }else{
				obj[pageIndex]['components'][panelIndex]['components'][panelSIndex]['validate'] =  {'json':dataStringJson};
			  } 
		  }else{
			  if(obj[pageIndex]['components'][compIndex]['validate']){
				  var ValidateArr = new Array();
				  ValidateArr = obj[pageIndex]['components'][compIndex]['validate'];
				  if(dataString!='') ValidateArr['json'] = JSON.parse(dataString);
				  else ValidateArr['json'] = dataString;
				  obj[pageIndex]['components'][compIndex]['validate'] =  ValidateArr;
			  }else{
				obj[pageIndex]['components'][compIndex]['validate'] =  {'json':dataStringJson};
			  } 
		  } 
	  
	  return obj;
  }
  
  jsonAppendComponent_Fee(obj,indexPageVal:String,compIndexPageVal:String,updateStr:String){
		var pageIndex  = '';
		
		var compIndex  = '';
		var pageIndex  = '';
		var compIndex  = "";
		var dataString = this.jsonConvertedString;
		var columnIndex = '';
		var columnSIndex = '';
		var rowsIndex = '';
		var rowsSIndex = '';
		var rowsSSIndex = '';
		var tabIndex = '';
		var tabSIndex = '';
		var tabSSIndex = '';
		var panelIndex = '';
		var panelSIndex = '';
		var columnSRIndex = '';
		var rowsSRRIndex = '';
		
		if(updateStr == 'delete') dataString = "";
		else if(updateStr == 'updateWorkExp') dataString = this.jsonConvertedStrWorkExp;
		else if(updateStr == 'ageFn') dataString = this.jsonConvertedStringAgeClc;
		
		var dataStringJson = dataString;
	    if(dataString!='') dataStringJson = JSON.parse(dataString);
		
	    obj.filter(function (element, index) {
		  if(element.key === indexPageVal) pageIndex = index;
		 // return res = (element.key === "page1");
		});
		obj[pageIndex]['components'].filter(function (element, index) {
		  if(element.key === compIndexPageVal) compIndex = index;
		  //return res= (element.key === "firstName");
		})
		
		
		
		if(compIndex=='' && parseInt(compIndex)!=0){ //COLUMN Layout 
			obj[pageIndex]['components'].filter(function (element, index) {
				if(element.type == 'columns'){
					if(index!='' || parseInt(index)>=0){
						if(obj[pageIndex]['components'][index]['columns']){
							obj[pageIndex]['components'][index]['columns'].filter(function (element, indexC) {
								element['components'].filter(function (element, indexRRR) {
									if(element['key'] == compIndexPageVal){
										columnIndex = index;
										columnSIndex = indexC;
										columnSRIndex = indexRRR;
									}
								});
							});
						}
					}
				}else if(element.type == 'table'){ //TABLE LAYOUT
					
					if(index!='' || parseInt(index)>=0){
						if(obj[pageIndex]['components'][index]['rows']){
							obj[pageIndex]['components'][index]['rows'].filter(function (element, indexR) {
								if(obj[pageIndex]['components'][index]['rows'][indexR]){
									obj[pageIndex]['components'][index]['rows'][indexR].filter(function (element, indexRR) {
										element['components'].filter(function (element, indexRRR) {
											//console.log(element);
											if(element['key'] == compIndexPageVal){
												rowsSIndex = indexRRR;
												rowsIndex = index;
												rowsSSIndex = indexR;
												rowsSRRIndex = indexRR;
											}
										});
									});
								}
							});
						}
					}
				}else if(element.type == 'tabs'){ //tab LAYOUT
					if(index!='' || parseInt(index)>=0){
						//console.log(obj[pageIndex]['components'][index]['components']);
						if(obj[pageIndex]['components'][index]['components']){
							obj[pageIndex]['components'][index]['components'].filter(function (element, indexT) {
								if(element['components']){
									element['components'].filter(function (element, indexTT) {
										//console.log(element['key']);
										if(element['key'] == compIndexPageVal){
											tabSSIndex = indexTT;
											tabSIndex = indexT;
											tabIndex = index;
										}
									});
								}
							});
						}
					}
				}else if(element.type == 'panel' || element.type == 'fieldset'){ //Panel Layout & Fieldset Layout
					if(index!='' || parseInt(index)>=0){
						if(obj[pageIndex]['components'][index]['components']){
							obj[pageIndex]['components'][index]['components'].filter(function (element, indexT) {
								//console.log(element['key']);
								if(element['key'] == compIndexPageVal){
									panelSIndex = indexT;
									panelIndex = index;
								}
							});
						}
					}
				}
				//if(element.key === compIndexPageVal) compIndex = index;
				//return res= (element.key === "firstName");
			});
		}
		
	  if(columnSIndex!='' || parseInt(columnSIndex)>=0){//COLUMN Layout 
		  obj[pageIndex]['components'][columnIndex]['columns'][columnSIndex]['components'][columnSRIndex]['calculateValue'] =  dataStringJson;
	  }else if(rowsSIndex!='' || parseInt(rowsSIndex)>=0){//TABLE Layout;  
		  obj[pageIndex]['components'][rowsIndex]['rows'][rowsSSIndex][rowsSRRIndex]['components'][rowsSIndex]['calculateValue'] =  dataStringJson;
	  }else if(tabSIndex!='' || parseInt(tabSIndex)>=0){ //TAB LAYOUT
		  obj[pageIndex]['components'][tabIndex]['components'][tabSIndex]['components'][tabSSIndex]['calculateValue']  =  dataStringJson;
	  }else if(panelSIndex!='' || parseInt(panelSIndex)>=0){ //Panel Layout & Fieldset Layout
		  obj[pageIndex]['components'][panelIndex]['components'][panelSIndex]['calculateValue'] =  dataStringJson;
	  }else{
		  obj[pageIndex]['components'][compIndex]['calculateValue'] =  dataStringJson;
	  } 
	  return obj;
  }
  
  jsonAppendComponent_cnd(obj,indexPageVal:String,compIndexPageVal:String,updateStr:String){
		var pageIndex  = '';
		
		var compIndex  = '';
		var pageIndex  = '';
		var compIndex  = "";
		var dataString = this.jsonConvertedString;
		var columnIndex = '';
		var columnSIndex = '';
		var rowsIndex = '';
		var rowsSIndex = '';
		var rowsSSIndex = '';
		var tabIndex = '';
		var tabSIndex = '';
		var tabSSIndex = '';
		var panelIndex = '';
		var panelSIndex = '';
		var columnSRIndex = '';
		var rowsSRRIndex = '';
		
		if(updateStr == 'delete') dataString = "";
		//else if(updateStr == 'update') dataString = this.jsonConvertedStrWorkExp;
		//else if(updateStr == 'ageFn') dataString = this.jsonConvertedStringAgeClc;
		
		var dataStringJson = dataString;
	    if(dataString!='') dataStringJson = JSON.parse(dataString);
		
	    obj.filter(function (element, index) {
		  if(element.key === indexPageVal) pageIndex = index;
		 // return res = (element.key === "page1");
		});
		obj[pageIndex]['components'].filter(function (element, index) {
		  if(element.key === compIndexPageVal) compIndex = index;
		  //return res= (element.key === "firstName");
		})
		
		
		
		if(compIndex=='' && parseInt(compIndex)!=0){ //COLUMN Layout 
			obj[pageIndex]['components'].filter(function (element, index) {
				if(element.type == 'columns'){
					if(index!='' || parseInt(index)>=0){
						if(obj[pageIndex]['components'][index]['columns']){
							obj[pageIndex]['components'][index]['columns'].filter(function (element, indexC) {
								element['components'].filter(function (element, indexRRR) {
									if(element['key'] == compIndexPageVal){
										columnIndex = index;
										columnSIndex = indexC;
										columnSRIndex = indexRRR;
									}
								});
							});
						}
					}
				}else if(element.type == 'table'){ //TABLE LAYOUT
					
					if(index!='' || parseInt(index)>=0){
						if(obj[pageIndex]['components'][index]['rows']){
							obj[pageIndex]['components'][index]['rows'].filter(function (element, indexR) {
								if(obj[pageIndex]['components'][index]['rows'][indexR]){
									obj[pageIndex]['components'][index]['rows'][indexR].filter(function (element, indexRR) {
										element['components'].filter(function (element, indexRRR) {
											//console.log(element);
											if(element['key'] == compIndexPageVal){
												rowsSIndex = indexRRR;
												rowsIndex = index;
												rowsSSIndex = indexR;
												rowsSRRIndex = indexRR;
											}
										});
									});
								}
							});
						}
					}
				}else if(element.type == 'tabs'){ //tab LAYOUT
					if(index!='' || parseInt(index)>=0){
						//console.log(obj[pageIndex]['components'][index]['components']);
						if(obj[pageIndex]['components'][index]['components']){
							obj[pageIndex]['components'][index]['components'].filter(function (element, indexT) {
								if(element['components']){
									element['components'].filter(function (element, indexTT) {
										//console.log(element['key']);
										if(element['key'] == compIndexPageVal){
											tabSSIndex = indexTT;
											tabSIndex = indexT;
											tabIndex = index;
										}
									});
								}
							});
						}
					}
				}else if(element.type == 'panel' || element.type == 'fieldset'){ //Panel Layout & Fieldset Layout
					if(index!='' || parseInt(index)>=0){
						if(obj[pageIndex]['components'][index]['components']){
							obj[pageIndex]['components'][index]['components'].filter(function (element, indexT) {
								//console.log(element['key']);
								if(element['key'] == compIndexPageVal){
									panelSIndex = indexT;
									panelIndex = index;
								}
							});
						}
					}
				}
				//if(element.key === compIndexPageVal) compIndex = index;
				//return res= (element.key === "firstName");
			});
		}
		
	  if(columnSIndex!='' || parseInt(columnSIndex)>=0){//COLUMN Layout 
		  obj[pageIndex]['components'][columnIndex]['columns'][columnSIndex]['components'][columnSRIndex]['conditional']['json'] =  dataStringJson;
	  }else if(rowsSIndex!='' || parseInt(rowsSIndex)>=0){//TABLE Layout;  
		  obj[pageIndex]['components'][rowsIndex]['rows'][rowsSSIndex][rowsSRRIndex]['components'][rowsSIndex]['conditional']['json'] =  dataStringJson;
	  }else if(tabSIndex!='' || parseInt(tabSIndex)>=0){ //TAB LAYOUT
		  obj[pageIndex]['components'][tabIndex]['components'][tabSIndex]['components'][tabSSIndex]['conditional']['json']  =  dataStringJson;
	  }else if(panelSIndex!='' || parseInt(panelSIndex)>=0){ //Panel Layout & Fieldset Layout
		  obj[pageIndex]['components'][panelIndex]['components'][panelSIndex]['conditional']['json'] =  dataStringJson;
	  }else{
		  obj[pageIndex]['components'][compIndex]['conditional']['json'] =  dataStringJson;
	  } 
	  return obj;
  }
  
  jsonpreviewView(jsonLogicDisp){
	  this.displayPrevJson = true;
	  this.displayPrevJsonVal = jsonLogicDisp;
  }
  
  resetRuleEng(){
	  this.query = Object.assign({}, this.queryInitVal);
	  this.inputSelectInsert = "";
	  this.alertmsgstr = "";
	  this.showCRRule = true;
	  this.showAge = false;
	  this.showEditRule = false;
	  this.showWorkexpRuleManagement = true;
	  this.showWorkexpRule = false;
	  this.showRuleng = true;
	  this.showDependent = false;
  }
  
  resetDependentFld(){
		this.showAge = false;
		this.showCRRule = false;
		this.showWorkexpRule = false;
		this.showWorkexpRuleManagement = true;
		this.showRuleng = false;
		this.showDependent = true;
  }
  // work exp start
  resetWorkexpEng(){
	  this.query = Object.assign({}, this.queryInitVal);
	  this.inputSelectInsert = "";
	  this.alertmsgstr = "";
	  this.showWorkexpRule = true;
	  this.showWorkexpRuleManagement = false;
	  this.showAge = false;
	  this.showCRRule = false;
	  this.showRuleng = false;
	  this.showDependent = false;
	   this.Workexpservice.workexpConfigEdit(this.model.projectName,this.model.accountName)
        .subscribe(res => {
			  this.loading = false;
			  if(res['success'] == true){
				  
					this.myFormworkexp = this._fb.group({
						totexp:[''],
						workexp: this._fb.array([
							//this.initwork(),
						])
					});
					
					if(res['data'] && res['data']!=''){
						
						this.worExpData = res['data'];
						//this.model = res['data'];
						
						/* this.myFormworkexp = this._fb.group({
							totexp:[res['data'].totexp]
						}); */
						this.myFormworkexp = this._fb.group({
							totexp:[res['data']['totexp']],
							workexp: this._fb.array([
								//this.initwork(),
							])
						});
						for (let i = 0; i <res['data'].workExpArrayCount; i++) {
							this.AddWorkexpcol(res['data'].formJSON[i]);
						} 
					}else{
						this.AddWorkexpcol('');
					}
			  }
	   }); 
		 
  }		 
  
	initwork(workDt) {  
		return this._fb.group({
		 
			fromdate: [workDt.fromdate],
			todate: [workDt.todate],
			CalcAppendField: [workDt.CalcAppendField]
			 
		});
	}
	
	AddWorkexpcol(workDt) {
		const control = <FormArray>this.myFormworkexp.controls['workexp'];
		control.push(this.initwork(workDt));
	}
	  removeSection_workexp(i: number) {  //console.log('ggggg');
		const control = <FormArray>this.myFormworkexp.controls['workexp'];
		control.removeAt(i);
	} 
	
   
	  onSubmit() {  
		   //console.log('----------testingnnn start-------------');
		 this.loading = true;
		  this.Workexpservice.workexpConfigStore(this.myFormworkexp.value,this.model.projectName,this.model.accountName,this.worExpData['_id'])
			.subscribe(res => {
				  
				if(res['success'] == true) {
					var aletMsg = "Work Exp Calculation settings has been added successfully..."; 
					 
					if(this.worExpData['_id'] && this.worExpData['_id']!=''){
						aletMsg = "Work Exp Calculation settings has been updated successfully..."; 
					}
					var obj = JSON.parse(JSON.stringify(this.QueryBuilderConfigOrigArr)); 
					
					let JsonWorkExp = this.worExpData['formJSON'];
					 
					for (let keyWork in JsonWorkExp) {
						 
						var valueW = JsonWorkExp[keyWork];
						 
						var inputSelectInsertArr = valueW["CalcAppendField"].split('-');
						 
						var indexPageVal = inputSelectInsertArr[0]; // page1
						var compIndexPageVal = inputSelectInsertArr[1]; //firtsName
						
						obj = this.jsonAppendComponent_Fee(obj,indexPageVal,compIndexPageVal,'delete');
					 
					}
					//console.log("out");
					let JsonWorkExpForm = this.myFormworkexp.value.workexp;
					var RulePushArrWorkTot = [];
					var RulePushArrWorkTotStr = '';
					RulePushArrWorkTot = [];
					var counter = 0;
					for (let keyWorkFrm in JsonWorkExpForm) {
						var RulePushArrWork = [];
						var jsonConvertedValue = new Array();
						var valueW = JsonWorkExpForm[keyWorkFrm];
						var inputSelectInsertArr = valueW["CalcAppendField"].split('-');
						var fromdateArr = valueW["fromdate"].split('-');
						var todateArr = valueW["todate"].split('-');
						var indexPageVal = inputSelectInsertArr[0]; // page1
						var compIndexPageVal = inputSelectInsertArr[1]; //firtsName
						RulePushArrWork.push({["date_calc_diff_year"]: [{"var": "data."+fromdateArr[1]},{"var": "data."+todateArr[1]}]});
						jsonConvertedValue = RulePushArrWork.map(function(e){
							return JSON.stringify(e);
						}); 
						//console.log('----------jsonConvertedValue value------------');
						 //console.log(jsonConvertedValue);
						var dataString = jsonConvertedValue.join(","); 
						this.jsonConvertedStrWorkExp = dataString;
						//console.log(indexPageVal);
						//console.log(compIndexPageVal);
						 //console.log('----------jsonConvertedStrWorkExp value------------');
						 //console.log(this.jsonConvertedStrWorkExp);
						
						obj = this.jsonAppendComponent_Fee(obj,indexPageVal,compIndexPageVal,'updateWorkExp');
						 
						/* RulePushArrWorkTotStr = '{"var":\"data.'+fromdateArr[1]+'\"},{"var":\"data.'+todateArr[1]+'\"}';
						RulePushArrWorkTot.push(RulePushArrWorkTotStr); */
						RulePushArrWorkTot.push([{"var": "data."+fromdateArr[1]},{"var": "data."+todateArr[1]}]);
						//console.log('----------obj value------------');
						 //console.log(obj);
						counter++;
					}
						
					//Total Experience
					var RulePushArrWorkTotP = new Array();
					var jsonConvertedValueTot = new Array();
					
					
					//console.log(RulePushArrWorkTot);
					var dataStringTotV = [];
					dataStringTotV.push({"date_calc_diff_totalmonth": RulePushArrWorkTot});
					
					
					//console.log(dataStringTotV);
					jsonConvertedValueTot = dataStringTotV.map(function(e){
							return JSON.stringify(e);
					}); 
					var dataString = jsonConvertedValueTot.join(","); 
					//console.log(dataString);
					this.jsonConvertedStrWorkExp = dataString;
						
					//this.jsonConvertedStrWorkExp = dataStringTotV;
					let Jsontotexp = this.worExpData['totexp'];
					let totexp = this.myFormworkexp.value.totexp;
					
					if(Jsontotexp!=totexp){
						var inputSelectInsertArrTotJ = Jsontotexp.split('-');
						var indexPageValTotJ = inputSelectInsertArrTotJ[0]; // page1
						var compIndexPageValTotJ = inputSelectInsertArrTotJ[1]; //firtsName
						obj = this.jsonAppendComponent_Fee(obj,indexPageValTotJ,compIndexPageValTotJ,'delete');
					}
				
					var inputSelectInsertArrTot = totexp.split('-');
					var indexPageValTot = inputSelectInsertArrTot[0]; // page1
					var compIndexPageValTot = inputSelectInsertArrTot[1]; //firtsName
					obj = this.jsonAppendComponent_Fee(obj,indexPageValTot,compIndexPageValTot,'updateWorkExp');
					//console.log(obj);
					
					 this.QueryBuilderConfigOrigArr = (obj);
					 var Jsonapplncomp: Object = {
						components: this.QueryBuilderConfigOrigArr,
						display: 'wizard'
					 };
					 var ruleEngWork;
					 
					 ruleEngWork = {'accountName':this.model.accountName,'projectName':this.model.projectName};
					 
					 this.applicationService.appSubmit(ruleEngWork,Jsonapplncomp).subscribe(res => {
						if(res.success == true){
							this.resetWorkexpEng();
							//alert(aletMsg);
							this.toastr.success(aletMsg);
						}else{
							this.toastr.error("Error in Creation...");
						}
					 });
				}
			}); 
	  }
  
	  //work exp end
	  resetAgeEng(){
		  //this.query = Object.assign({}, this.queryInitVal);
		  //this.inputSelectInsert = "";
		  //this.alertmsgstr = "";
		  this.showAge = true;
		  this.showCRRule = false;
		  this.myForm = this._fb.group({
					ageDep:new FormControl(''),
					formFields:new FormControl(''),
					relaxFields:new FormControl(''), 
					dobVal:new FormControl(''),
					ageVal:new FormControl(''),
					//ageDependentFields:new FormControl(''),
				});
		  
		  this.getageRelaxationList();
			this.showWorkexpRule = false;
			this.showWorkexpRuleManagement = true;
			this.showRuleng = false;
			this.showDependent = false;
	  }
  
	  getageRelaxationList() {
		this.ruleengineService.getRelaxationList(this.model.accountName,this.model.projectName).subscribe(res => {
			if(res.genFormStatus == "Success")
			{
				let jsonData= JSON.parse(res.genFormJSON); 
				var arrkey= 'rel1';
				let genRelaxAgeJSON = JSON.parse(res.genRelaxAgeJSON);
				//console.log("genRelaxAgeJSON.formVal.arrkey");
				//console.log(genRelaxAgeJSON.formVal);
				//
				
				this.myForm.controls['ageDep'].setValue(genRelaxAgeJSON.formVal.ageDep);
				this.myForm.controls['formFields'].setValue(genRelaxAgeJSON.formVal.formFields);
				this.myForm.controls['relaxFields'].setValue(genRelaxAgeJSON.formVal.relaxFields);
				this.myForm.controls['ageVal'].setValue(genRelaxAgeJSON.formVal.ageVal);
				this.myForm.controls['dobVal'].setValue(genRelaxAgeJSON.formVal.dobVal);
				//this.myForm.controls['ageDependentFields'].setValue(genRelaxAgeJSON.formVal.ageDependentFields);
				
				this.ageConfigMap();
				
				let dataKeys = Object.keys(jsonData); 
				let listData = [];
				let iteration = 0; 
				for (let prop of dataKeys) { 
				//console.log(jsonData[prop]);
					jsonData[prop].subArr=genRelaxAgeJSON.formVal['rel'+(iteration+1)];
					//console.log(genRelaxAgeJSON.formVal['rel'+(iteration+1)]);
					//console.log(jsonData[prop]);
					listData.push(jsonData[prop]);
					this.myForm.addControl('ageDependentFields'+iteration, new FormControl(genRelaxAgeJSON.formVal['ageDependentFields'+iteration]));
					this.relaxationlistcount[iteration] = genRelaxAgeJSON.formVal['rel'+(iteration+1)].length;
					//console.log("genRelaxAgeJSON.formVal['rel'+(iteration+1)].length");
					//console.log(genRelaxAgeJSON.formVal['rel'+(iteration+1)].length);
					let countVal = this.relaxationlistcount[iteration];
					for (let i = 0; i <countVal; i++) {
						//console.log(genRelaxAgeJSON.formVal['rel'+(iteration+1)]);
						this.showRelaxation(iteration, i, genRelaxAgeJSON.formVal.relaxFields,genRelaxAgeJSON.formVal['rel'+(iteration+1)][i]);
					} 
					iteration++;
					
					
				} 
				//console.log(this.relaxationlistcount);
				this.ageRelaxationList = listData;
			}
			else if (res.genFormStatus == "update") {
				let jsonData= JSON.parse(res.genFormJSON); 
				let dataKeys = Object.keys(jsonData); 
				let listData = [];
				let iteration = 0; 
				for (let prop of dataKeys) { 
				//console.log(jsonData[prop]); 
					//console.log(genRelaxAgeJSON.formVal['rel'+(iteration+1)]);
					//console.log(jsonData[prop]);
					listData.push(jsonData[prop]);
					this.myForm.addControl('ageDependentFields'+iteration, new FormControl(''));
					this.relaxationlistcount[iteration] = 0;  
					iteration++; 
					
				} 
				
				this.ageRelaxationList = listData;
				 
			}
		 });
	  }
  
	  showRelaxation(index:number, relcount:number, relaxField:string, editData='') {
		
		/*console.log(index);
		console.log(relcount);
		console.log(relaxField);*/
		let relaxFieldVal1 = [];
		for (let optionObj of this.fieldListArr[relaxField]['options']) { 
			relaxFieldVal1.push(optionObj.name);
		}
		this.relaxFieldVal = relaxFieldVal1;
		//console.log(relaxFieldVal);
		this.generate(index, relcount,this.relaxFieldVal, editData);
		 /*  this.myForm = this._fb.group({
							rel: this._fb.array([
								this.initRel(relaxFieldVal),
							])
							
						});  */
			let relIndex = index+1;
			let relcountIndex = relcount;
			/* console.log(relIndex);
			console.log(relcountIndex); */
			this.getSecondaryOpt(relIndex,relcountIndex);  
			//this.getSecondaryOpt(relIndex,relcountIndex,'Avail');  
	  }
	
	 initRel(relaxFieldVal, editData='') {
		let fldObj = {relaxFormField:[(editData['relaxFormField'])?editData['relaxFormField']:'']};
	    fldObj['relaxFormField_sec'] = [(editData['relaxFormField_sec'])?editData['relaxFormField_sec']:''];
		fldObj['relaxFormField_third'] = [(editData['relaxFormField_third'])?editData['relaxFormField_third']:''];
		fldObj['relaxFormFieldAvail'] = [(editData['relaxFormFieldAvail'])?editData['relaxFormFieldAvail']:''];
		//fldObj['relaxFormFieldAvail_sec'] = [(editData['relaxFormFieldAvail_sec'])?editData['relaxFormFieldAvail_sec']:''];
		for (let fldVal of relaxFieldVal) { 
			fldObj[fldVal] = [editData[fldVal]];
		}
		return this._fb.group(fldObj);
	}
	
	generate(index, relcount,relaxFieldVal, editData = '') {
		// const control = <FormArray>this.myForm.controls['rel'];
		let fldVal = 'rel' + parseInt(index+1);
		if(relcount == 0) {
			this.myForm.addControl(fldVal,this._fb.array([this.initRel(relaxFieldVal, editData)]));
			this.relaxFieldCount[index+1] = [] ;
		} else {
			const control = <FormArray>this.myForm.controls[fldVal];
			control.push(this.initRel(relaxFieldVal, editData));
		}
		this.relaxFieldCount[index+1].push('value');
		this.relaxationlistcount[index] = relcount+1;
		/* console.log(editData);
		this.relaxFormField_third = editData['relaxFormField_third']; */

	} 
	
	removeSection(index:any, relcount:number, i: number) {
		let fldVal = 'rel' + parseInt(index+1);
		const control = <FormArray>this.myForm.controls[fldVal];
		control.removeAt(i);
		this.relaxationlistcount[index] = relcount-1;
		this.relaxFieldCount[index+1].pop();
		
		/*console.log(fldVal);
		console.log(this.relaxationlistcount);*/
	}
	
	get ageDep() { // name property
	   return this.myForm.get('ageDep')
	}
	
	get relaxFields() { // name property
	   return this.myForm.get('relaxFields')
	}
	
	
	get formFields() { // name property
	   return this.myForm.get('formFields')
	}
	
	ageConfigMap(){
		this.ageDependFieldVal = [];
		let AgeConfigDependentField = this.myForm.get('formFields').value;
		let AgeConfigDependent = this.myForm.get('ageDep').value;
		if(AgeConfigDependent == 'Y' && AgeConfigDependentField != '') {
			for (let optionObj of this.fieldListArr[AgeConfigDependentField]['options']) { 
				this.ageDependFieldVal.push(optionObj);
			}
			//console.log(this.ageDependFieldVal);
		}
		
		/* this.myForm.get('formFields').valueChanges.subscribe(val => {
			console.log(val);
			console.log(ageDep.value);
		}); */
	}
  
    searchStatus(){
	  //console.log("innn "+this.inputSearch);
	  this.ruleengineService.getRulesManage(this.model.accountName,this.model.projectName,this.inputSearch).subscribe(res => {
			this.ruleEngineData = res.data;
	  });
    }
  
    toscrollRule(el: HTMLElement){
	   el.scrollIntoView();
    }
  
	
	getParentfieldVal(arrayGroup, index,typeOpt='') {
		//console.log(this.rel1.value[index].relaxFormField1);
		let fldVal = 'rel' + parseInt(arrayGroup);
		let arrayGroupVal = this.myForm.get(fldVal) as FormArray;
		if(typeOpt=='Avail') return arrayGroupVal.value[index]['relaxFormFieldAvail'];
		else return arrayGroupVal.value[index]['relaxFormField_sec'];
    }
	
    getSecondaryOpt(arrayGroup, index,typeOpt=''){
		let fldVal = 'rel' + parseInt(arrayGroup);
		let arrayGroupVal = this.myForm.get(fldVal) as FormArray;
		//console.log(arrayGroupVal);
		let arrIndexValopt = arrayGroupVal.value[index];
		if(typeOpt=="Avail"){
			let relaxFormField_secVal = arrayGroupVal.value[index]['relaxFormFieldAvail'];
			let relaxFormField_third_val = (document.getElementById("relaxFormFieldAvail_sec_"+index));
			this.RelaxFieldThirdAvail[index] = Array();
			if(relaxFormField_secVal!=''){
				//console.log("omomomo");
				if(this.config['fields'][relaxFormField_secVal]['type'] == 'category'){
					let arrOpt = this.config['fields'][relaxFormField_secVal]['options'];
					this.RelaxFieldThirdAvail[index] = arrOpt;
				}
			}
		}else {
			let relaxFormField_secVal = arrayGroupVal.value[index]['relaxFormField_sec'];
			/* console.log(this.inputFiledSel);
			console.log(this.QueryBuilderConfigOrigArr); 
			console.log(this.query); 
			console.log(this.config['fields']);
			console.log(this.config['fields'][relaxFormField_secVal]);  */ 
			let relaxFormField_third_val = (document.getElementById("relaxFormField_third_"+index));
			this.RelaxFieldThird[index] = Array();
			if(relaxFormField_secVal!=''){
				if(this.config['fields'][relaxFormField_secVal]['type'] == 'category'){
					//relaxFormField2
					let arrOpt = this.config['fields'][relaxFormField_secVal]['options'];
					this.RelaxFieldThird[index] = arrOpt;
				}
			}
		}
			/* const control = <FormArray>this.myFormworkexp.controls['workexp'];
		control.push(this.initwork(workDt)); */
    }
	
	showUpload(){
		this.showAge = false;
		this.showCRRule = false;
		this.showWorkexpRule = false;
		this.showWorkexpRuleManagement = false;
		this.showRuleng = false;
		this.showDependent = true;
		this.showUploadSec = true;
		this.showMappingSec = false;
  }
  showMapping(){
		this.showAge = false;
		this.showCRRule = false;
		this.showWorkexpRule = false;
		this.showWorkexpRuleManagement = false;
		this.showRuleng = false;
		this.showDependent = true;
		this.showUploadSec = false;
		this.showMappingSec = true;
		this.mappingModel = {
			'parentField' : '',
			'parentData' : '',
			'childField' : '',
			'childData' : '',
		};
		//console.log(this.inputFiledSel);
  }
  
  dependentData(event,formData:NgForm) {
	/*console.log(formData);
	console.log(event);*/
	
	let frmData = formData.value;
	this.selectedFile = <File>event.target.files[0];
	var form = new FormData(); 
	form.append('depField', frmData.depField);
	form.append('projectId', this.model.projectName);
    form.append('depData', this.selectedFile, this.selectedFile.name);
	
	this.ruleengineService.uploadChildData(form).subscribe( res => { 
		//console.log(res);
	});
  }
  
  saveMappingData(formData:NgForm) {
	//console.log(formData);
	this.ruleengineService.dataMapping(formData.value,this.model.projectName).subscribe( res => { 
		if(res.success) {
			this.mappingModel = {
				'parentField' : '',
				'parentData' : '',
				'childField' : '',
				'childData' : '',
			};
		}
	});
  }
  
  getParentData(fldVal) {
	this.parentData = [];
	let rtnData = [];
	for(let fld of this.inputFiledSel) {
		if(fld['keyVal'] == fldVal && fld.hasOwnProperty('selectOption') && fld['selectOption'].length > 0) {
			//this.parentData = fld['selectOption']
			for (let option of fld['selectOption']) {
				let opt = {
					'Key':option.value,
					'Value' : option.label
				}
				rtnData.push(opt);
			}
			this.parentData = rtnData;
		} else if(fld['keyVal'] == fldVal && !fld.hasOwnProperty('selectOption') ) {
			this.ruleengineService.getListData(fldVal, this.model.projectName).subscribe( res => { 
				this.parentData = res.data
			});
		}
	}
  }
  getListData(fldVal) {
	this.listData = [];
	let rtnData = [];
	for(let fld of this.inputFiledSel) {
		if(fld['keyVal'] == fldVal && fld.hasOwnProperty('selectOption') && fld['selectOption'].length > 0) {
			//this.listData = fld['selectOption']
			for (let option of fld['selectOption']) {
				let opt = {
					'Key':option.value,
					'Value' : option.label
				}
				rtnData.push(opt);
			}
			this.listData = rtnData;
		} else if(fld['keyVal'] == fldVal && !fld.hasOwnProperty('selectOption')) {
			this.ruleengineService.getListData(fldVal, this.model.projectName).subscribe( res => { 
				this.listData = res.data
			});
		}
	}
  }
  
   getProjects() {
		//console.log(this.model.accountName);
		this.applicationService.getProjects(this.model.accountName).subscribe(res =>{
			this.projectData = res.data;
		});
   }
   
   getProjectAccDet() {
		this.projectService.getProjectDetails(this.model.accountName,this.model.projectName).subscribe(res =>{
			//this.projectData = res.data;
			this.AccProjectdet = res['data'];
		});
	}
	
	backtoSection(section:any){
		if(section == 'dashboard') this.router.navigate(['/dashboard']);
		else if(section == 'rule'){
			this.sharedService.changeAccount(this.model.accountName);
			this.sharedService.changeProject(this.model.projectName); 
			this.router.navigate(['/rulengine']);
		}else if(section == 'application'){
			this.sharedService.changeAccount(this.model.accountName);
			this.sharedService.changeProject(this.model.projectName); 
			this.router.navigate(['/application']);
		}else if(section == 'ageconfig'){
			this.sharedService.changeAccount(this.model.accountName);
			this.sharedService.changeProject(this.model.projectName); 
			this.router.navigate(['/age']); 
		}
	}
  
}