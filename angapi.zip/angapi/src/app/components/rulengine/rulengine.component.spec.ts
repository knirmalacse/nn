import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RulengineComponent } from './rulengine.component';

describe('RulengineComponent', () => {
  let component: RulengineComponent;
  let fixture: ComponentFixture<RulengineComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RulengineComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RulengineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
