import { Component, OnInit, ComponentRef, EventEmitter, Output } from '@angular/core';
import { ModalDialogService, IModalDialog, IModalDialogOptions, ModalDialogOnAction, IModalDialogButton } from "ngx-modal-dialog";
import { NgForm } from '@angular/forms';
import { RoleService } from '../../services/role.service';
import { Roleform }    from '../../classes/roleform';
import { Subject } from 'rxjs/Subject';
import { AclService } from '../../services/acl.service';
import { Router } from '@angular/router'; 
@Component({
  selector: 'app-role',
  templateUrl: './role.component.html',
  styleUrls: ['./role.component.css']
})
export class RoleComponent implements OnInit, IModalDialog {

  actionButtons: IModalDialogButton[];
  options: IModalDialogOptions;
  Response:string = '';
  closeDialogSubject = new Subject<any>();
  constructor(private modalService: ModalDialogService, private aclService: AclService, private _role:RoleService,public router: Router) {
    /* this.actionButtons = [
      { text: 'Close' }, // no special processing here
      { text: 'Create Role', onAction: () => this.onSubmit(this.NgForm, id) }
    ]; */
  }
  roleAdd: any = 0;
  roleView: any = 0;
  roleEditval: any = 0;
  roleDelete: any = 0;
  pages  = 0;
  ngOnInit() {
	this.getUserAccess('role','add');
	this.getUserAccess('role','view');
	this.getUserAccess('role','edit');
	this.getUserAccess('role','delete');
  }
   getUserAccess(compName:any, functAcc:any) {
	this.aclService.getRoles().then(userRoles => {
		if(compName == 'role') {
			if(functAcc == 'add') this.roleAdd = 0;
			if(functAcc == 'view') this.roleView = 0;
			if(functAcc == 'edit') this.roleEditval = 0;
			if(functAcc == 'delete') this.roleDelete = 0;
		}
		var avail = 0; 
		for(let pages of Object.values(userRoles)) {  
			if(pages.page == compName) {
				var accFunc = pages.functionality;
				console.log(accFunc.includes(functAcc));
				if(accFunc.includes(functAcc) == true) {
				this.router.navigate(['/role']);
				} else {
					this.router.navigate(['/dashboard']);
				}
				if(accFunc.includes(functAcc)){
					avail = 1;
				}
			}
		}
		 if(compName == 'role') {
			if(functAcc == 'add') this.roleAdd = avail;
			if(functAcc == 'view') this.roleView = avail;
			if(functAcc == 'edit') this.roleEditval = avail;
			if(functAcc == 'delete') this.roleDelete = avail;
			 
		} 
	}); 
  }
  
  role:any;
  dialogInit(reference: ComponentRef<IModalDialog>, dialogOption) {
	if(dialogOption.data != '') {
	  console.log(dialogOption.data);
	  this.roleEdit(dialogOption.data);
	}
	this.options = dialogOption;
  }
  roleManagement(_id) {
	if (_id=='') return this.createRole();
	else return this.updateRole(_id) ;
  }
  updateRole(_id) {
	this._role.updateRole(this.role, _id).subscribe(res => {
		if(res.success==false) {
          this.Response = res.message.role;
		  return false;
		} else if(res.success==true) {
		  this.Response = res.message;
		  this.options.onClose();
		  this.options.closeDialogSubject.next();
		  return true;
		}
	});
  }
  createRole() {
	this._role.createRole(this.role).subscribe(res => {
		if(res.success==false) {
          this.Response = res.message.role;
		  return false;
		} else if(res.success==true) {
		  this.Response = res.message;
		  this.options.onClose();
		  this.options.closeDialogSubject.next();
		  return true;
		}
	});
  }
  model = new Roleform('', '');
  onSubmit(form: NgForm, _id:any) {
    this.role = form.value;
	return this.roleManagement(_id);
  }
  
  roleEdit(selectedRole:any){
	console.log(selectedRole);
	this.model = new Roleform(selectedRole._id, selectedRole.role);
  }
}
