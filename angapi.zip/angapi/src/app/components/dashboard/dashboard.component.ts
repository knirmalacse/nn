import { Component, OnInit, ComponentFactoryResolver, ViewContainerRef } from '@angular/core';
import { Router } from "@angular/router";
//import { ModalDialogService } from 'ngx-modal-dialog';

import { LoginService } from '../../services/login.service';
import { SharedService } from '../../services/shared.service';
import { AccountService } from '../../services/account.service';
import { ProjectService } from '../../services/project.service';
import { AclService } from '../../services/acl.service';

import { ModalDialogService,IModalDialog,IModalDialogOptions,ModalDialogOnAction } from "ngx-modal-dialog";
import { AccountComponent } from '../account/account.component';
import { ProjectComponent } from '../project/project.component';
import { Accountform }    from '../../classes/accountform';
import { Projectform }    from '../../classes/projectform';

import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit  {

  constructor(private loginService: LoginService,private sharedService: SharedService,private accountService:AccountService,private projectService:ProjectService, private modalService: ModalDialogService, private viewRef: ViewContainerRef, private aclService: AclService, public router: Router) { }
  actnElement:string;
  display:string = 'none';
  id:any = '';
  accountData:any;
  projectData:any;
  selAccount:any;
  model:any;
  public accData: any;
  options: IModalDialogOptions;
  closeDialogSubject = new Subject<any>();
  
  dataDet:any;
  selectedProjectServices:any;
  selectedProjectComponents:any;
  projectServ:any;
  projectComp:any;
  projectPayMode:any;
  projectPayType:any;
  
  prjAdd: any = 0;
  prjView: any = 0;
  prjEdit: any = 0;
  prjDelete: any = 0;
  
  accAdd: any = 0;
  accView: any = 0;
  accEdit: any = 0;
  accDelete: any = 0;
  
  createruleAdd: any = 0;
  createruleView: any = 0;
  createruleEdit: any = 0;
  createruleDelete: any = 0;
  
  createappAdd: any = 0;
  createappView: any = 0;
  createappEdit: any = 0;
  createappDelete: any = 0;
  
  pages  = 0;
  current = 1;
  p: number = 1;
  ngOnInit() {
	this.getUsername();
	this.getAccountList(this.id,1);
	this.getUserAccess('project','add');
	this.getUserAccess('project','view');
	this.getUserAccess('project','edit');
	this.getUserAccess('project','delete');
	
	this.getUserAccess('account','add');
	this.getUserAccess('account','view');
	this.getUserAccess('account','edit');
	this.getUserAccess('account','delete');
	
	this.getUserAccess('createrule','add');
	this.getUserAccess('createrule','view');
	this.getUserAccess('createrule','edit');
	this.getUserAccess('createrule','delete');
	
	this.getUserAccess('createapp','add');
	this.getUserAccess('createapp','view');
	this.getUserAccess('createapp','edit');
	this.getUserAccess('createapp','delete'); 
  }
  
  /* dialogInit(reference: ComponentRef<IModalDialog>, options?: IModalDialogOptions) {
    // no processing needed
  } */
  
  pageChanged(newPage: number,AccIDVal,i) {
	  console.log("in page"+newPage);
	  
	  this.p = newPage;
	  this.getAccountList(AccIDVal,newPage,AccIDVal);
	  console.log(AccIDVal);
	  //document.getElementById("acc_coll_1").setAttribute("is-open", "true");
	  //document.getElementById("acc_coll_"+i).style.display = "block";
	   //this.router.navigate(['/books'], { queryParams: { page: newPage } }); 
  }
  
  getUserAccess(compName:any, functAcc:any) {
	this.aclService.getRoles().then(userRoles => {
		 
		if(compName == 'project'){
			if(functAcc == 'add') this.prjAdd = 0;
			if(functAcc == 'view') this.prjView = 0;
			if(functAcc == 'edit') this.prjEdit = 0;
			if(functAcc == 'delete') this.prjDelete = 0;	
		}else if(compName == 'account') {
			if(functAcc == 'add') this.accAdd = 0;
			if(functAcc == 'view') this.accView = 0;
			if(functAcc == 'edit') this.accEdit = 0;
			if(functAcc == 'delete') this.accDelete = 0;
		}else if(compName == 'createrule') {
			if(functAcc == 'add') this.createruleAdd = 0;
			if(functAcc == 'view') this.createruleView = 0;
			if(functAcc == 'edit') this.createruleEdit = 0;
			if(functAcc == 'delete') this.createruleDelete = 0;
		}else if(compName == 'createapp') {
			if(functAcc == 'add') this.createappAdd = 0;
			if(functAcc == 'view') this.createappView = 0;
			if(functAcc == 'edit') this.createappEdit = 0;
			if(functAcc == 'delete') this.createappDelete = 0;
		}  
		var avail = 0; 
		for(let pages of Object.values(userRoles)) { //let pages in userRoles //Object.values(userRoles)
		//console.log(typeof userRoles)
		//for(let i=0; i<userRoles.length; i++){
			//console.log(pages);
			//console.log(pages.page+'--->'+compName);
			if(pages.page == compName) {
				var accFunc = pages.functionality;
				//console.log(accFunc.includes(functAcc));
				if(accFunc.includes(functAcc)){
					avail = 1;
				}
			}
		}
		/* userRoles.forEach(function(pages){
			//console.log(pages.page+'--->'+compName);
			if(pages.page == compName) {
				var accFunc = pages.functionality;
				console.log(accFunc.includes(functAcc));
				if(accFunc.includes(functAcc)){
					avail = 1;
					// if(compName == 'project'){
					//	this.prjAdd = 1;
					//}
					//if(compName == 'account') {
					//	this.accAdd = 1;
					//} 
				}
			}
		}); */
		if(compName == 'project'){
			//this.prjAdd = avail;
			if(functAcc == 'add') this.prjAdd = avail;
			if(functAcc == 'view') this.prjView = avail;
			if(functAcc == 'edit') this.prjEdit = avail;
			if(functAcc == 'delete') this.prjDelete = avail;
		}
		if(compName == 'account') {
			//this.accAdd = avail;
			if(functAcc == 'add') this.accAdd = avail;
			if(functAcc == 'view') this.accView = avail;
			if(functAcc == 'edit') this.accEdit = avail;
			if(functAcc == 'delete') this.accDelete = avail;
		} 
		if(compName == 'createrule') {
			//this.accAdd = avail;
			if(functAcc == 'add') this.createruleAdd = avail;
			if(functAcc == 'view') this.createruleView = avail;
			if(functAcc == 'edit') this.createruleEdit = avail;
			if(functAcc == 'delete') this.createruleDelete = avail;
		} 
		
		if(compName == 'createapp') {
			//this.accAdd = avail;
			if(functAcc == 'add') this.createappAdd = avail;
			if(functAcc == 'view') this.createappView = avail;
			if(functAcc == 'edit') this.createappEdit = avail;
			if(functAcc == 'delete') this.createappDelete = avail;
		} 
		//console.log('project ->'+this.prjAdd+" account ->"+this.accAdd);
		
	}); 
	//console.log(this.prjAdd);
	//var roles = this.aclService.isAccessible();
	/* roles.forEach(function(pages){
		console.log(pages.page+'--->'+compName);
		if(pages.page == compName) {
			var accFunc = pages.functionality;
			console.log(accFunc.includes(functAcc));
			if(accFunc.includes(functAcc)){
				//this.router.navigate(['/dashboard']);
				return true;
			}else {
				//this.router.navigate(['/login']);
				return  false;
			}
		}
		return false;
	}); */
  }
  
	
  getUsername(){
	this.loginService.getLoggedInUser().subscribe(res => {
			//this.userData = res;
			this.sharedService.LoggedUserName.next(res);
			//console.log('dddd'+res);
		});
  }
  
  mouseEnter(selectedDiv) {
	this.actnElement = selectedDiv;
	this.p = 1;
  }
  
  mouseLeave() {
	this.actnElement = '';
  }
  
  openModal(){
   this.display='block'; 
  }
  
  onCloseHandled(){
   this.display='none'; 
  }
  
  getAccountList(selectedAcc?: any,pageNo?:any,AccIDVal?:any){
		/* this.accountService.getAccountInfo().subscribe(res => {
			this.accountData = res['data'];	
			//this.pages  = Math.ceil(res.data.length / 5);
			this.selAccount = (selectedAcc != '')?selectedAcc:'';
			//console.log(res);
		});
		return true; */
		
		this.accountService.getAccountInfoPageLtd(pageNo,AccIDVal).subscribe(res => {
			if (typeof AccIDVal !== 'undefined'){
				//console.log(this.accountData);
				//console.log(res.data);
				let resultdataArr = this.accountData;
				//console.log(resultdataArr);
				
				var resultdataIndex = resultdataArr.findIndex(function(item, i){
					return item._id === AccIDVal;
				});
				//console.log(AccIDVal);
				//console.log(resultdataIndex);
				this.accountData[resultdataIndex] = res['data'][0];
				
			}else{
				this.accountData = res['data'];	
			}
			//this.pages  = Math.ceil(res.data.length / 5);
			this.selAccount = (selectedAcc != '')?selectedAcc:'';
			console.log("innnkn");
			console.log(this.accountData);
		});
		
		return true;
  }
  
  
  
  addAccount(){
	this.modalService.openDialog(this.viewRef, {
		childComponent: AccountComponent,
		onClose: () => this.getAccountList(),
		data: '',
		//closeDialogSubject: true,
	});
  }
  
  getProjectList(){
	this.projectService.getProjectInfo().subscribe(res => {
			this.projectData = res['data'];	
			//console.log(res);
		});
	return true;
  }
  addProject(id:any){
    this.dataDet = {
		data: '',
		data_aid: id
	 };
	   
	this.modalService.openDialog(this.viewRef, {
		childComponent: ProjectComponent,
		onClose: () => this.getAccountList(),
		data: this.dataDet
		//closeDialogSubject: true,
	});
  }
  accountEdit(id:any){
	  this.accountService.getAccountDetails(id)
			.subscribe(res => {			
				if(res['success'] == true){
					//this.model = new Accountform(id, res.data.accountName, res.data.registrationType ,res.data.accountDetails,res.data.accountDomain);
					this.modalService.openDialog(this.viewRef, {
						//title: 'Some modal title',
						childComponent: AccountComponent,
						onClose: () => this.getAccountList(id),
						data: id,
						//closeDialogSubject: true,
					});
				} else {
					this.model = new Accountform('', '','','','');
				}
				
			}); 
	/*this.accountService.getAccountDetails().subscribe(res => {
		//this.accountData = res.data;	
		console.log(res);
		this.modalService.openDialog(this.viewRef, {
		title: 'Some modal title',
		childComponent: AccountComponent,
		onClose: this.getAccountList(),
		data: res.data
	});
	});*/
  }
  
  
  projectEdit(aid:any,pid:any){
	  this.dataDet = {
		data: pid,
		data_aid: aid
		};
	  this.projectService.getProjectDetails(aid, pid) 
		.subscribe(res => {			
			if(res['success'] == true){
			
				this.modalService.openDialog(this.viewRef, {
					//title: 'Some modal title',
					childComponent: ProjectComponent,
					onClose: () => this.getAccountList(aid),
					data: this.dataDet
					//closeDialogSubject: true,
				});
			    
			}				
			else {
				this.closeDialogSubject.next(false);
				this.model = new Projectform(this.dataDet['data_aid'], '', '', '', '',{hasEmail:'',hasSms:'',hasCaptcha:'',hasBarcode:'',hasUploads:'',hasPayment:''},{hasRegistration:'',hasReRegistration:'',hasCallletter:'',hasResults:''});
			}
		}); 
  }
  //ModalDialogOnAction = this.getAccountList();
  
   goApplication(account,project) {
	this.sharedService.changeAccount(account);
	this.sharedService.changeProject(project);
	this.router.navigate(['/application']);
  }
  
   goAge(account,project) {
	this.sharedService.changeAccount(account);
	this.sharedService.changeProject(project);
	this.router.navigate(['/age']);
  }
  
  goAppRuleEngine(account,project){
    this.sharedService.changeAccount(account);
	this.sharedService.changeProject(project);
	this.router.navigate(['/rulengine']);
  }
  
  setApplnAge(account,project){
    this.sharedService.changeAccount(account);
	this.sharedService.changeProject(project);
	this.router.navigate(['/age']);
  }
  
}
