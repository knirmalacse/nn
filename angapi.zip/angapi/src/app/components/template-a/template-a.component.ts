import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-template-a',
  templateUrl: './template-a.component.html',
  styleUrls: ['./template-a.component.css']
})
export class TemplateAComponent implements OnInit {
  
  constructor() { }

  ngOnInit() {
  }

}
