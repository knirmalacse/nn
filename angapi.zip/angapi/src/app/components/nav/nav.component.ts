import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SharedService } from '../../services/shared.service';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {

  isUserLoggedIn: boolean;
  LoggedUserName: String;
  
  constructor( private router: Router,private sharedService: SharedService) {
    this.sharedService.IsUserLoggedIn.subscribe( value => {
		
		//console.log('here');
        this.isUserLoggedIn = value;
    });
	this.sharedService.LoggedUserName.subscribe( value => {
		console.log(value);
		//console.log('here');
        this.LoggedUserName = value;
    });
  }

  ngOnInit() {
  }

  goHome() {
	this.router.navigate(['dashboard']);
  }
  
  goUsers() {
	this.router.navigate(['users']);
  }
  
  goProject() {
	this.router.navigate(['project']);
  }
  
  goApplication() {
	this.router.navigate(['application']);
  }
  
  getRoles() {
	this.router.navigate(['role']);
  }
  
  goAccesslevel() {
	this.router.navigate(['accesslevel']);
  }
  
}
