import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { NgForm } from '@angular/forms';
import { UsersService } from '../../services/users.service';
import { LoginService } from '../../services/login.service';
import { SharedService } from '../../services/shared.service';
import { AccountService } from '../../services/account.service';
import { AclService } from '../../services/acl.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-accesslevel',
  templateUrl: './accesslevel.component.html',
  styleUrls: ['./accesslevel.component.css']
})

export class AccesslevelComponent implements OnInit {

  constructor(private _data:UsersService,private loginService: LoginService,private aclService: AclService,private sharedService: SharedService,private accountService:AccountService, public router: Router,private toastr: ToastrService) { }

  
  userTypes = [{id:'1','userType':'Super Admin'},{id:'2','userType':'Org Admin'},{id:'3','userType':'Client'},{id:'4','userType':'User'}];
  userData:any;
  dataDet:any;
  funArr:any;
  funArrfuns: any;
  rtnData:any;
  rtnDataRes:any;
  
  accesslevelAdd: any = 0;
  accesslevelView: any = 0;
  accesslevelEdit: any = 0;
  accesslevelDelete: any = 0;
  
  view_acc_control:any = false;
  add_acc_control:any = false;
  edit_acc_control:any = false;
  delete_acc_control:any = false;
  
  view_project_control:any = false;
  add_project_control:any = false;
  edit_project_control:any = false;
  delete_project_control:any = false;
  
  view_user_control:any = false;
  add_user_control:any = false;
  edit_user_control:any = false;
  delete_user_control:any = false;
  
  view_accesslevel_control:any = false;
  add_accesslevel_control:any = false;
  edit_accesslevel_control:any = false;
  delete_accesslevel_control:any = false;
  
  view_createrule_control:any = false;
  add_createrule_control:any = false;
  edit_createrule_control:any = false;
  delete_createrule_control:any = false;
  
  view_createapp_control:any = false;
  add_createapp_control:any = false;
  edit_createapp_control:any = false;
  delete_createapp_control:any = false;
  
  view_role_control:any = false;
  add_role_control:any = false;
  edit_role_control:any = false;
  delete_role_control:any = false;
  
  UserRole:any = '';
  UserRoleDt:any = '';
  loading = false;
  ngOnInit() {
    this.getUserList(); 
	this.getUsername();
	
	this.getUserAccess('accesslevel','add');
	this.getUserAccess('accesslevel','view');
	this.getUserAccess('accesslevel','edit');
	this.getUserAccess('accesslevel','delete');
  }
   getUserAccess(compName:any, functAcc:any) {
	this.aclService.getRoles().then(userRoles => {
		if(compName == 'accesslevel') {
			if(functAcc == 'add') this.accesslevelAdd = 0;
			if(functAcc == 'view') this.accesslevelView = 0;
			if(functAcc == 'edit') this.accesslevelEdit = 0;
			if(functAcc == 'delete') this.accesslevelDelete = 0;
		}
		var avail = 0; 
		for(let pages of Object.values(userRoles)) {  
			if(pages.page == compName) {
				var accFunc = pages.functionality;
				console.log(accFunc.includes(functAcc));
				if(accFunc.includes(functAcc) == true) {
				this.router.navigate(['/accesslevel']);
			} else {
				this.router.navigate(['/dashboard']);
			}
				if(accFunc.includes(functAcc)){
					avail = 1;
				}
			}
		}
		 if(compName == 'accesslevel') {
			if(functAcc == 'add') this.accesslevelAdd = avail;
			if(functAcc == 'view') this.accesslevelView = avail;
			if(functAcc == 'edit') this.accesslevelEdit = avail;
			if(functAcc == 'delete') this.accesslevelDelete = avail;
			
		} 
	}); 
  }
   
  getUserList(){
	this._data.UserDetails().subscribe(res => {
			this.userData = res['data'];	
			console.log(res);
		});
  }
  
  getUsername(){
	this.loginService.getLoggedInUser().subscribe(res => {
			//this.userData = res;
			this.sharedService.LoggedUserName.next(res);
		});
  }
  
  onSubmit(aclEngForm: NgForm){
	 /*  console.log("------------accesslevel form--------------");
	  console.log(aclEngForm);
	  console.log(this.UserRoleDt); */
	  
			
	  //if(aclEngForm.valid){
		   
		   this.loading = true;
		   let accountObj = [];
		   let projectObj = [];
		   let userObj = [];
		   let accesslevelObj = [];
		   let createruleObj = [];
		   let createappObj = [];
		   let roleObj = [];
		   
		    //account
		  if(this.view_acc_control)
			  accountObj.push('view');
		  if(this.add_acc_control)
			   accountObj.push('add');
		  if(this.edit_acc_control)
			    accountObj.push('edit');
		  if(this.delete_acc_control)
			  accountObj.push('delete'); 
		  
		   //project
		  if(this.view_project_control)
			  projectObj.push('view');
		  if(this.add_project_control)
			   projectObj.push('add');
		  if(this.edit_project_control)
			    projectObj.push('edit');
		  if(this.delete_project_control)
			  projectObj.push('delete'); 
		  
		  //user
		  if(this.view_user_control)
			  userObj.push('view');
		  if(this.add_user_control)
			   userObj.push('add');		
		  if(this.edit_user_control)
			    userObj.push('edit');		
		  if(this.delete_user_control)
			  userObj.push('delete'); 
		  
		  //accesslevel
		  if(this.view_accesslevel_control)
			  accesslevelObj.push('view');		
		  if(this.add_accesslevel_control)
			   accesslevelObj.push('add');		
		  if(this.edit_accesslevel_control)
			    accesslevelObj.push('edit');		
		  if(this.delete_accesslevel_control)
			  accesslevelObj.push('delete'); 
		  
		   //createrule
		  if(this.view_createrule_control)
			  createruleObj.push('view');		
		  if(this.add_createrule_control)
			   createruleObj.push('add');		
		  if(this.edit_createrule_control)
			    createruleObj.push('edit');		
		  if(this.delete_createrule_control)
			  createruleObj.push('delete');  
		  
		  //createapp
		  if(this.view_createapp_control)
			  createappObj.push('view');		
		  if(this.add_createapp_control)
			   createappObj.push('add');		
		  if(this.edit_createapp_control)
			    createappObj.push('edit');		
		  if(this.delete_createapp_control)
			  createappObj.push('delete'); 

		  //role
		  if(this.view_role_control)
			  roleObj.push('view');		
		  if(this.add_role_control)
			   roleObj.push('add');		
		  if(this.edit_role_control)
			    roleObj.push('edit');		
		  if(this.delete_role_control)
			  roleObj.push('delete'); 
		  
		this.funArr = [{page:'account',functionality:accountObj},{page:'project',functionality:projectObj},{page:'user',functionality:userObj},{page:'accesslevel',functionality:accesslevelObj},{page:'createrule',functionality:createruleObj},{page:'createapp',functionality:createappObj},{page:'role',functionality:roleObj}];
		   this.dataDet = {
				roleID: this.UserRole,
				access: this.funArr
			};
			   
		this.accountService.accountAclIns(this.dataDet,this.UserRoleDt)
        .subscribe(res => {
			/* console.log('---------acl datas---------');
			console.log(this.dataDet); */
		    this.loading = false;
			this.rtnData = res;
			if(res['success'] == true ){
				this.toastr.success(res['message']);
			    this.router.navigate(['/dashboard']);
				/* this.options.onClose();
				this.options.closeDialogSubject.next(); */
			}else{
				this.toastr.error("Error in Creation...");
			}
		});
		
	 // }
  }
  
  getAccessDetails(roleID:any){
		this.view_acc_control = false;
		this.add_acc_control = false;
		this.edit_acc_control = false;
		this.delete_acc_control = false;
		
		this.view_project_control = false;
		this.add_project_control = false;
		this.edit_project_control = false;
		this.delete_project_control = false;
		
		this.view_user_control = false;
		this.add_user_control = false;
		this.edit_user_control = false;
		this.delete_user_control = false;
		
		this.view_accesslevel_control = false;
		this.add_accesslevel_control = false;
		this.edit_accesslevel_control = false;
		this.delete_accesslevel_control = false;
		
		this.view_createrule_control = false;
		this.add_createrule_control = false;
		this.edit_createrule_control = false;
		this.delete_createrule_control = false;
		
		this.view_createapp_control = false;
		this.add_createapp_control = false;
		this.edit_createapp_control = false;
		this.delete_createapp_control = false;
		
		this.view_role_control = false;
		this.add_role_control = false;
		this.edit_role_control = false;
		this.delete_role_control = false;
		
		this.UserRoleDt = '';
	  if(roleID!=""){
		   this.accountService.getaccountAcl(roleID)
			.subscribe(res => {
				this.rtnDataRes = res;
				console.log(roleID);
				if(res['success'] == true ){
					console.log('------------res data------------');
					console.log(res['data']);
					let accessData = res['data']['access'];
					this.UserRoleDt = res['data']['_id'];
					for (let key in accessData) {
						var value = accessData[key];
						for (let keyV in value) {
							if(keyV == 'functionality'){
								var valueV = value[keyV];
								for (let keyVal in valueV) {
									var valueVD = valueV[keyVal];
									var pageVal = value['page'];
									console.log(value['page']+"--"+valueVD);
								
									if(pageVal == 'account'){
										if(valueVD == 'view') this.view_acc_control = true;
										if(valueVD == 'add') this.add_acc_control = true;
										if(valueVD == 'edit') this.edit_acc_control = true;
										if(valueVD == 'delete') this.delete_acc_control = true;
									}else if(pageVal == 'project'){
										if(valueVD == 'view') this.view_project_control = true;
										if(valueVD == 'add') this.add_project_control = true;
										if(valueVD == 'edit') this.edit_project_control = true;
										if(valueVD == 'delete') this.delete_project_control = true;
										
									}else if(pageVal == 'user'){
										if(valueVD == 'view') this.view_user_control = true;
										if(valueVD == 'add') this.add_user_control = true;
										if(valueVD == 'edit') this.edit_user_control = true;
										if(valueVD == 'delete') this.delete_user_control = true;	
									}else if(pageVal == 'accesslevel'){
										if(valueVD == 'view') this.view_accesslevel_control = true;
										if(valueVD == 'add') this.add_accesslevel_control = true;
										if(valueVD == 'edit') this.edit_accesslevel_control = true;
										if(valueVD == 'delete') this.delete_accesslevel_control = true;	
									}else if(pageVal == 'createrule'){
										if(valueVD == 'view') this.view_createrule_control = true;
										if(valueVD == 'add') this.add_createrule_control = true;
										if(valueVD == 'edit') this.edit_createrule_control = true;
										if(valueVD == 'delete') this.delete_createrule_control = true;	
									}else if(pageVal == 'createapp'){
										if(valueVD == 'view') this.view_createapp_control = true;
										if(valueVD == 'add') this.add_createapp_control = true;
										if(valueVD == 'edit') this.edit_createapp_control = true;
										if(valueVD == 'delete') this.delete_createapp_control = true;	
									}else if(pageVal == 'role'){
										if(valueVD == 'view') this.view_role_control = true;
										if(valueVD == 'add') this.add_role_control = true;
										if(valueVD == 'edit') this.edit_role_control = true;
										if(valueVD == 'delete') this.delete_role_control = true;	
									}
								}
							}
						}
					}
				} 
			});  
	  }
  }
  
 
  
  
}
