import { Component, OnInit, ComponentRef, EventEmitter, Output } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Accountform }    from '../../classes/accountform';
import { AccountService } from '../../services/account.service';
import { LoginService } from '../../services/login.service';
import { SharedService } from '../../services/shared.service';

import { ModalDialogService, IModalDialog, IModalDialogOptions, ModalDialogOnAction, IModalDialogButton } from "ngx-modal-dialog";

import { Subject } from 'rxjs/Subject';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent implements OnInit,IModalDialog  {

   
  //actionButtons: IModalDialogButton[];
 // onClose: ModalDialogOnAction;
  options: IModalDialogOptions;
  data:any;
  constructor(private _data:AccountService, private loginService: LoginService, private sharedService: SharedService, private modalService: ModalDialogService) 
  {}
  users: any;
  rtnData:any;
  rtnStatusData:any;
  accountData:any;
  closeDialogSubject = new Subject<any>();
  
  ngOnInit() {	
	//this.getAccountList(); 
	this.getUsername()
  }
  
  dialogInit(reference: ComponentRef<IModalDialog>,dialogOption) {
    // no processing needed
	if(dialogOption.data == '') {
		dialogOption.title = 'Account Creation';
		//dialogOption.data = new Accountform('', '','','','');
		this.model = new Accountform('', '','','','');
		//dialogOption.onClose = this.getAccountList();
		//dialogOption.closeDialogSubject = this.resultFn;
	} else {
		dialogOption.title = 'Account Updation';
		this.accountEdit(dialogOption.data);
		/*dialogOption.actionButtons = [
			{ text: 'Update', onAction: () => true },
			{ text: 'Cancel', onAction: () => true }
		];*/
		//dialogOption.onClose = () => this.getAccountList();
		//dialogOption.closeDialogSubject = dialogOption.onClose;
	}
	this.options = dialogOption;
  }
  
  
  getAccountList(){
	this._data.getAccountInfo().subscribe(res => {
			if(res.hasOwnProperty("data"))
				this.accountData = res['data'];	
			//this.options.closeDialogSubject.next(this.accountData);
			this.options.onClose();
			console.log('aacount'+res);
		});
		return true;
  }
  
  getUsername(){
	this.loginService.getLoggedInUser().subscribe(res => {
			//this.accountData = res;
			this.sharedService.LoggedUserName.next(res);
			console.log('dddd'+res);
		});
  }
  
  registrationAccountTypes = [{id:'1','type':'One Time Registration'},{id:'2','type':'Seperate Registration'}];
    
  model = new Accountform('', '','','','');
  onSubmit(form: NgForm, id:any) {
	  console.log(id);
	  this._data.accountRegistration(form.value,id)
        .subscribe(res => {
			this.rtnData = res;
			if(res['success'] == true ){
				this.options.onClose();
				this.options.closeDialogSubject.next();
			} 
		});  
  }
  
  accountEdit(aid:any){
	  return this._data.getAccountDetails(aid)
		.subscribe(res => {			
			if(res['success'] == true) {
				//this.resultFn.next(true);
				this.model = new Accountform(aid, res['data']['accountName'], res['data']['registrationType'] ,res['data']['accountDetails'],res['data']['accountDomain']);
				console.log(this.model);
			} else {
				this.closeDialogSubject.next(false);
				this.model = new Accountform('', '','','','');
			}
		}); 
  }
  
  deleteAccount(aid:any){	
			
	  this._data.deleteAccount(aid)
		.subscribe(res => {		
			this.rtnStatusData = res;
			this.getAccountList();
		}); 
		
	   //this.getAccountList(); 
  }
  
  clearFormData(){
	//this.modalDialogInstanceService.closeAnyExistingModalDialog();
	//this.model = new Accountform('', '','','','');
	//this.options.onClose();
	this.options.closeDialogSubject.next();
  }	
	
}
