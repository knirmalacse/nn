import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router'; 
import { Userform }    from '../../classes/userform';
import { UsersService } from '../../services/users.service';
import { LoginService } from '../../services/login.service';
import { SharedService } from '../../services/shared.service';
import { AclService } from '../../services/acl.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

  constructor(private _data:UsersService,private loginService: LoginService,private aclService: AclService, private sharedService: SharedService,public router: Router) {}
  users: any;
  rtnData:any;
  rtnStatusData:any;
  userData:any;
  
  userAdd: any = 0;
  userView: any = 0;
  userEditval: any = 0;
  userDelete: any = 0;
  pages  = 0;
  
  ngOnInit() {	
	this.getUserList(); 
	this.getUsername()
	
	this.getUserAccess('user','add');
	this.getUserAccess('user','view');
	this.getUserAccess('user','edit');
	this.getUserAccess('user','delete');
	 
  }
  
  getUserAccess(compName:any, functAcc:any) { 
	this.aclService.getRoles().then(userRoles => {
		if(compName == 'user') {
			if(functAcc == 'add') this.userAdd = 0;
			if(functAcc == 'view') this.userView = 0;
			if(functAcc == 'edit') this.userEditval = 0;
			if(functAcc == 'delete') this.userDelete = 0;
		}
		var avail = 0; 
		for(let pages of Object.values(userRoles)) {  
			if(pages.page == compName) {
				var accFunc = pages.functionality;
				if(accFunc.includes(functAcc) == true) {
				this.router.navigate(['/users']);
				} else {
					this.router.navigate(['/dashboard']);
				} 
				if(accFunc.includes(functAcc)){
					avail = 1;
				} 
				 
				 
			}
		}
		 if(compName == 'user') {
			 
			if(functAcc == 'add') this.userAdd = avail;
			if(functAcc == 'view') this.userView = avail;
			if(functAcc == 'edit') this.userEditval = avail;
			if(functAcc == 'delete') this.userDelete = avail;
			
		}
					
		
	});  
	
  }
  
  getUserList(){
	this._data.UserDetails().subscribe(res => {
			this.userData = res['data'];	
			console.log(res);
		});
  }
  
  getUsername(){
	this.loginService.getLoggedInUser().subscribe(res => {
			//this.userData = res;
			this.sharedService.LoggedUserName.next(res);
			console.log('dddd'+res);
		});
  }
  
  userTypes = [{id:'1','userType':'Super Admin'},{id:'2','userType':'Org Admin'},{id:'3','userType':'Client'},{id:'4','userType':'User'}]; 
  model = new Userform('', '','','','','','','');
  onSubmit(form: NgForm, id:any) {
	  console.log(id);
	  this._data.Register(form.value,id)
        .subscribe(res => {
			this.rtnData = res;
			if(res['success'] == true){
				this.model = new Userform('', '','','','','','','');
				this.getUserList(); 
			}
		});  
  }
  
  userEdit(uid:any){
	  this._data.getUsers(uid)
		.subscribe(res => {			
			if(res['success'] == true)
				this.model = new Userform(uid, res['data']['UserName'], res['data']['EmailID'] ,'','',res['data']['UserRole'],res['data']['Mobile'],res['data']['status']);
				//this.model = new Userform(uid, res['data']['UserName'], res['data']['EmailID'] ,res['data']['Password'],res['data']['frmPassword2'],res['data']['UserRole'],res['data']['Mobile'],res['data']['status']);
			else
				this.model = new Userform('', '','','','','','','');
		}); 
  }

  
   updateStatus(uid:any, status:string){
		
		if(status == "N")
			status = "Y";
		else
			status = "N";
			
	  this._data.setUserStatus(uid, status)
		.subscribe(res => {		
			this.rtnStatusData = res;
			this.getUserList();
		}); 
		
	   //this.getUserList(); 
  }
  
  deleteUsers(uid:any){	
			
	  this._data.deleteUsers(uid)
		.subscribe(res => {		
			this.rtnStatusData = res;
			this.getUserList();
		}); 
		
	   //this.getUserList(); 
  }
  
  clearFormData(){
	this.model = new Userform('', '','','','','','','');
  }

}
