import { Component, OnInit, ComponentRef, EventEmitter, Output } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Projectform }    from '../../classes/projectform';
import { ProjectService } from '../../services/project.service';
import { LoginService } from '../../services/login.service';
import { SharedService } from '../../services/shared.service';

import { ModalDialogService, IModalDialog, IModalDialogOptions, ModalDialogOnAction, IModalDialogButton } from "ngx-modal-dialog";

import { Subject } from 'rxjs/Subject';

@Component({
  selector: 'app-project',
  templateUrl: './project.component.html',
  styleUrls: ['./project.component.css']
})
export class ProjectComponent implements OnInit,IModalDialog {

  options: IModalDialogOptions;
  data:any;
  closeDialogSubject = new Subject<any>();
  constructor(private _data:ProjectService, private loginService: LoginService, private sharedService: SharedService) { }
  users: any;
  rtnData:any;
  rtnStatusData:any;
  projectData:any;
  selectedProjectServices:any;
  selectedProjectComponents:any;
  projectServ:any;
  projectComp:any;
  projectPayMode:any;
  projectPayType:any;
  
  genericServices = [
						{id:'1','type':'generic','service':'Email',value:'hasEmail',checked: 'false'},
						{id:'2','type':'generic','service':'SMS',value:'hasSms',checked: 'false'},
						{id:'3','type':'generic','service':'Captcha',value:'hasCaptcha',checked: 'false'},
						{id:'4','type':'generic','service':'Barcode',value:'hasBarcode',checked: 'false'},
						{id:'5','type':'generic','service':'Uploads',value:'hasUploads',checked: 'false'},
						{id:'6','type':'generic','service':'Payment',value:'hasPayment',checked: 'false'},
					];
					
  genericComponents = [
						{id:'1','type':'generic','service':'Registration',value:'hasRegistration',checked: 'false'},
						{id:'2','type':'generic','service':'Re-Registration',value:'hasReRegistration',checked: 'false'},
						{id:'3','type':'generic','service':'Callletter',value:'hasCallletter',checked: 'false'},
						{id:'4','type':'generic','service':'Results',value:'hasResults',checked: 'false'},
					];
					
  paymentModeServices = [
						{id:'ONLINE','name':'ONLINE'},
						{id:'OFFLINE','name':'OFFLINE' },
						{id:'BOTH','name':'BOTH' }
					];
					
  paymentVendorServices = [
						{id:'SINGLE','name':'SINGLE'},
						{id:'MULTIPLE','name':'MULTIPLE' },
					];
	model = new Projectform('5ab3582c6038f515298300c0', '', '', '', '',{hasEmail:'',hasSms:'',hasCaptcha:'',hasBarcode:'',hasUploads:'',hasPayment:''},{hasRegistration:'',hasReRegistration:'',hasCallletter:'',hasResults:''});
  ngOnInit() {	
	this.getProjectList(); 
	this.getUsername()
	//console.log('model',this.model);
  }
  
  dialogInit(reference: ComponentRef<IModalDialog>,dialogOption) {
    // no processing needed
	if(dialogOption['data']['data'] == '') {
		dialogOption.title = 'Project Creation';
		//dialogOption.data = new Accountform('', '','','','');
		this.model = new Projectform(dialogOption['data']['data_aid'], '', '', '', '',{hasEmail:'',hasSms:'',hasCaptcha:'',hasBarcode:'',hasUploads:'',hasPayment:''},{hasRegistration:'',hasReRegistration:'',hasCallletter:'',hasResults:''});
		//dialogOption.onClose = this.getAccountList();
		//dialogOption.closeDialogSubject = this.resultFn;
	} else {
		dialogOption.title = 'Project Updation';
		this.accountEdit(dialogOption['data']['data_aid'],dialogOption['data']['data']);
		/*dialogOption.actionButtons = [
			{ text: 'Update', onAction: () => true },
			{ text: 'Cancel', onAction: () => true }
		];*/
		//dialogOption.onClose = () => this.getAccountList();
		//dialogOption.closeDialogSubject = dialogOption.onClose;
	}
	this.options = dialogOption;
  }
  
  getProjectList(){
	this._data.getProjectInfo().subscribe(res => {
			this.projectData = res['data'];	
			console.log(res);
		});
  }
  
  getUsername(){
	this.loginService.getLoggedInUser().subscribe(res => {
			//this.projectData = res;
			this.sharedService.LoggedUserName.next(res);
			console.log('dddd'+res);
		});
  }
  
  registrationAccountTypes = [{id:'1','type':'One Time Registration'},{id:'2','type':'Seperate Registration'}];
    
  
  
  onSubmit(form: NgForm, id:any, projectid:any) {
	  //console.log('id'+id);
	  //console.log('form'+form.value);
	  //form.value.projectServices = [true,true,false,false,false,false,false,false,false,false];
	 // console.log('service',form.value.projectServices);
	 /*  var projectServices = [];
	  this.genericServices.forEach(service=>{
		var servName = service.value;
		console.log(form.value.servName);
		projectServices[service.service] = form.value.servName;
	  });
	  console.log(projectServices); */
	  this._data.projectRegistration(form.value, id, projectid)
        .subscribe(res => {
			this.rtnData = res;
			if(res['success'] == true){
				/* this.model = new Projectform('5ab3582c6038f515298300c0', '', '', '', '',{hasEmail:'',hasSms:'',hasCaptcha:'',hasBarcode:'',hasUploads:'',hasPayment:''},{hasRegistration:'',hasReRegistration:'',hasCallletter:'',hasResults:''});
				this.getProjectList(); */ 
				
				this.options.onClose();
				this.options.closeDialogSubject.next();
			}
		});  
  }
  
  accountEdit(aid:any,pid:any){
	  this._data.getProjectDetails(aid, pid) 
		.subscribe(res => {			
			if(res['success'] == true){
			    this.projectPayMode = this.projectPayType = '';
				this.selectedProjectServices = [];
				this.selectedProjectComponents = [];
				this.projectServ = res['data']['projectServices'];
				this.projectComp = res['data']['projectComponents'];
				for(var myKey in this.projectServ) {
				 /*if(myKey == 'payment' && this.projectServ[myKey].mode != ''){
					this.projectPayMode = this.projectServ[myKey].mode;
				  }
				  
				 if(myKey == 'payment' && this.projectServ[myKey].type != ''){
					this.projectPayType = this.projectServ[myKey].type;
				  }*/
				  
				 if(this.projectServ[myKey] == true){
					this.selectedProjectServices.push(myKey);
				  }
				}
				for(var myKey in this.projectComp) {
				 if(this.projectComp[myKey] == true){
					this.selectedProjectComponents.push(myKey);
				  }
				}
				this.model = new Projectform(aid, pid, res['data']['projectName'], res['data']['projectDetails'], res['data']['projectIdentifier'], this.projectServ, this.projectComp);
				this.getProjectList(); 
			}				
			else {
				this.closeDialogSubject.next(false);
				this.model = new Projectform(aid, '', '', '', '',{hasEmail:'',hasSms:'',hasCaptcha:'',hasBarcode:'',hasUploads:'',hasPayment:''},{hasRegistration:'',hasReRegistration:'',hasCallletter:'',hasResults:''});
			}
		}); 
  }
  
  deleteProject(aid:any,pid:any){	
			
	  this._data.deleteProject(aid, pid)
		.subscribe(res => {		
			this.rtnStatusData = res;
			this.getProjectList();
		}); 
		
	   //this.getProjectList(); 
  }
  
  clearFormData(){
	//this.model = new Projectform('5ab3582c6038f515298300c0', '', '', '', '',{hasEmail:'',hasSms:'',hasCaptcha:'',hasBarcode:'',hasUploads:'',hasPayment:''},{hasRegistration:'',hasReRegistration:'',hasCallletter:'',hasResults:''});
	this.options.closeDialogSubject.next();
  }	

}
/* ,{hasEmail:'',hasSms:'',hasCaptcha:'',hasBarcode:'',hasRegistration:'',hasReRegistration:'',hasCallletter:'',hasResults:'',hasUploads:'',hasPayment:''} */