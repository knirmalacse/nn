import { Injectable } from '@angular/core';
import { CanActivate,Router, ActivatedRouteSnapshot, RouterStateSnapshot,ActivatedRoute } from '@angular/router';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';

import { AcpService } from '../services/acp.service';
import { AcpsharedService } from '../services/acpshared.service';

@Injectable()

export class OnlyLoggedInUsersGuard implements CanActivate { 

  constructor(private acpService: AcpService, public router: Router,private routeAct: ActivatedRoute/* ,
  private sharedacpService:SharedacpService */) {}; 
  
  projectId:any;
  LoggedUserNameVAl:any;
  appRegId:any;
  ngOnInit() {  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) :Observable<boolean> | boolean {
    this.projectId = route.params.projectId; 
	if(route.params.appRegId) this.appRegId = route.params.appRegId; 
	let routeUrlstate = state.url;
	let routeUrlstateStr = '/acp/'+this.projectId;
	var routeUrlstateStrPrint = '';
	if(this.appRegId)
		routeUrlstateStrPrint = '/acp/'+this.projectId+'/printapplication/'+this.appRegId;
	
	 return this.acpService.isLoggedIn(this.projectId).map(e => {
		 //console.log(e);
		if (e.success == true) {
			/* this.sharedService.IsUserLoggedIn.next(true);
			this.sharedService.LoggedUserName.next('10004'); 
			this.sharedService.LoggedUserName.subscribe( value => {
				this.LoggedUserNameVAl = value;
				console.log(this.LoggedUserNameVAl);
			});*/
			//console.log("ccc1");
			if(routeUrlstateStr == routeUrlstate) this.router.navigate(['/acp/'+this.projectId+'/settings']);
			return true; 
		}else{
			//console.log("ccc2");
			localStorage.removeItem('acp_auth_token');
			//sessionStorage.removeItem('loggedUserStorage'+this.projectId); 	
			if(routeUrlstateStrPrint != routeUrlstate){
				if(routeUrlstateStr != routeUrlstate) this.router.navigate(['/acp/'+this.projectId]);
			}
			return true;
		}
	}).catch(() => {
		//sessionStorage.removeItem('loggedUserStorage'+this.projectId);
		localStorage.removeItem('acp_auth_token');
		if(routeUrlstateStr != routeUrlstate) this.router.navigate(['/acp/'+this.projectId]);
		return Observable.of(false);
	});
		
	/* this.loginService.isLoggedIn().subscribe(data => {
		if(data.success == true) {
			// Page View Allowed
		} else {
			this.router.navigate(['login/'+this.projectId]);
			return false;
		}
	}); */
  }
}