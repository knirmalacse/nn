import { Injectable } from "@angular/core";
import { tap } from "rxjs/operators";
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
  HttpResponse,
  HttpErrorResponse
} from "@angular/common/http";
import { Observable } from "rxjs/Observable";

@Injectable()
export class AcpApplnInterceptor implements HttpInterceptor {
  constructor() { }
  //function which will be called for all http calls
  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
	 const idToken = localStorage.getItem("acp_auth_token");
   /*  //how to update the request Parameters
    const updatedRequest = request.clone({
      headers: request.headers.set("Authorization", idToken)
    }); */
	console.log("in inter");
	console.log(idToken);
	
	if (idToken) {
		const cloned = request.clone({
			headers: request.headers.set("Authorization",
				"Bearer " + idToken)
		});

		return next.handle(cloned);
	} else {
			return next.handle(request);
	}
	
	
    /* //logging the updated Parameters to browser's console
    console.log("Before making api call : ", updatedRequest);
    return next.handle(request).pipe(
      tap(
        event => {
          //logging the http response to browser's console in case of a success
          if (event instanceof HttpResponse) {
            console.log("api call success :", event);
          }
        },
        error => {
          //logging the http response to browser's console in case of a failuer
          if (event instanceof HttpResponse) {
            console.log("api call error :", event);
          }
        }
      )
    ); */
  }
}