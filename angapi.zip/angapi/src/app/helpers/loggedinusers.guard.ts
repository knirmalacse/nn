import { Injectable } from '@angular/core';
import { CanActivate,Router, ActivatedRouteSnapshot, RouterStateSnapshot,ActivatedRoute } from '@angular/router';
import { LoginService } from '../services/login.service';
import { AclService } from '../services/acl.service';
import { SharedService } from '../services/shared.service';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Observable } from 'rxjs/Observable';


@Injectable()
export class OnlyLoggedInUsersGuard implements CanActivate { 

  constructor(private loginService: LoginService , private aclService: AclService , public router: Router,private sharedService: SharedService) {}; 

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) :Observable<boolean> | boolean {
    //console.log(this.loginService.isLoggedIn);
	/* let promise = new Promise((resolve, reject) => {
		resolve();
		//return true;
	});
	promise.then(function(result){
		console.log(result);
		return true;
	}) */
	
	this.loginService.isLoggedIn().subscribe(data => {
		const permission = route.data["permission"];
		const pathName = route.data["pathname"];
		var pagNav;
		if(data.success == true) {
			if(data['data']['UserRole'] != "1"){ //console.log('------------UserRole check in-------');
				return this.aclService.getRoles().then(userRoles => {
					/* console.log(userRoles);
					console.log(pathName);
					console.log('------------UserRole check step 1-------'); */
					//return userRoles;
					//pathName = route.data["pathname"];
					
					for(let pages of Object.values(userRoles)) { //let pages in userRoles
						 /* if(pages.page == 'dashboard')
						 { */	
							this.router.navigate(['/dashboard']);
							return true;
							
						 /* } else {
							 if(pages.page == pathName) {
								var accFunc = pages.functionality;
								 
								if(accFunc.includes('view')){  
									this.router.navigate(['/dashboard']);
									return true;
								  }else {  
									this.sharedService.IsUserLoggedIn.next(false);
									this.router.navigate(['/login']);
									return  false;  
								 }
							 } 
						 } */
						 
					}
					
					/* userRoles.forEach(function(pages){
						console.log(pages.page+'--->'+pathName);
						if(pages.page == pathName) {
							var accFunc = pages.functionality;
							console.log(accFunc.includes('view'));
							if(accFunc.includes('view')){
								this.router.navigate(['/dashboard']);
								return true;
							}else {
								this.router.navigate(['/login']);
								return  false;
							}
						}
					}); */
					this.sharedService.IsUserLoggedIn.next(false);
					this.router.navigate(['/login']);
					return false;
				});
			}
		} else { //console.log('------------UserRole check out-------');
			this.sharedService.IsUserLoggedIn.next(false);
			this.router.navigate(['/login']);
			return false;
		}
	});
	return true;
	
	/* if(this.checkUserLoggedIn(route)){
		 if(this.getUserAccess(route)) {
			//this.router.navigate(['/dashboard']);
			console.log('have access');
			return true;
		} else {
			console.log('no access');
			localStorage.removeItem('usrToken');
			this.router.navigate(['/login']);
			return false;
		}  
	}else {
		localStorage.removeItem('usrToken');
		this.router.navigate(['/login']);
		return false;
	} */
	
  }
  
  checkUserLoggedIn(route) {
	/* console.log('in routing');
	const data = this.loginService.isLoggedIn();
	console.log(data);
	return false; */
	return this.loginService.isLoggedIn().subscribe(data => {
		//return new Promise((resolve, reject) => {
			const permission = route.data["permission"];
			const pathName = route.data["pathname"];
			var pagNav;
			if(data.success == true) {
				return true;
			} else {
				return false;
			}
			
		//});
	}); 
  }
  
  getUserAccess(route) {
	var pathName;
	return this.aclService.getRoles().then(userRoles => {
		//console.log(userRoles);
		//return userRoles;
		pathName = route.data["pathname"];
		for(let pages of Object.values(userRoles)) { //let pages in userRoles
			//console.log(pages);
			if(pages.page == pathName) {
				var accFunc = pages.functionality;
				//console.log(accFunc.includes('view'));
				if(accFunc.includes('view')){
					this.router.navigate(['/dashboard']);
					return true;
				}else {
					this.router.navigate(['/login']);
					return  false;
				}
			}
		}
		/* userRoles.forEach(function(pages){
			console.log(pages.page+'--->'+pathName);
			if(pages.page == pathName) {
				var accFunc = pages.functionality;
				console.log(accFunc.includes('view'));
				if(accFunc.includes('view')){
					this.router.navigate(['/dashboard']);
					return true;
				}else {
					this.router.navigate(['/login']);
					return  false;
				}
			}
		}); */
		this.router.navigate(['/login']);
		return false;
	}); 
	//console.log(pathName);
	//return false;
  }
}