import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchfilter'
})
export class SearchfilterPipe implements PipeTransform {

/*    transform(items: any[], field: string, value: string): any[] {
	   if (!items) return [];
	   return items.filter(it => it[field] == value);
   }
    */
   /* transform(items: Array<any>, conditions: {[field: string]: any}): Array<any> {
        return items.filter(item => {
            for (let field in conditions) {
                if (item[field] !== conditions[field]) {
                    return false;
                }
            }
            return true;
        });
    } */
	transform(items: Array<any>, conditions: Array<any>): Array<any> {
        return items.filter(item => {
            for (let fieldArr in conditions) {
				var conditionsArr = conditions[fieldArr];
				for (let field in conditionsArr) {
					/* console.log(conditionsArr[field]);
					console.log(item[field]); */
					if (item[field] == conditionsArr[field]) {
						//return false;
						return true;
					} 
				}
            }
        });
    }
 
 
}
