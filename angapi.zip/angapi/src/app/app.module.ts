import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule }   from '@angular/forms';
import {HttpModule} from "@angular/http";
import { JwtModule } from '@auth0/angular-jwt';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import {AccordionModule} from "ngx-accordion";
import { ModalDialogModule } from 'ngx-modal-dialog';
import { FormioModule/* ,FormioAppConfig */ } from 'angular-formio';
import {DropdownModule} from 'primeng/dropdown';
import {EditorModule} from 'primeng/editor';
import { ToastrModule } from 'ngx-toastr';
//for captcha
import { BotDetectCaptchaModule } from 'angular-captcha';
//import { RecaptchaModule } from 'angular-google-recaptcha';
import { RecaptchaModule, RECAPTCHA_SETTINGS, RecaptchaSettings } from 'ng-recaptcha';
import { RecaptchaFormsModule } from 'ng-recaptcha/forms';

import { QueryBuilderModule } from "angular2-query-builder";
 
import { AppComponent } from './app.component';
import { TemplateAComponent } from './components/template-a/template-a.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { NavComponent } from './components/nav/nav.component';
import { LoginComponent } from './components/login/login.component';
import { UsersComponent } from './components/users/users.component';
import { AppRoutingModule } from './modules/app-routing.module';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { AccountComponent } from './components/account/account.component';
import { Page404Component } from './components/page404/page404.component';
import { ProjectComponent } from './components/project/project.component';
import { ForgotpasswordComponent } from './components/forgotpassword/forgotpassword.component';

import { LoginService } from './services/login.service';
import { UsersService } from './services/users.service';
import { SharedService } from './services/shared.service';
import { AccountService } from './services/account.service';
import { ProjectService } from './services/project.service';
import { ApplAgeService } from './services/appl-age.service';
import { AclComponent } from './components/acl/acl.component';
import { AclService } from './services/acl.service';
import { RoleComponent } from './components/role/role.component';
import { RoleService } from './services/role.service';
import { ApplicationService } from './services/application.service';
import { ApplicationComponent } from './components/application/application.component';
import { RulengineComponent } from './components/rulengine/rulengine.component';
import { RuleengineService } from './services/ruleengine.service';
import { Workexpservice } from './services/workexp.service';
import { AcpsharedService } from './services/acpshared.service';
import { AcpService } from './services/acp.service';
import { ReportsService } from './services/reports.service';


import { ApplnInterceptor } from './helpers/appln-interceptor';
import {NgxPaginationModule} from 'ngx-pagination';
//import { MyDatePickerModule } from 'angular4-datepicker';

/**
 * Import the Custom component CheckMatrix.
 */
import {Formio} from 'formiojs';
import './components/CheckMatrix';
import { AccesslevelComponent } from './components/accesslevel/accesslevel.component';
import { SearchfilterPipe } from './pipe/searchfilter.pipe';
import { TemplateAcpComponent } from './components/acp/template-acp/template-acp.component';

import { AcpModule } from './components/acp/acp.module';
// import { EmailSettingComponent } from './components/email-setting/email-setting.component'; 
/* export function tokenGetter() {
  return localStorage.getItem('usrToken');
} */

import { NgxLoadingModule, ngxLoadingAnimationTypes } from 'ngx-loading';
@NgModule({
  declarations: [
    AppComponent,
	TemplateAComponent,
    HeaderComponent,
    FooterComponent,
    NavComponent,
    LoginComponent,
	UsersComponent,
    DashboardComponent,
    Page404Component,
    AccountComponent,
    ProjectComponent,
    AclComponent,
    RoleComponent,
    ApplicationComponent,
    RulengineComponent,
    AccesslevelComponent,
    SearchfilterPipe,
    TemplateAcpComponent,
	ForgotpasswordComponent
	// EmailSettingComponent 
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
	AppRoutingModule,
	FormsModule,
	HttpModule,
	HttpClientModule,
	AccordionModule,
	FormioModule,
	QueryBuilderModule,
	ModalDialogModule.forRoot(), 
	NgxPaginationModule,
   ReactiveFormsModule,
   DropdownModule,
   EditorModule,
   NgxLoadingModule.forRoot({
	    animationType: ngxLoadingAnimationTypes.doubleBounce,
        backdropBackgroundColour: 'rgba(0,0,0,0.1)', 
        backdropBorderRadius: '15px',
        primaryColour: '#bed730', 
        secondaryColour: '#ffffff', 
        tertiaryColour: '#bed730'
    }),
  ToastrModule.forRoot(),
	/* RecaptchaModule.forRoot({
		siteKey: '6Lc6QLAUAAAAAInZHVxLl1hz2ahplDR1q07KzXP0',
	}), */
	RecaptchaModule,
    RecaptchaFormsModule,
	/* BotDetectCaptchaModule.forRoot({ 
      captchaEndpoint: 
        'http://223.30.222.85/satheesh/botdetect-captcha-lib/simple-botdetect.php'
    }), */
	AcpModule
	//MyDatePickerModule
	 /* JwtModule.forRoot({
      config: {
        tokenGetter: tokenGetter,
        //whitelistedDomains: ['localhost:3001'],
        //blacklistedRoutes: ['localhost:3001/auth/']
      }
    }) */
  ],
  providers: [LoginService ,UsersService, SharedService, AccountService, ProjectService  , AclService , RoleService, ApplicationService,RuleengineService,ApplAgeService,Workexpservice,AcpsharedService,AcpService,ReportsService,{
      provide: HTTP_INTERCEPTORS,
      useClass: ApplnInterceptor,
      multi: true
},{
      provide: RECAPTCHA_SETTINGS,
      useValue: { siteKey: '6Lc6QLAUAAAAAInZHVxLl1hz2ahplDR1q07KzXP0' } as RecaptchaSettings,
    },],
  bootstrap: [AppComponent],
  entryComponents: [AppComponent],
})
export class AppModule { }
