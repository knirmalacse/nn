import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router'; 
import { LoginComponent } from '../components/login/login.component';
import { HeaderComponent } from '../components/header/header.component';
import { UsersComponent } from '../components/users/users.component';
import { DashboardComponent } from '../components/dashboard/dashboard.component';
import { AccountComponent } from '../components/account/account.component';
import { ProjectComponent } from '../components/project/project.component';
import { ForgotpasswordComponent } from '../components/forgotpassword/forgotpassword.component';
import { ApplicationComponent } from '../components/application/application.component';
import { RulengineComponent } from '../components/rulengine/rulengine.component';
import { AclComponent } from '../components/acl/acl.component';
import { RoleComponent } from '../components/role/role.component';
import { Page404Component } from '../components/page404/page404.component';
import { AccesslevelComponent } from '../components/accesslevel/accesslevel.component';
// import { EmailSettingComponent } from './../components/email-setting/email-setting.component'; 


import { AcpModule } from '../components/acp/acp.module';
import { ApplnAgeModule } from '../components/appln-age/appln-age.module';
import { OnlyLoggedInUsersGuard } from '../helpers/loggedinusers.guard';

const routes: Routes = [
  { path: '', redirectTo: '/login',  pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'forgot', component: ForgotpasswordComponent },
  { path: 'accesslevel', component: AccesslevelComponent,canActivate: [OnlyLoggedInUsersGuard]},
//   {path: 'emailsettings', component: EmailSettingComponent, canActivate: [OnlyLoggedInUsersGuard]},
  { path: 'acp/:projectId', loadChildren: '../components/acp/acp.module#AcpModule' },
  { path: 'users', component: UsersComponent , canActivate: [OnlyLoggedInUsersGuard],data: {
		pathname: 'users',
        permission: {
            only: [ '1','3'],
            redirectTo: 'login'
        }
    }},//, canActivate: [OnlyLoggedInUsersGuard]
  { 
	path: 'dashboard', 
	component: DashboardComponent, 
	canActivate: [OnlyLoggedInUsersGuard],
	data: {
		pathname: 'dashboard',
        permission: {
            only: [ '1'],
            redirectTo: 'login'
        }
    }
  },
  { 
	path: 'account', 
	component: AccountComponent, 
	canActivate: [OnlyLoggedInUsersGuard],
	data: {
		pathname: 'account',
        permission: {
            only: [ '1','3'],
            redirectTo: 'login'
        }
    }
  }, 
  { 
	path: 'project', 
	component: ProjectComponent,
	canActivate: [OnlyLoggedInUsersGuard],
	data: {
		pathname: 'project',
        permission: {
            only: [ '1'],
            redirectTo: 'login'
        }
    }
  }, 
  { 
	path: 'application', 
	component: ApplicationComponent,
	canActivate: [OnlyLoggedInUsersGuard],
	data: {
		pathname: 'application',
        permission: {
            only: [ '1'],
            redirectTo: 'login'
        }
    }
  }, 
  { 
	path: 'rulengine', 
	component: RulengineComponent,
	canActivate: [OnlyLoggedInUsersGuard],
	data: {
		pathname: 'rulengine',
        permission: {
            only: [ '1'],
            redirectTo: 'login'
        }
    }
  }, 
  { path: 'acl', component: AclComponent,canActivate: [OnlyLoggedInUsersGuard]}, //, canActivate: [OnlyLoggedInUsersGuard]
  { path: 'role', component: RoleComponent,canActivate: [OnlyLoggedInUsersGuard]}, //, canActivate: [OnlyLoggedInUsersGuard]
  { path: 'age', loadChildren: '../components/appln-age/appln-age.module#ApplnAgeModule',canActivate: [OnlyLoggedInUsersGuard] }, //, canActivate: [OnlyLoggedInUsersGuard]
  {path: '404', component: Page404Component},
  { path: '**', component: Page404Component }
];


@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [RouterModule],
  providers: [OnlyLoggedInUsersGuard]
})
export class AppRoutingModule { }
