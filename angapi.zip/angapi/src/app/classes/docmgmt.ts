export class Docmgmt {
    constructor(
        public doccategory: any,
        public docname: any,
        public docfile: any,
      ) {  }
}
