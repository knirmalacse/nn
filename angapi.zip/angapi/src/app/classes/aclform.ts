export class Aclform {
	constructor(
    public id: any,    
    public permissionSet?: {
		ListAccounts: any;
		CreateAccounts: any;
		DeleteAccounts: any;
		UpdateAccounts: any;
	}
  ) {  }
}