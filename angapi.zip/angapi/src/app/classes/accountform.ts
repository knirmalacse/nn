export class Accountform {
	constructor(
    public id: any,    
    public accountName?: string,
    public registrationType?: string,
    public accountDetails?: string,
    public accountDomain?: string,
  ) {  }
}