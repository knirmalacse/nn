export class Userform {
	constructor(
    public id: any,    
    public UserName?: string,
    public EmailID?: string,
    public Password?: string,
    public frmPassword2?: string,
    public UserRole?: string,
    public Mobile?: string,
    public status?: string,
  ) {  }
}