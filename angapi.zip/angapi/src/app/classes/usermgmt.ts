export class Usermgmt {
    constructor(
        public id: number,
        public userName: string,
        public emailID: string,
        public mobileNo: string,
        public userType: string,
        public userStatus: string,
        public userPwd?: string,
        public userCPwd?: string,
      ) {  }
}
