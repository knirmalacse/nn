export class Roleform {
  constructor(
    public _id: any,    
    public role?: string,
  ) {  }
}