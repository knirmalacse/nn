export class Projectform {
	constructor(
    public id: any,    
    public projectid?: string,
    public projectName?: string,
    public projectDetails?: string,
    public projectIdentifier?: string,
    public projectServices?: {
		hasEmail: any;
		hasSms: any;
		hasCaptcha: any;
		hasBarcode: any;
		hasUploads: any;
		hasPayment: any;
	},
	public projectComponents?: {
		hasRegistration: any;
		hasReRegistration: any;
		hasCallletter: any;
		hasResults: any;
	},
    public projectLogo?: any,
    //public projectPaymentMode?: string,
    //public projectPaymentType?: string,
  ) {  }
}