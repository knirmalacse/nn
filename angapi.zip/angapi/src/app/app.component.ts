import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  ulrAcp : any = 0; 
  ngOnInit() {
	  let urlString = location.pathname;
	  if(urlString.indexOf('/acp/') >=0 ){
		  this.ulrAcp = '1';  
	  }
  }
}