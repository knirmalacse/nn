const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const validator = require('express-validator');
const path = require('path');
const http = require('http');
const app = express();

// API file for interacting with MongoDB
const api = require('./server/routes/api1');
//var login = require('./server/routes/login');
//var register = require('./server/routes/register');


// Parsers
app.use(session({
	secret: 'testsession',
	resave: false,
	saveUninitialized: true,
	cookie: { maxAge: 60000 }
	}
));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false}));
app.use(validator());

// Angular DIST output folder
app.use(express.static(path.join(__dirname, '../dist')));

app.use(function(req, res, next) {
  res.set('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
  next();
});

app.use(function(req, res, next) {
 res.header("Access-Control-Allow-Origin", "*");
 res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS');
 res.header("Access-Control-Allow-Headers", "X-Requested-With,Content-Type,Cache-Control");
 next();
});

// API location
app.use('/api', api);
//app.use('/api/login', login);
//app.use('/api/register', register);

// Send all other requests to the Angular app
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../dist/index.html'));
});

//Set Port
const port = process.env.PORT || '1003';
app.set('port', port);

const server = http.createServer(app);

server.listen(port, () => console.log(`Running on localhost:${port}`));