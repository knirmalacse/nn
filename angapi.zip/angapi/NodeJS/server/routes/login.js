const { check, oneOf, validationResult } = require('express-validator/check');
const { matchedData, sanitize } = require('express-validator/filter');
const ObjectID = require("mongodb").ObjectID;
const mongojs = require("mongojs");
const db = mongojs("FormBuilderACP", ["users"]);



exports.loginFn = function(req, res) {
	sess = req.session;
	const errorFormatter = ({ location, msg, param, value }) => {
		// Build your resulting errors however you want! String, object, whatever - it works!
		return `${msg}`;
	};
	req.check("usrName")
		.notEmpty().withMessage("Please enter Email Address")
		.isEmail().withMessage("Please enter a valid Email Address");
	req.assert('usrPwd', 'Please enter Password')
		.notEmpty();
	var errors = req.validationErrors();
	const results = validationResult(req).formatWith(errorFormatter);
	
	/*req.validationErrors().then(() => {
			db.users.find({frmEmail1: req.body.usrName,frmPassword1: req.body.usrPwd}, function (err, user) {
				if(err) {
					response.success = false;
					response.message = "Invalid Email or Password";
				}else if (user) {
					sess.email=req.body.usrName;
					response.success = true;
					response.message = "Success";
				}
			});
			//db.users.save(req.body);
			//response.success = true;
			//response.message = "Success";
	  }).catch((errors) => {
		    const results = validationResult(req).formatWith(errorFormatter);
			//console.log(errors);
			//console.log(results.mapped());
			if(errors) {
			  response.success = false;
			  response.message = results.mapped();
			  
		  };
	  });*/
	  if (errors) {
		response.message = results.mapped();
	  } else {
			response.message = '';
			db.users.find({frmEmail1: req.body.usrName,frmPassword1: req.body.usrPwd}, function (err, user) {
			console.log(user[0].frmusername);
			if (err) {
				response.success = false;
				response.message = "Invalid Email or Password";
			}else if (user  && user[0]) {
				req.session.email=user[0].frmEmail1;
				console.log(req.session.email);
				response.success = true;
				response.message = "Success";
			} else {
				console.log('else');
				response.success = false;
				response.message = "Invalid Email or Password";
			}
		});
		 
	  }
	res.json(response);
};

exports.usrLoginChkFn = function(req,res){
	sess = req.session;
	console.log(req.session);
	console.log(req.session.email);
	if(req.session.email) {
		response.success = true;
	} else {
		response.success = false;
	}
	res.json(response);
};

exports.logoutFn = function(req,res){
	req.session.destroy(function(err) {
		if(err) {
			response.success = false;
		} else {
			response.success = true;
		}
	});
	res.json(response);
};