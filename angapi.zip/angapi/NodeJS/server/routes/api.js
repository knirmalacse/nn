const express = require("express");
const router = express.Router();
const ObjectID = require("mongodb").ObjectID;
const mongojs = require("mongojs");
const db = mongojs("FormBuilderACP", ["users"]);
const request = require('request');

const validator = require('express-validator');
const { check, oneOf, validationResult } = require('express-validator/check');
const { matchedData, sanitize } = require('express-validator/filter');

// Error handling
const sendError = (err, res) => {
 response.status = 501;
 response.message = typeof err == "object" ? err.message : err;
 res.status(501).json(response);
};

//var sess;
// Response handling
response = {
 status: 200,
 data: [],
 message: null,
 success: false,
};

responseAcc = {
 status: 200,
 data: [],
 message: null
};

response1 = {
 status: 200,
 data: [],
 message: null
};


router.use(validator({
    customValidators: {
      isEmailExists(value, udetails) {
        return new Promise((resolve, reject) => {
         db.users.find({frmEmail1: value, isDeleted : 0}, function (err, user){
            if (err) reject();
            if(user && user[0]) {
              //reject();
			  if(user[0]._id == udetails.uid && udetails.uid != ''){
					resolve();
				} else {
					reject();
				}
            } else {
              resolve();
            }
          });
        });
      },
	  
	  isUserNameExists(value, udetails) {
        return new Promise((resolve, reject) => {
         db.users.find({frmusername: value, isDeleted : 0}, function (err, user){
            if (err) reject();
            if(user && user[0]) {		;
				if(user[0]._id == udetails.uid && udetails.uid != ''){
					resolve();
				} else {
					reject();
				}
            } else {
              resolve();
            }
          });
        });
      },
	  
	  isMobileExists(value, udetails) {
        return new Promise((resolve, reject) => {
         db.users.find({frmmobile: value, isDeleted : 0}, function (err, user){
            if (err) reject();
            if(user && user[0]) {		;
				if(user[0]._id == udetails.uid && udetails.uid != ''){
					resolve();
				} else {
					reject();
				}
            } else {
              resolve();
            }
          });
        });
      },
	  
    }
  })
);

router.post('/register', function(req, res) {
	const errorFormatter = ({ location, msg, param, value }) => {
		// Build your resulting errors however you want! String, object, whatever - it works!
		return `${msg}`;
	  };
    req.header('Cache-Control', 'no-cache');
	const regID = req.body.formUID;
	req.body = JSON.parse(req.body.formJSON);	
	req.checkBody('frmusername', "Please enter  Display Name.").notEmpty();
	//req.checkBody('frmusername', "This User Name is already in use").isUserNameExists({usernm: req.body.frmusername, uid : regID});	
	if(regID == ''){
		req.checkBody('frmEmail1', "Please enter  email address.").notEmpty();
		req.checkBody('frmEmail1', "Please enter valid email address.").isEmail();
		req.checkBody('frmEmail1', "This email is already in use").isEmailExists({usernm: req.body.frmEmail1, uid : regID});
	}
	
	
	req.checkBody('frmPassword1', "Please enter  Password").notEmpty();
	req.checkBody('frmPassword1', "Password should more than 4 characters").isLength({ min: 4 });
		
	req.checkBody('frmPassword2', "Please enter Confirm Password").notEmpty();
	req.checkBody('frmPassword2', "Confirm Password should more than 4 characters").isLength({ min: 4 });
	req.check('frmPassword2', 'Confirm Password must have the same value as the password').custom((value) => value === req.body.frmPassword1);
	
	req.checkBody('frmmobile', "Please enter Mobile No").notEmpty();	
	req.check('frmmobile','Invalid Mobile No').isInt(10).isLength({ min: 10, max:10 });
	req.checkBody('frmmobile', "Mobile No already in use").isMobileExists({usernm: req.body.frmmobile, uid : regID});
	
	req.checkBody('frmutype', "Please select User Type").notEmpty();	
	req.check('frmutype','Invalid User Type').isIn(['1', '2', '3', '4']);
	
	req.checkBody('frmstatus', "Please select Status").notEmpty();
	req.check('frmstatus','Invalid Status').isIn(['Y', 'N']);
	
	req.asyncValidationErrors().then(() => {
			 if(regID){
				 db.collection('users').update({'_id': ObjectID(regID)},
                    {$set: req.body});
				 response.message = "User updated successfully";
			 } else {
				 req.body.isDeleted = 0;
				 db.users.save(req.body);
				 response.message = "User added successfully";
			 }
			 
			 response.success = true;
			 
	  }).catch((errors) => {
			//response.success = false;
		    const results = validationResult(req).formatWith(errorFormatter);
			//console.log(errors);
			//console.log(results.mapped());
			
			if(errors) {
			 
			  response.success = false;
			  response.message = results.mapped();
			  
		  };
	  });
	res.json(response);
});



// Get users
router.get("/users", (req, res, next) => {
  if(req.session.email) {
	db.users.find({isDeleted : 0},(err, users) => {
	  if (err) return next(err);
	  response1.data = users;
	  res.json(response1);
	});
  } else {
	  console.log("Access Denied");
  }
}); 

router.post("/getuser", (req, res, next) => {

 db.users.find({'_id': ObjectID(req.body.userID), isDeleted : 0},(err, users) => {
  if (err) return next(err);
  else if(users && users[0]){
	response1.data = users[0];
	response1.success =  true;
  }
  else {
	response1.success =  false;
	response1.data = '';
  }
  res.json(response1);
 });
});

router.post("/setuserstatus", (req, res, next) => {

 req.check('status','Invalid Status').isIn(['Y', 'N']);	
 var errors = req.validationErrors();
 
 if(errors){
	 response1.success =  false;
	 response1.data = ''; 
 } else {
	 db.collection('users').update({'_id': ObjectID(req.body.userID)},
                    {$set: { frmstatus: req.body.status }});
					 
	 response1.success =  true; response1.data = ''; response1.message = 'Status updated successfully';
 }
 res.json(response1);
});

router.post("/deleteusers", (req, res, next) => {	
	/*db.collection('users').remove(
            {'_id': ObjectID(req.body.userID)}, 
            function (err, result){ 
               //check result to see how many document are deleted
			   console.log(result);
	});	*/
	 db.collection('users').update({'_id': ObjectID(req.body.userID)},
                    {$set: { isDeleted: 1 }});
	 response1.success =  true; response1.data = '';  response1.message = 'User deleted successfully';
 
	 res.json(response1);
});


router.post('/accountregister', function(req, res) {
	const errorFormatter = ({ location, msg, param, value }) => {
		// Build your resulting errors however you want! String, object, whatever - it works!
		return `${msg}`;
	  };
    req.header('Cache-Control', 'no-cache');
	const regID = req.body.AID;
	req.body = JSON.parse(req.body.formJSON);	
	
	req.checkBody('accountName', "Please enter Account Name.").notEmpty();
	req.checkBody('accountName', " Account Name should more than 4 characters or less than 50 characters").isLength({ min: 4, max:50 });
		
	req.checkBody('registrationType', "Please select Registration Type").notEmpty();	
	req.check('registrationType','Invalid Registration Type').isIn(['1', '2']);
	
	req.checkBody('accountDetails', "Please enter Account Details.").notEmpty();
	req.checkBody('accountDetails', " Account Details should more than 4 characters or less than 100 characters").isLength({ min: 4, max:100 });
	
	req.checkBody('accountDomain', "Please enter Account Domain.").notEmpty();
	req.check("accountDomain", "Invalid Account Domain").matches(/^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$/gm, "i");
	
	
	req.asyncValidationErrors().then(() => {
			if(regID){
				req.body.updatedBy = req.session.usrName;
				 db.collection('account').update({'_id': ObjectID(regID)},
					{
						$currentDate:{
							lastmodifiedDate:{$type:"timestamp"}
						},
						$set: req.body
					});
				 response.message = "Account updated successfully";
			 } else {
				 req.body.isDeleted = 0;
				 req.body.createdBy = req.session.usrName;
				 req.body.createdDate = new Date(Date.now());
				 //console.log(req.body);
				db.account.save(req.body);
				 response.message = "Account added successfully";
			 }
			 //response.errMessage = '';
			 response.success = true;
			 //response.saved = true;
			 
	  }).catch((errors) => {
		    const results = validationResult(req).formatWith(errorFormatter);
			//console.log(errors);
			//console.log(results.mapped());
			
			if(errors) {
			 
			  response.success = false;
			  //response.saved = false;
			  response.message = results.mapped();
			  
		  };
	  });
	res.json(response);
});


// Get account
router.get("/accountinfo", (req, res, next) => {
 db.account.find({isDeleted : 0},(err, accounts) => {
  if (err) return next(err);
  response1.data = accounts;
  res.json(response1);
 });
}); 

router.post("/getaccountdetails", (req, res, next) => {

 db.account.find({'_id': ObjectID(req.body.AID), isDeleted : 0},(err, accounts) => {
  if (err) return next(err);
  else if(accounts && accounts[0]){
	response1.data = accounts[0];
	response1.success =  true;
  }
  else {
	response1.success =  false;
	response1.data = '';
  }
  res.json(response1);
 });
});


router.post("/deleteaccount", (req, res, next) => {	
	/* db.collection('account').remove(
            {'_id': ObjectID(req.body.AID)}, 
            function (err, result){ 
               //check result to see how many document are deleted
			   console.log(result);
	});	 */
	 db.collection('account').update({'_id': ObjectID(req.body.AID)},
                   {$set: { isDeleted: 1 }});
	 response1.success =  true; response1.data = '';  response1.message = 'Account deleted successfully';
 
	 res.json(response1);
});

/* const login = require('./login');
router.post('/login', login.loginFn);
router.get('/usrLogCheck', login.usrLoginChkFn); */

router.post('/login',function(req, res) {
	
	sess = req.session;
	const errorFormatter = ({ location, msg, param, value }) => {
		// Build your resulting errors however you want! String, object, whatever - it works!
		return `${msg}`;
	};
	req.check("usrName")
		.notEmpty().withMessage("Please enter Email Address")
		.isEmail().withMessage("Please enter a valid Email Address");
	req.assert('usrPwd', 'Please enter Password')
		.notEmpty();
	var errors = req.validationErrors();
	const results = validationResult(req).formatWith(errorFormatter);
	
	/*req.validationErrors().then(() => {
			db.users.find({frmEmail1: req.body.usrName,frmPassword1: req.body.usrPwd}, function (err, user) {
				if(err) {
					response.success = false;
					response.message = "Invalid Email or Password";
				}else if (user) {
					sess.email=req.body.usrName;
					response.success = true;
					response.message = "Success";
				}
			});
			//db.users.save(req.body);
			//response.success = true;
			//response.message = "Success";
	  }).catch((errors) => {
		    const results = validationResult(req).formatWith(errorFormatter);
			//console.log(errors);
			//console.log(results.mapped());
			if(errors) {
			  response.success = false;
			  response.message = results.mapped();
			  
		  };
	  });*/
	  if (errors) {
		response.message = results.mapped();
	  } else {
			response.message = '';
			db.users.find({frmEmail1: req.body.usrName,frmPassword1: req.body.usrPwd}, function (err, user) {
			//console.log(user[0]);
			if (err) {
				response.success = false;
				response.message = "Invalid Email or Password";
			}else if (user  && user[0]) {
				req.session.email=user[0].frmEmail1;
				req.session.usrName=user[0].frmusername;
				req.session.save();
				//console.log(req.session.email);
				response.success = true;
				response.message = "Success";
			} else {
				console.log('else');
				response.success = false;
				response.message = "Invalid Email or Password";
			}
		});
		 
	  }
	res.json(response);
});

router.get('/usrLogCheck',function(req,res){
	//sess = req.session;
	//console.log(req.session);
	console.log(req.session.email);
	if(req.session.email) {
		response.success = true;
	} else {
		response.success = false;
	}
	res.json(response);
});

router.get('/usrDetails',function(req,res){
	//sess = req.session;
	//console.log(req.session);
	//console.log(req.session.email);
	response.data = '';
	if(req.session.email && req.session.usrName) {
		response.success = true;
		response.data = req.session.usrName;
	} else {
		response.success = false;
	}
	res.json(response);
});
router.get('/logout', function(req,res){
	req.session.destroy(function(err) {
		if(err) {
			response.success = true;
		} else {
			response.success = false;
		}
	});
	res.json(response);
});

module.exports = router;