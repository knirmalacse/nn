const express = require("express");
const router = express.Router();
const ObjectID = require("mongodb").ObjectID;
const mongojs = require("mongojs");
const db = mongojs("FormBuilderACP", ["users"]);
const request = require('request');

const validator = require('express-validator');
const { check, oneOf, validationResult } = require('express-validator/check');
const { matchedData, sanitize } = require('express-validator/filter');

// Error handling
const sendError = (err, res) => {
 response.status = 501;
 response.message = typeof err == "object" ? err.message : err;
 res.status(501).json(response);
};

var sess;
// Response handling
let response = {
 status: 200,
 data: [],
 message: null
};

let response1 = {
 status: 200,
 data: [],
 message: null
};


router.use(validator({
    customValidators: {
      isEmailExists(value) {
        return new Promise((resolve, reject) => {
         db.users.find({frmEmail1: value}, function (err, user){
            if (err) reject();
            if(user && user[0]) {
              reject();
            } else {
              resolve();
            }
          });
        });
      },
	  
	  isUserNameExists(value) {
        return new Promise((resolve, reject) => {
         db.users.find({frmusername: value}, function (err, user){
            if (err) reject();
            if(user && user[0]) {
              reject();
            } else {
              resolve();
            }
          });
        });
      },
	  
    }
  })
);

router.post('/register', function(req, res) {
	const errorFormatter = ({ location, msg, param, value }) => {
		// Build your resulting errors however you want! String, object, whatever - it works!
		return `${msg}`;
	  };
    req.header('Cache-Control', 'no-cache');
	req.body = JSON.parse(req.body.formJSON);
	console.log(req.body);
	req.checkBody('frmusername', "Please enter  User Name.").notEmpty();
	req.checkBody('frmusername', "This User Name is already in use").isUserNameExists(req.body.frmusername);
	
	req.checkBody('frmEmail1', "Please enter  email address.").notEmpty();
	req.checkBody('frmEmail1', "Please enter valid email address.").isEmail();
	req.checkBody('frmEmail1', "This email is already in use").isEmailExists(req.body.frmEmail1);
	
	req.checkBody('frmPassword1', "Please enter  Password").notEmpty();
	req.checkBody('frmPassword1', "Password should more than 4 characters").isLength({ min: 4 });
		
	req.checkBody('frmPassword2', "Please enter Confirm Password").notEmpty();
	req.checkBody('frmPassword2', "Confirm Password should more than 4 characters").isLength({ min: 4 });
	req.check('frmPassword2', 'Confirm Password must have the same value as the password').custom((value) => value === req.body.frmPassword1);
	
	req.checkBody('frmmobile', "Please enter Mobile No").notEmpty();	
	req.check('frmmobile','Invalid Mobile No').isInt(10).isLength({ min: 10, max:10 });
	
	req.checkBody('frmutype', "Please select User Type").notEmpty();	
	req.check('frmutype','Invalid User Type').isIn(['1', '2', '3', '4']);
	
	req.checkBody('frmstatus', "Please select Status").notEmpty();
	req.check('frmstatus','Invalid Status').isIn(['Y', 'N']);
	
	req.asyncValidationErrors().then(() => {
			 db.users.save(req.body);
			 response.success = true;
			 response.message = "Success";
	  }).catch((errors) => {
		    const results = validationResult(req).formatWith(errorFormatter);
			console.log(errors);
			console.log(results.mapped());
			
			if(errors) {
			 
			  response.success = false;
			  response.message = results.mapped();
			  
		  };
	  });
	res.json(response);
});


// Get users
router.get("/users", (req, res, next) => {
 db.users.find((err, users) => {
  if (err) return next(err);
  response1.data = users;
  console.log(users);
  res.json(response1);
 });
});


module.exports = router;